# Project Context

## Research focus

The project studies **online information-aware multi-UAV route planning under
weather, airspace, and wind uncertainty for post-disaster relief**.

At mission time zero, all 20 relief-node locations, commodity demands,
vulnerabilities, depot inventory, and UAV characteristics are known. The
research question is therefore how an external planning method should allocate,
sequence, and route UAVs as environmental information changes—not how UAVs
discover victims or sense unknown demand.

The current milestone supplies the experimental environment only. It does not
select the eventual optimization or learning method.

## Research gap approached

Many relief-routing formulations plan with static or fully known operating
conditions. Weather-aware studies often model uncertain travel or energy cost,
while dynamic airspace and rolling forecast revisions are less often evaluated
together under a strict online information boundary. This project creates a
controlled setting in which route availability and direction-dependent battery
feasibility can both change as new information arrives.

The intended future contribution is an information-aware route-planning method
that reacts effectively to those revisions. The present repository makes that
claim testable without embedding a preferred method in the environment.

## Scenario design

The canonical seed-42 scenario has:

- 20 exact, known relief tasks in clustered disaster locations;
- three homogeneous UAVs and a 12-hour mission horizon;
- two evolving weather regions and two temporary no-fly regions;
- online environmental packets issued every 0.5 hours with a 1.5-hour horizon;
- a global, time-varying two-dimensional wind vector; and
- independent deterministic random streams for tasks, weather, airspace, and
  packet revisions.

Packets are visible only after their issue time. Their wind points and polygon
validity intervals apply within the packet horizon, and overlapping valid times
may be revised by later packets. Weather and airspace state is derived from
polygon geometry and validity intervals at traversal time.

## Wind and battery model

Wind is a global two-dimensional east/north vector in km/h. The UAV holds
nominal airspeed `v_uav` and crabs to stay on the directed track, so the
ground speed along the segment is

`s = w_along + sqrt(v_uav^2 - w_perp^2)`,

where `w_along` and `w_perp` are the along-track and cross-track wind parts.
Travel time is `L / s` and energy is constant nominal power
`e_c (m0 + w_pay) v_uav` times the time aloft. Thus a headwind raises both
travel time and energy, a tailwind lowers both, a crosswind slows the track,
and opposite route directions can have different feasibility. Zero wind
exactly recovers the calm model. The evaluator never extrapolates beyond the
latest packet: when the full route interval is not covered, forecast energy,
duration, and battery feasibility are returned as unknown.

## Method-neutral experimental contract

The retained scenario generator produces deterministic version-3 JSON with
schema, configuration, and scenario hashes. The pure route evaluator checks
only a polyline supplied by its caller. The event-driven executor accepts
explicit `prepare`, `dispatch`, and `deliver` commands and advances one event
at a time.

If a packet changes during a flight, execution settles the route under the
previous packet at the issue time and the UAV enters `AWAITING_ROUTE`; no
replacement route is constructed. Online snapshots contain current task
residuals, fleet and inventory state, active received polygons, and the latest
received packet. Future packets remain hidden.

The read-only `env.diagnostics.diagnose_packet_update` boundary compares an
externally supplied incumbent suffix against the immediately previous and
newly received packets at a decision epoch. It identifies geometry/time
direct impacts and propagates packet-aware ETA, flight energy, reserve, and
deadline effects through the declared suffix. The returned closure is
structured and JSON-compatible; it does not construct or repair routes,
allocate tasks, or inspect unrevealed packets.

Repeated stops require an incumbent-plan `current_route_index` when their
occurrence is ambiguous, so suffix extraction cannot accidentally include a
completed occurrence. The ordinary initial/terminal depot pair defaults to
the initial depot. The simulator wrapper closes its diagnostic window after
the next controller command.

## Evaluation outputs

Future methods can be compared on the same frozen scenario using:

- humanitarian objective terms: priority-weighted, quantity-weighted delivery
  time, its horizon reference, maximin fill-ratio fairness, and the normalized
  composite (configurable fairness weight `lambda_fair`);
- total and per-node deprivation (outcome metric, not the optimization
  objective);
- energy consumed;
- hard-route and battery violations;
- delivered units, per-node fill ratios, and global fill rate;
- the delivery log with per-delivery quantities and completion times;
- remaining unserved demand; and
- completed services and termination reason.

Algorithm selection, baselines, and method-specific ablations are deliberately
deferred until the route-planning contribution is finalized.
