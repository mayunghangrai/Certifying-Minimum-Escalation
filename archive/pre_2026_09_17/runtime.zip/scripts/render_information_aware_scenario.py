"""Render a self-contained inspection page for a canonical packet scenario."""

from __future__ import annotations

import argparse
import json
import numpy as np
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from env.diagnostics import diagnose_environmental_packet_update  # noqa: E402
from env.entities import Mode  # noqa: E402
from env.environment import EnvironmentalPacket  # noqa: E402
from env.params import N_COMMODITIES  # noqa: E402
from env.scenario import Scenario  # noqa: E402
from env.simulator import (  # noqa: E402
    DemandNodeSnapshot,
    EnvironmentSnapshot,
    UAVSnapshot,
)
from env.wind import WindForecastPoint  # noqa: E402


def _controlled_impact_closure(scenario: Scenario) -> dict:
    """Build a deterministic, visible-input-only closure for the HTML demo."""
    packets = scenario.environment_packet_timeline()
    if not packets:
        raise ValueError("the visualization requires at least one environmental packet")
    previous = packets[0]
    epoch_time_h = 0.5
    if not (
        previous.valid_from_h <= epoch_time_h < previous.valid_until_h
        and previous.wind_at(epoch_time_h) is not None
    ):
        raise ValueError("the controlled visualization revision requires 0.5 h packet coverage")
    if not scenario.nodes:
        raise ValueError("the controlled visualization requires a demand node")
    node = scenario.nodes[0]
    edge_matches = scenario.network.edges_between("DEPOT", f"NODE-{node.idx:03d}")
    if not edge_matches:
        raise ValueError("the controlled visualization requires a depot-to-node edge")
    edge = edge_matches[0]
    direction = np.asarray(edge.direction_xy, dtype=float)
    revision = 9.0 * direction
    revised_times = (epoch_time_h, epoch_time_h + 0.02, epoch_time_h + 0.04, previous.valid_until_h)
    if revised_times[-2] >= revised_times[-1]:
        raise ValueError("the controlled visualization requires a packet horizon after 0.54 h")
    revised_points = []
    for index, time_h in enumerate(revised_times):
        wind = previous.wind_at(time_h)
        if wind is None:
            raise ValueError("the first packet does not cover the controlled revision")
        u_kmh, v_kmh = wind
        if index in (1, 2):
            u_kmh -= float(revision[0])
            v_kmh -= float(revision[1])
        revised_points.append(WindForecastPoint(time_h, u_kmh, v_kmh))
    received = EnvironmentalPacket(
        packet_id=f"{previous.packet_id}-CONTROLLED-REVISION",
        issued_at_h=epoch_time_h,
        valid_from_h=epoch_time_h,
        valid_until_h=previous.valid_until_h,
        wind=tuple(revised_points),
        weather=previous.weather,
        airspace=previous.airspace,
    )
    fleet_item = scenario.fleet[0]
    load = [0.0] * N_COMMODITIES
    load[0] = min(1.0, float(node.demand[0]))
    plan = {
        fleet_item.id: {
            "route": ["DEPOT", f"NODE-{node.idx:03d}", "DEPOT"],
            "load": load,
            "deliveries": {f"NODE-{node.idx:03d}": load},
        }
    }
    snapshot = EnvironmentSnapshot(
        time_h=epoch_time_h,
        nodes=tuple(
            DemandNodeSnapshot(
                idx=item.idx,
                position=np.asarray([item.x, item.y], dtype=float),
                vulnerability=float(item.vulnerability),
                priority=float(item.priority),
                remaining_demand=np.asarray(item.demand, dtype=float),
            )
            for item in scenario.nodes
        ),
        uavs=(UAVSnapshot(
            idx=0,
            position=np.asarray(scenario.depot, dtype=float),
            battery=float(fleet_item.battery_capacity_wh),
            payload=np.zeros(N_COMMODITIES, dtype=float),
            mode=Mode.DEPOT,
            current_node=None,
            destination=None,
            active_route=None,
            committed_route=None,
            committed_destination=None,
        ),),
        inventory=np.asarray(scenario.initial_inventory, dtype=float),
        airspace_version=0,
        airspace_regions=(),
        wind_forecast=None,
        environment_packet=received,
        event_type=None,
        terminated=False,
    )
    probe = diagnose_environmental_packet_update(
        scenario,
        plan,
        snapshot,
        previous,
        received,
    )
    first_leg = next(
        (leg for leg in probe.legs if leg.destination == f"NODE-{node.idx:03d}"),
        None,
    )
    deadline = float(scenario.env_params().mission.T)
    if (
        first_leg is not None
        and first_leg.baseline.arrival_time_h is not None
        and first_leg.revised.arrival_time_h is not None
    ):
        baseline_arrival = float(first_leg.baseline.arrival_time_h)
        revised_arrival = float(first_leg.revised.arrival_time_h)
        deadline = (
            0.5 * (baseline_arrival + revised_arrival)
            if revised_arrival > baseline_arrival + 1e-9
            else revised_arrival + 0.05
        )
    closure = diagnose_environmental_packet_update(
        scenario,
        plan,
        snapshot,
        previous,
        received,
        deadlines_h={f"NODE-{node.idx:03d}": deadline},
    )
    return closure.to_dict()


HTML_TEMPLATE = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Authoritative environmental packets</title>
<style>
:root {
  color-scheme: light dark;
  --bg: #f7f8fb; --surface: #fff; --text: #18202b; --muted: #5e6b7b;
  --line: #d7dde5; --grid: #e8ecf1; --clear: #198754; --soft: #d97706;
  --blocked: #dc3545; --packet: #6f42c1; --node: #26384d; --depot: #111827;
}
@media (prefers-color-scheme: dark) {
  :root {
    --bg: #10141b; --surface: #171d26; --text: #e8edf3; --muted: #a6b1c0;
    --line: #394452; --grid: #252e3a; --clear: #42c987; --soft: #f6ad45;
    --blocked: #ff6b76; --packet: #b995f5; --node: #d6e2f0; --depot: #f8fafc;
  }
}
* { box-sizing: border-box; }
.sr-only { position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden; clip: rect(0,0,0,0); white-space: nowrap; border: 0; }
body { margin: 0; background: var(--bg); color: var(--text); font: 15px/1.45 system-ui, sans-serif; }
main { width: min(1180px, 100%); margin: 0 auto; padding: 20px; }
h1 { margin: 0; font-size: clamp(1.25rem, 3vw, 1.75rem); font-weight: 650; }
.subtitle { margin: 4px 0 14px; color: var(--muted); }
.meta { display: flex; flex-wrap: wrap; gap: 8px 18px; margin-bottom: 16px; color: var(--muted); font-size: .88rem; }
.controls { display: grid; grid-template-columns: auto minmax(180px, 1fr) auto; align-items: center; gap: 10px; margin-bottom: 10px; }
button, input { font: inherit; }
button { padding: 7px 12px; border: 1px solid var(--line); border-radius: 7px; background: var(--surface); color: var(--text); cursor: pointer; }
button:focus-visible, input:focus-visible { outline: 3px solid color-mix(in srgb, var(--packet) 42%, transparent); outline-offset: 2px; }
input[type="range"] { width: 100%; accent-color: var(--packet); }
.time { min-width: 84px; text-align: right; font-variant-numeric: tabular-nums; }
.horizon-wrap { display: grid; grid-template-columns: minmax(120px, 1fr) auto; gap: 12px; align-items: center; margin-bottom: 14px; }
.horizon-track { position: relative; height: 13px; border-radius: 7px; background: var(--grid); overflow: hidden; }
.horizon-band { position: absolute; inset-block: 0; background: color-mix(in srgb, var(--packet) 58%, transparent); }
.time-mark { position: absolute; top: -2px; width: 2px; height: 17px; background: var(--text); }
.horizon-label { color: var(--muted); font-size: .86rem; white-space: nowrap; }
.layout { display: grid; grid-template-columns: minmax(0, 1fr) minmax(250px, 310px); gap: 18px; align-items: start; }
.map-wrap { min-width: 0; }
#map { display: block; width: 100%; aspect-ratio: 1 / 1; max-height: 760px; background: var(--surface); border: 1px solid var(--line); }
.side { display: grid; gap: 14px; }
.section { border-top: 1px solid var(--line); padding-top: 10px; }
.section:first-child { border-top: 0; padding-top: 0; }
.section h2 { margin: 0 0 7px; font-size: 1rem; font-weight: 650; }
.value-grid { display: grid; grid-template-columns: 1fr auto; gap: 5px 12px; margin: 0; }
.value-grid dt { color: var(--muted); }
.value-grid dd { margin: 0; text-align: right; font-variant-numeric: tabular-nums; }
.legend { display: grid; gap: 7px; color: var(--muted); font-size: .87rem; }
.legend-row { display: flex; align-items: center; gap: 8px; }
.swatch { width: 28px; height: 0; border-top: 3px solid currentColor; }
.swatch.soft { color: var(--soft); }.swatch.clear { color: var(--clear); }.swatch.blocked { color: var(--blocked); }.swatch.packet { color: var(--packet); }
.route { fill: none; stroke-width: 2.1; cursor: pointer; transition: opacity .16s, stroke-width .16s; }
.route:hover, .route.selected { stroke-width: 4; }
.node { fill: var(--surface); stroke: var(--node); stroke-width: 2; cursor: pointer; }
.node.selected { fill: color-mix(in srgb, var(--packet) 24%, var(--surface)); stroke-width: 3; }
.node-label { fill: var(--text); font-size: 11px; pointer-events: none; text-anchor: middle; dominant-baseline: central; }
.depot { fill: var(--depot); stroke: var(--surface); stroke-width: 2; }
.weather { stroke: var(--soft); fill: color-mix(in srgb, var(--soft) 20%, transparent); stroke-width: 2; }
.hard-weather { stroke: var(--blocked); fill: color-mix(in srgb, var(--blocked) 18%, transparent); }
.airspace { stroke: var(--blocked); fill: color-mix(in srgb, var(--blocked) 22%, transparent); stroke-width: 2; }
.wind-arrow { fill: none; stroke: var(--packet); stroke-width: 4; }
.wind-label { fill: var(--text); font-size: 12px; }
.axis-label { fill: var(--muted); font-size: 11px; }
.gridline { stroke: var(--grid); stroke-width: 1; }
.impact-leg { border-top: 1px solid var(--line); margin-top: 8px; padding-top: 8px; }
.impact-leg:first-child { border-top: 0; margin-top: 0; padding-top: 0; }
.impact-leg strong { display: block; font-size: .88rem; }
.impact-leg span { color: var(--muted); font-size: .82rem; }
.empty { color: var(--muted); font-style: italic; }
@media (max-width: 780px) {
  main { padding: 14px; }
  .layout { grid-template-columns: 1fr; }
  .side { grid-template-columns: repeat(2, minmax(0, 1fr)); }
}
@media (max-width: 500px) {
  main { padding: 10px; }
  .controls { grid-template-columns: auto 1fr; }
  .controls .time { grid-column: 1 / -1; text-align: left; }
  .horizon-wrap { grid-template-columns: 1fr; }
  .side { grid-template-columns: 1fr; }
  .meta { gap: 5px 12px; }
}
</style>
</head>
<body>
<main>
  <header>
    <h1>Authoritative environmental packets</h1>
    <p class="subtitle">Known relief tasks and directed corridors; only the current environmental packet changes with mission time.</p>
    <div class="meta" id="meta"></div>
  </header>
  <div class="controls">
    <button id="play" type="button" aria-pressed="false">Play</button>
    <label><span class="sr-only">Mission time</span><input data-role="time-slider" id="time" type="range" min="0" value="0" step="0.05"></label>
    <output class="time" id="time-label" for="time">0.00 h</output>
  </div>
  <div class="horizon-wrap">
    <div class="horizon-track" data-role="packet-horizon" aria-label="Current packet validity on the mission timeline">
      <div class="horizon-band" id="horizon-band"></div><div class="time-mark" id="time-mark"></div>
    </div>
    <div class="horizon-label" id="horizon-label"></div>
  </div>
  <div class="layout">
    <div class="map-wrap"><svg id="map" viewBox="0 0 720 720" role="img" aria-labelledby="map-title map-desc">
      <title id="map-title">Directed relief network and current environmental state</title>
      <desc id="map-desc">Known demand nodes, directed depot corridors, packet-scoped weather and airspace polygons, and the current global wind vector.</desc>
    </svg></div>
    <aside class="side" aria-live="polite">
      <section class="section"><h2>Current packet</h2><dl class="value-grid" id="environment-values"></dl></section>
      <section class="section"><h2 id="route-heading">Selected direct corridor</h2><dl class="value-grid" id="route-values"></dl><p class="status-line" id="route-note"></p></section>
      <section class="section"><h2>Geometry-derived state</h2><div class="legend">
        <div class="legend-row"><span class="swatch clear"></span>Clear corridor</div>
        <div class="legend-row"><span class="swatch soft"></span>Soft weather</div>
        <div class="legend-row"><span class="swatch blocked"></span>Hard weather or airspace block</div>
        <div class="legend-row"><span class="swatch packet"></span>Current authoritative wind</div>
      </div></section>
      <section class="section"><h2>Active packet regions</h2><div id="active-regions" class="status-line"></div></section>
      <section class="section" data-role="impact-closure" aria-labelledby="impact-closure-title">
        <h2 id="impact-closure-title">Controlled packet-revision disturbance-impact closure</h2>
        <div id="impact-closure" class="status-line"></div>
      </section>
    </aside>
  </div>
</main>
<script id="scenario-data" type="application/json">__SCENARIO_JSON__</script>
<script id="impact-closure-data" type="application/json">__IMPACT_CLOSURE_JSON__</script>
<script>
(() => {
  'use strict';
  const data = JSON.parse(document.getElementById('scenario-data').textContent);
  const impactClosure = JSON.parse(document.getElementById('impact-closure-data').textContent);
  const mission = data.mission;
  const T = Number(mission.horizon_h);
  const regionKm = Number(Math.max(...data.network.nodes.map(node => Math.max(Number(node.position[0]), Number(node.position[1]))), 12));
  const depot = data.depot.position.map(Number);
  const nodes = data.relief_nodes.map((node, index) => ({
    ...node, idx: index, x: Number(node.position[0]), y: Number(node.position[1])
  }));
  const packets = data.environment_packets || [];
  const edges = data.network.edges || [];
  const margin = 46, span = 628;
  const sx = x => margin + Number(x) / regionKm * span;
  const sy = y => margin + (1 - Number(y) / regionKm) * span;
  let selected = nodes.reduce((best, node) => {
    const distance = Math.hypot(node.x - depot[0], node.y - depot[1]);
    return !best || distance > best.distance ? { node, distance } : best;
  }, null).node.id;
  let timer = null;

  const nodeById = new Map(nodes.map(node => [node.id, node]));
  const packetAt = time => packets.reduce(
    (latest, packet) => Number(packet.issued_at_h) <= time + 1e-9 ? packet : latest,
    null
  );
  const interpolate = (points, time) => {
    if (!points || !points.length) return null;
    const rows = points.map(point => [Number(point.valid_time_h), Number(point.u_kmh), Number(point.v_kmh)]);
    if (time < rows[0][0] - 1e-9 || time > rows[rows.length - 1][0] + 1e-9) return null;
    if (time <= rows[0][0]) return rows[0].slice(1);
    for (let index = 1; index < rows.length; index += 1) {
      if (time <= rows[index][0] + 1e-9) {
        const left = rows[index - 1], right = rows[index];
        const weight = (time - left[0]) / (right[0] - left[0]);
        return [left[1] + weight * (right[1] - left[1]), left[2] + weight * (right[2] - left[2])];
      }
    }
    return rows[rows.length - 1].slice(1);
  };
  const packetWind = (packet, time) => packet ? interpolate(packet.wind.points, time) : null;
  const active = (region, time) => Number(region.valid_from_h) <= time + 1e-9 &&
    (region.valid_until_h == null || time <= Number(region.valid_until_h) + 1e-9);
  const lineCross = (a, b, c) => (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
  const onSegment = (a, b, point) => Math.min(a[0], b[0]) - 1e-9 <= point[0] &&
    point[0] <= Math.max(a[0], b[0]) + 1e-9 && Math.min(a[1], b[1]) - 1e-9 <= point[1] &&
    point[1] <= Math.max(a[1], b[1]) + 1e-9;
  const segmentsIntersect = (a, b, c, d) => {
    const ab1 = lineCross(a, b, c), ab2 = lineCross(a, b, d);
    const cd1 = lineCross(c, d, a), cd2 = lineCross(c, d, b);
    if (((ab1 > 0 && ab2 < 0) || (ab1 < 0 && ab2 > 0)) &&
        ((cd1 > 0 && cd2 < 0) || (cd1 < 0 && cd2 > 0))) return true;
    return (Math.abs(ab1) < 1e-9 && onSegment(a, b, c)) ||
      (Math.abs(ab2) < 1e-9 && onSegment(a, b, d)) ||
      (Math.abs(cd1) < 1e-9 && onSegment(c, d, a)) ||
      (Math.abs(cd2) < 1e-9 && onSegment(c, d, b));
  };
  const pointInPolygon = (point, polygon) => {
    let inside = false;
    for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
      const a = polygon[i], b = polygon[j];
      if (((a[1] > point[1]) !== (b[1] > point[1])) &&
          point[0] < (b[0] - a[0]) * (point[1] - a[1]) / (b[1] - a[1]) + a[0]) inside = !inside;
    }
    return inside;
  };
  const lineHits = (a, b, polygon) => pointInPolygon(a, polygon) || pointInPolygon(b, polygon) ||
    polygon.some((point, index) => segmentsIntersect(a, b, point, polygon[(index + 1) % polygon.length]));
  const routeFor = node => {
    const edge = edges.find(item => item.origin === 'DEPOT' && item.destination === node.id);
    return edge ? edge.geometry.map(point => point.map(Number)) : [depot, [node.x, node.y]];
  };
  const regionsAt = (packet, time) => {
    if (!packet) return [];
    return [
      ...packet.weather.map(region => ({...region, region_type: 'weather'})),
      ...packet.airspace.map(region => ({...region, region_type: 'airspace'}))
    ].filter(region => active(region, time));
  };
  const routeState = (node, regions) => {
    let state = 'clear';
    const route = routeFor(node);
    for (const region of regions) {
      if (!lineHits(route[0], route[route.length - 1], region.geometry)) continue;
      if (region.region_type === 'airspace' || region.severity === 'HARD') return 'blocked';
      state = 'degraded';
    }
    return state;
  };
  const magnitude = vector => vector ? Math.hypot(vector[0], vector[1]) : NaN;
  const direction = vector => {
    if (!vector) return '—';
    let degrees = Math.atan2(vector[1], vector[0]) * 180 / Math.PI;
    if (degrees < 0) degrees += 360;
    return degrees.toFixed(0) + '° toward';
  };
  const relationship = (from, to, vector) => {
    if (!vector) return 'not covered';
    const dx = to[0] - from[0], dy = to[1] - from[1], length = Math.hypot(dx, dy) || 1;
    const along = (vector[0] * dx + vector[1] * dy) / length;
    if (Math.abs(along) < 0.3 * (magnitude(vector) || 1)) return 'crosswind';
    return along > 0 ? 'tailwind' : 'headwind';
  };
  const revisionCount = (packet, index) => {
    if (!packet || index <= 0) return 0;
    const previous = packets[index - 1];
    let count = 0;
    packet.wind.points.forEach(point => {
      if (Number(point.valid_time_h) <= Number(previous.valid_until_h) + 1e-9) {
        const before = interpolate(previous.wind.points, Number(point.valid_time_h));
        if (!before || Math.hypot(before[0] - Number(point.u_kmh), before[1] - Number(point.v_kmh)) > 1e-6) count += 1;
      }
    });
    return count + (packet.weather.length !== previous.weather.length ? 1 : 0) +
      (packet.airspace.length !== previous.airspace.length ? 1 : 0);
  };
  const rows = values => Object.entries(values).map(([key, value]) => '<dt>' + key + '</dt><dd>' + value + '</dd>').join('');
  const ns = 'http://www.w3.org/2000/svg';
  const el = (name, attrs = {}, text = '') => {
    const node = document.createElementNS(ns, name);
    Object.entries(attrs).forEach(([key, value]) => node.setAttribute(key, value));
    if (text) node.textContent = text;
    return node;
  };
  const svg = document.getElementById('map');
  const slider = document.getElementById('time');
  const timeLabel = document.getElementById('time-label');
  const play = document.getElementById('play');
  const horizonBand = document.getElementById('horizon-band');
  const timeMark = document.getElementById('time-mark');
  const horizonLabel = document.getElementById('horizon-label');
  const envValues = document.getElementById('environment-values');
  const routeValues = document.getElementById('route-values');
  const routeHeading = document.getElementById('route-heading');
  const routeNote = document.getElementById('route-note');
  const activeRegions = document.getElementById('active-regions');
  const impactPanel = document.getElementById('impact-closure');
  const formatDelta = value => value == null ? 'unknown' : (Number(value) >= 0 ? '+' : '') + Number(value).toFixed(4);
  const renderImpactClosure = () => {
    const summary = impactClosure.summary || {};
    const header = rows({
      'Previous packet': impactClosure.previous_packet_id,
      'Received packet': impactClosure.received_packet_id,
      'Directly affected legs': summary.directly_affected_leg_count,
      'Propagated legs': summary.propagated_leg_count,
      'ETA delta': formatDelta(summary.maximum_known_arrival_delta_h) + ' h'
    });
    const legs = (impactClosure.legs || []).map(leg => {
      const status = leg.directly_affected ? 'directly affected' : leg.propagated ? 'propagated' : 'unchanged';
      return '<div class="impact-leg"><strong>' + leg.leg_id + ' · ' + status + '</strong><span>' +
        'ETA delta ' + formatDelta(leg.delta_arrival_time_h) + ' h · Energy delta ' +
        formatDelta(leg.delta_energy_wh) + ' Wh · Deadline slack ' +
        formatDelta(leg.delta_deadline_slack_h) + ' h</span></div>';
    }).join('');
    impactPanel.innerHTML = '<dl class="value-grid">' + header + '</dl>' +
      (legs || '<span class="empty">No remaining incumbent legs</span>');
  };
  slider.max = String(T);
  renderImpactClosure();
  document.getElementById('meta').textContent = [
    'Scenario ' + String(data.schema_version),
    'Seed ' + String(data.metadata.seed),
    String(nodes.length) + ' known nodes',
    String(data.fleet.length) + ' UAVs',
    T.toFixed(1) + ' h horizon',
    String(packets.length) + ' environment packets',
    'hash ' + String(data.metadata.scenario_hash).slice(0, 12) + '…'
  ].join(' · ');
  const defs = el('defs');
  const marker = el('marker', {id: 'packet-arrow', markerWidth: 7, markerHeight: 7, refX: 6, refY: 3.5, orient: 'auto'});
  marker.appendChild(el('path', {d: 'M0,0 L7,3.5 L0,7 Z', fill: 'var(--packet)'}));
  defs.appendChild(marker);
  svg.appendChild(defs);
  const gridLayer = el('g'), edgeLayer = el('g'), routeLayer = el('g');
  const regionLayer = el('g'), nodeLayer = el('g'), windLayer = el('g');
  for (let value = 0; value <= regionKm + 1e-9; value += 2) {
    gridLayer.appendChild(el('line', {x1: sx(value), y1: sy(0), x2: sx(value), y2: sy(regionKm), class: 'gridline'}));
    gridLayer.appendChild(el('line', {x1: sx(0), y1: sy(value), x2: sx(regionKm), y2: sy(value), class: 'gridline'}));
    gridLayer.appendChild(el('text', {x: sx(value), y: 700, class: 'axis-label', 'text-anchor': 'middle'}, value.toFixed(0) + ' km'));
  }
  edges.forEach(edge => {
    const geometry = edge.geometry.map(point => point.map(Number));
    edgeLayer.appendChild(el('polyline', {
      points: geometry.map(point => sx(point[0]) + ',' + sy(point[1])).join(' '),
      fill: 'none', stroke: 'var(--grid)', 'stroke-width': 1
    }));
  });
  svg.append(gridLayer, edgeLayer, routeLayer, regionLayer, nodeLayer, windLayer);

  function render() {
    const time = Number(slider.value);
    const packet = packetAt(time);
    const packetIndex = packet ? packets.indexOf(packet) : -1;
    const vector = packetWind(packet, time);
    const regions = regionsAt(packet, time);
    const selectedNode = nodeById.get(selected) || nodes[0];
    timeLabel.value = time.toFixed(2) + ' h';
    timeLabel.textContent = timeLabel.value;
    timeMark.style.left = (time / T * 100) + '%';
    if (packet) {
      const first = Number(packet.valid_from_h), last = Number(packet.valid_until_h);
      horizonBand.style.left = (first / T * 100) + '%';
      horizonBand.style.width = (Math.max(0, last - first) / T * 100) + '%';
      horizonLabel.textContent = 'packet ' + packet.packet_id + ' · issued ' +
        Number(packet.issued_at_h).toFixed(1) + ' h · valid interval ' + first.toFixed(1) + '–' + last.toFixed(1) + ' h';
    } else {
      horizonBand.style.width = '0%';
      horizonLabel.textContent = 'no packet issued yet';
    }
    regionLayer.replaceChildren();
    routeLayer.replaceChildren();
    nodeLayer.replaceChildren();
    windLayer.replaceChildren();
    regions.forEach(region => {
      const polygon = region.geometry.map(point => sx(point[0]) + ',' + sy(point[1])).join(' ');
      const hard = region.region_type === 'airspace' || region.severity === 'HARD';
      regionLayer.appendChild(el('polygon', {points: polygon, class: region.region_type === 'airspace' ? 'airspace' : hard ? 'weather hard-weather' : 'weather'}));
    });
    const counts = {clear: 0, degraded: 0, blocked: 0};
    nodes.forEach(node => {
      const state = routeState(node, regions);
      counts[state] += 1;
      const geometry = routeFor(node);
      const line = el('polyline', {
        points: geometry.map(point => sx(point[0]) + ',' + sy(point[1])).join(' '),
        class: 'route ' + (node.id === selected ? 'selected' : ''),
        stroke: 'var(--' + (state === 'clear' ? 'clear' : state === 'degraded' ? 'soft' : 'blocked') + ')',
        'aria-label': 'Node ' + String(node.idx + 1) + ': ' + state
      });
      line.addEventListener('click', () => { selected = node.id; render(); });
      routeLayer.appendChild(line);
      const group = el('g');
      const circle = el('circle', {cx: sx(node.x), cy: sy(node.y), r: 13, class: 'node ' + (node.id === selected ? 'selected' : '')});
      circle.addEventListener('click', () => { selected = node.id; render(); });
      group.append(circle, el('text', {x: sx(node.x), y: sy(node.y), class: 'node-label'}, String(node.idx + 1)));
      nodeLayer.appendChild(group);
    });
    nodeLayer.appendChild(el('rect', {x: sx(depot[0]) - 10, y: sy(depot[1]) - 10, width: 20, height: 20, transform: 'rotate(45 ' + sx(depot[0]) + ' ' + sy(depot[1]) + ')', class: 'depot'}));
    nodeLayer.appendChild(el('text', {x: sx(depot[0]) + 16, y: sy(depot[1]) - 13, class: 'wind-label'}, 'Depot'));
    if (vector) {
      const x = 90, y = 88, scale = 3.2;
      windLayer.appendChild(el('line', {x1: x, y1: y, x2: x + vector[0] * scale, y2: y - vector[1] * scale, class: 'wind-arrow', 'marker-end': 'url(#packet-arrow)'}));
      windLayer.appendChild(el('text', {x: x, y: y + 19, class: 'wind-label'}, 'Current authoritative wind ' + magnitude(vector).toFixed(1) + ' km/h'));
    }
    envValues.innerHTML = rows({
      'Packet': packet ? packet.packet_id : 'none',
      'Current wind': vector ? magnitude(vector).toFixed(1) + ' km/h' : 'not covered',
      'Direction': direction(vector),
      'Packet revision': packetIndex > 0 ? String(revisionCount(packet, packetIndex)) + ' overlapping changes' : 'initial packet',
      'Clear / soft / blocked': counts.clear + ' / ' + counts.degraded + ' / ' + counts.blocked
    });
    const state = routeState(selectedNode, regions);
    const route = routeFor(selectedNode);
    let length = 0;
    for (let index = 1; index < route.length; index += 1) length += Math.hypot(route[index][0] - route[index - 1][0], route[index][1] - route[index - 1][1]);
    routeHeading.textContent = 'Depot → ' + selectedNode.id;
    routeValues.innerHTML = rows({
      'Geometry state': state,
      'Directed distance': length.toFixed(2) + ' km',
      'Wind relation': relationship(depot, [selectedNode.x, selectedNode.y], vector),
      'Packet issued': packet ? Number(packet.issued_at_h).toFixed(2) + ' h' : 'not issued'
    });
    routeNote.textContent = state === 'blocked' ? 'The directed corridor intersects a hard packet region.' :
      state === 'degraded' ? 'The directed corridor intersects soft weather.' :
      packet ? 'The directed corridor is clear in the current packet geometry.' : 'No environmental packet is available yet.';
    activeRegions.innerHTML = regions.length ? regions.map(region =>
      region.id + ' · ' + (region.region_type === 'airspace' ? 'blocked airspace' : region.severity === 'HARD' ? 'blocked weather' : 'soft weather')
    ).join('<br>') : '<span class="empty">None at this time</span>';
  }
  slider.addEventListener('input', render);
  play.addEventListener('click', () => {
    if (timer) {
      clearInterval(timer); timer = null; play.textContent = 'Play'; play.setAttribute('aria-pressed', 'false'); return;
    }
    play.textContent = 'Pause'; play.setAttribute('aria-pressed', 'true');
    timer = setInterval(() => {
      let next = Number(slider.value) + 0.05;
      if (next > T) next = 0;
      slider.value = String(next); render();
    }, 80);
  });
  render();
})();
</script>
</body>
</html>
"""


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Render a canonical packet scenario inspection page."
    )
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    return parser


def main() -> int:
    args = _parser().parse_args()
    raw = json.loads(args.input.read_text(encoding="utf-8"))
    scenario = Scenario.from_dict(raw)
    scenario_hash = scenario.content_hash()
    embedded_hash = (raw.get("metadata") or {}).get("scenario_hash")
    if embedded_hash is not None and embedded_hash != scenario_hash:
        raise ValueError("scenario metadata scenario_hash does not match its payload")
    payload = scenario.to_dict()
    serialized = json.dumps(payload, separators=(",", ":"), ensure_ascii=True)
    serialized = serialized.replace("</", "<" + chr(92) + "/")
    closure_serialized = json.dumps(
        _controlled_impact_closure(scenario),
        separators=(",", ":"),
        ensure_ascii=True,
    )
    closure_serialized = closure_serialized.replace("</", "<" + chr(92) + "/")
    html = HTML_TEMPLATE.replace("__SCENARIO_JSON__", serialized)
    html = html.replace("__IMPACT_CLOSURE_JSON__", closure_serialized)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(html, encoding="utf-8")
    print(f"scenario_hash={scenario_hash}")
    print(f"output={args.output.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
