"""Run a deterministic fixed mission and print a physics/accounting report."""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from env.fixed_plan import execute_fixed_plan  # noqa: E402
from env.scenario import Scenario  # noqa: E402


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Verify canonical UAV physics with a deterministic fixed plan."
    )
    parser.add_argument(
        "--scenario",
        type=Path,
        default=ROOT / "scenarios" / "information_aware" / "seed_42.json",
    )
    return parser


def _seed_plan(scenario: Scenario) -> dict:
    node = scenario.nodes[0]
    quantity = [0.0] * 4
    quantity[0] = min(1.0, node.demand[0])
    node_id = f"NODE-{node.idx:03d}"
    return {
        "UAV-00": {
            "route": ["DEPOT", node_id, "DEPOT"],
            "load": quantity,
            "deliveries": {node_id: quantity},
        }
    }


def _analytical_checks(speed_kmh: float) -> dict:
    crosswind = 12.0
    return {
        "units": {
            "distance": "km",
            "time": "h",
            "speed": "km/h",
            "mass": "kg",
            "energy": "Wh",
        },
        "zero_wind_ground_speed_kmh": speed_kmh,
        "tailwind_plus_12_ground_speed_kmh": speed_kmh + 12.0,
        "headwind_minus_12_ground_speed_kmh": speed_kmh - 12.0,
        "crosswind_12_ground_speed_kmh": math.sqrt(speed_kmh ** 2 - crosswind ** 2),
        "crosswind_domain_check": abs(crosswind) < speed_kmh,
    }


def main() -> int:
    args = _parser().parse_args()
    scenario_path = args.scenario.resolve()
    scenario = Scenario.from_json(scenario_path)
    scenario_hash_before = scenario.content_hash()
    plan = _seed_plan(scenario)
    result = execute_fixed_plan(scenario, plan)
    scenario_hash_after = scenario.content_hash()
    if not result.completed:
        print(json.dumps(result.to_dict(), indent=2, sort_keys=True))
        return 1

    completion_times = [
        float(event["arrival_time_h"])
        for event in result.flight_events
    ] + [
        float(event["time_h"])
        for event in result.event_log["deliveries"]
    ]
    vehicle = scenario.fleet[0]
    report = {
        "scenario": str(scenario_path),
        "scenario_hash_before": scenario_hash_before,
        "scenario_hash_after": scenario_hash_after,
        "completed": result.completed,
        "termination_reason": result.termination_reason,
        "completion_time_h": max(completion_times, default=0.0),
        "legs": list(result.flight_events),
        "deliveries": list(result.event_log["deliveries"]),
        "battery_payload_trajectories": [
            {
                "uav": int(event["uav"]),
                "departure_time_h": event["departure_time_h"],
                "arrival_time_h": event["arrival_time_h"],
                "battery_before": event["battery_before"],
                "battery_after": event["battery_after"],
                "payload_before": event["payload_before"],
                "payload_after": event["payload_after"],
            }
            for event in result.flight_events
        ],
        "packets_encountered": list(result.environment_packets_encountered),
        "weather_states": [event["weather_state"] for event in result.flight_events],
        "airspace_states": [event["airspace_state"] for event in result.flight_events],
        "reserve": {
            "requirement_wh": vehicle.reserve_requirement_wh,
            "final_margin_wh": result.final_reserve_margin_wh,
        },
        "total_travel_time_h": result.total_travel_time_h,
        "total_energy_wh": result.total_energy_wh,
        "conservation": result.conservation,
        "analytical_checks": _analytical_checks(vehicle.nominal_airspeed_kmh),
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if scenario_hash_before == scenario_hash_after else 1


if __name__ == "__main__":
    raise SystemExit(main())
