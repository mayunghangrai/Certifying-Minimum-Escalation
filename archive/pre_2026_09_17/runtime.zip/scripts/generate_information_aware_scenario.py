"""Generate one replayable information-aware route-planning scenario."""

from __future__ import annotations

import argparse
import dataclasses
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from env.robust_scenario_generator import (  # noqa: E402
    generate_information_aware_scenario,
    load_information_aware_config,
)


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Generate a known-demand scenario with evolving route information."
    )
    parser.add_argument("--seed", required=True, type=int)
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument(
        "--mode",
        choices=("static", "weather", "airspace", "mixed"),
        help="Override the disruption mode in the YAML profile.",
    )
    return parser


def main() -> int:
    args = _parser().parse_args()
    params, route_information, _objective = load_information_aware_config(
        args.config
    )
    if args.mode is not None:
        route_information = dataclasses.replace(route_information, mode=args.mode)
    scenario = generate_information_aware_scenario(
        args.seed, params, route_information
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    scenario.to_json(str(args.output))
    print(f"scenario_hash={scenario.content_hash()}")
    print(
        f"nodes={len(scenario.nodes)} "
        f"uavs={scenario.env_params().mission.M} "
        f"horizon_h={scenario.env_params().mission.T:g}"
    )
    print(f"output={args.output.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
