"""Analytical contracts for the shared UAV leg-physics layer."""

from __future__ import annotations

import math

import pytest

import env.energy as energy
from env.entities import UAVParameters
from env.environment import EnvironmentalPacket
from env.network import NetworkEdge
from env.params import EnvParams, MissionParams
from env.route_evaluator import evaluate_route
from env.wind import WindForecastPoint


def _uav(speed: float = 60.0) -> UAVParameters:
    return UAVParameters(
        id="UAV-00",
        nominal_airspeed_kmh=speed,
        empty_mass_kg=4.0,
        max_payload_kg=5.0,
        battery_capacity_wh=230.0,
        reserve_requirement_wh=23.0,
        energy_coefficient_wh_per_km_kg=3.125,
        service_energy_wh=2.5,
    )


def _packet(
    vectors=((0.0, 0.0), (0.0, 0.0)),
    times=(0.0, 4.0),
) -> EnvironmentalPacket:
    return EnvironmentalPacket(
        packet_id="TEST-ENV",
        issued_at_h=float(times[0]),
        valid_from_h=float(times[0]),
        valid_until_h=float(times[-1]),
        wind=tuple(
            WindForecastPoint(time, vector[0], vector[1])
            for time, vector in zip(times, vectors)
        ),
    )


@pytest.fixture
def east_edge() -> NetworkEdge:
    return NetworkEdge("AB", "A", "B", ((0.0, 0.0), (2.0, 0.0)))


def test_leg_result_exposes_complete_physical_record(east_edge):
    result = energy.evaluate_leg(east_edge, 0.25, 1.0, _uav(), _packet())

    assert result.feasible is True
    assert result.departure_time_h == pytest.approx(0.25)
    assert result.arrival_time_h == pytest.approx(0.25 + 2.0 / 60.0)
    assert result.airspeed_kmh == pytest.approx(60.0)
    assert result.payload_mass_kg == pytest.approx(1.0)
    assert result.power_w == pytest.approx(3.125 * 5.0 * 60.0)
    assert result.packet_id == "TEST-ENV"
    assert result.diagnostics["direction_xy"] == pytest.approx((1.0, 0.0))
    assert result.diagnostics["packet_id"] == "TEST-ENV"


def test_seconds_to_wh_is_explicit():
    convert = getattr(energy, "seconds_to_wh", None)
    assert callable(convert)
    assert convert(10.0, 360.0) == pytest.approx(1.0)


def test_directed_edge_direction_reverses():
    forward = NetworkEdge("AB", "A", "B", ((0.0, 0.0), (3.0, 4.0)))
    reverse = NetworkEdge("BA", "B", "A", ((3.0, 4.0), (0.0, 0.0)))
    direction = getattr(energy, "edge_direction_xy", None)
    assert callable(direction)
    forward_direction = direction(forward)
    reverse_direction = direction(reverse)
    assert forward_direction == pytest.approx((-reverse_direction[0], -reverse_direction[1]))


@pytest.mark.parametrize(
    "wind, expected_speed",
    [
        ((0.0, 0.0), 60.0),
        ((12.0, 0.0), 72.0),
        ((-12.0, 0.0), 48.0),
        ((0.0, 12.0), math.sqrt(60.0**2 - 12.0**2)),
    ],
)
def test_analytical_ground_speed(east_edge, wind, expected_speed):
    result = energy.evaluate_leg(
        east_edge,
        0.0,
        0.0,
        _uav(),
        _packet((wind, wind)),
    )
    assert result.feasible is True
    assert result.ground_speed_kmh == pytest.approx(expected_speed)


def test_crosswind_at_airspeed_is_not_clamped(east_edge):
    result = energy.evaluate_leg(
        east_edge,
        0.0,
        0.0,
        _uav(speed=10.0),
        _packet(((0.0, 10.0), (0.0, 10.0))),
    )
    reason_type = getattr(energy, "InfeasibilityReason", None)
    assert reason_type is not None
    reason = reason_type.CROSSWIND_EXCEEDS_AIRSPEED
    assert result.feasible is False
    assert result.reason == reason


def test_stalled_headwind_has_canonical_reason(east_edge):
    result = energy.evaluate_leg(
        east_edge,
        0.0,
        0.0,
        _uav(speed=10.0),
        _packet(((-10.0, 0.0), (-10.0, 0.0))),
    )
    reason_type = getattr(energy, "InfeasibilityReason", None)
    assert reason_type is not None
    reason = reason_type.NONPOSITIVE_GROUND_PROGRESS
    assert result.feasible is False
    assert result.reason == reason


def test_crosswind_greater_than_airspeed_is_infeasible(east_edge):
    result = energy.evaluate_leg(
        east_edge,
        0.0,
        0.0,
        _uav(speed=10.0),
        _packet(((0.0, 10.1), (0.0, 10.1))),
    )
    assert result.feasible is False
    assert result.reason_code.value == "CROSSWIND_EXCEEDS_AIRSPEED"


def test_invalid_edge_has_a_standardized_reason():
    result = energy.evaluate_leg(
        {"geometry": ((0.0, 0.0), (0.0, 0.0))},
        0.0,
        0.0,
        _uav(),
        _packet(),
    )
    assert result.feasible is False
    assert result.reason_code is energy.InfeasibilityReason.INVALID_EDGE


def test_directional_wind_components_reverse_sign(east_edge):
    reverse = NetworkEdge("BA", "B", "A", ((2.0, 0.0), (0.0, 0.0)))
    forward = energy.evaluate_leg(
        east_edge,
        0.0,
        0.0,
        _uav(),
        _packet(((12.0, 4.0), (12.0, 4.0))),
    )
    backward = energy.evaluate_leg(
        reverse,
        0.0,
        0.0,
        _uav(),
        _packet(((12.0, 4.0), (12.0, 4.0))),
    )
    assert backward.along_track_wind_kmh == pytest.approx(
        -forward.along_track_wind_kmh
    )
    assert backward.travel_time_h != pytest.approx(forward.travel_time_h)


def test_leg_diagnostics_account_for_each_temporal_segment(east_edge):
    edge = NetworkEdge("LONG", "A", "B", ((0.0, 0.0), (100.0, 0.0)))
    packet = _packet(
        vectors=((0.0, 0.0), (0.0, 0.0), (20.0, 0.0), (20.0, 0.0)),
        times=(0.0, 0.5, 1.0, 2.0),
    )
    result = energy.evaluate_leg(edge, 0.0, 0.0, _uav(), packet)
    segments = result.diagnostics["segments"]
    assert len(segments) >= 2
    assert sum(segment["distance_km"] for segment in segments) == pytest.approx(100.0)
    assert sum(segment["duration_h"] for segment in segments) == pytest.approx(
        result.travel_time_h
    )


def test_partial_state_uses_segment_distance_not_elapsed_time_fraction():
    packet = _packet(
        vectors=((0.0, 0.0), (0.0, 0.0), (20.0, 0.0)),
        times=(0.0, 0.5, 1.0),
    )
    position, distance, energy_wh, now = energy.route_state_at(
        ((0.0, 0.0), (100.0, 0.0)),
        0.0,
        0.75,
        0.0,
        _uav(),
        packet,
    )

    assert distance == pytest.approx(46.25, abs=1e-9)
    assert position[0] == pytest.approx(distance)
    assert energy_wh == pytest.approx(energy.nominal_power(0.0, _uav()) * 0.75)
    assert now == pytest.approx(0.75)


def test_route_exposes_horizon_failure_as_a_hard_reason_code():
    params = EnvParams(mission=MissionParams(T=0.01))
    result = evaluate_route(
        ((0.0, 0.0), (2.0, 0.0)),
        0.0,
        0.0,
        230.0,
        None,
        None,
        params,
        environmental_packet=_packet(),
        uav_parameters=_uav(),
    )

    assert result.feasible is False
    assert "MISSION_HORIZON_EXCEEDED" in result.reason_codes
    assert result.failure_reason == "MISSION_HORIZON_EXCEEDED"
    assert result.reserve_margin_wh == pytest.approx(182.0)


def test_route_reports_payload_capacity_as_a_hard_reason_code():
    result = evaluate_route(
        ((0.0, 0.0), (2.0, 0.0)),
        0.0,
        6.0,
        230.0,
        None,
        None,
        EnvParams(),
        environmental_packet=_packet(),
        uav_parameters=_uav(),
    )

    assert result.feasible is False
    assert "PAYLOAD_CAPACITY_EXCEEDED" in result.reason_codes


def test_safe_return_margin_uses_fixed_wh_reserve():
    margin = energy.safe_return_margin_wh(40.0, 20.0, 23.0)
    assert margin == pytest.approx(-3.0)

    result = energy.evaluate_safe_return(
        (0.0, 0.0),
        (2.0, 0.0),
        0.0,
        0.0,
        40.0,
        _uav(),
        _packet(),
        service_energy_wh=0.0,
    )
    assert result.feasible is False
    assert result.reason == energy.InfeasibilityReason.SAFE_RETURN_RESERVE_VIOLATION
    assert result.reserve_margin_wh < 0.0
