"""Non-anticipative disturbance-impact closure contracts."""

from __future__ import annotations

import json
from dataclasses import replace

import numpy as np
import pytest

from env.diagnostics import diagnose_environmental_packet_update
from env.environment import EnvironmentalPacket, WeatherRegion
from env.entities import Mode
from env.params import EnvParams
from env.scenario import Scenario, ScenarioNode
from env.simulator import (
    DemandNodeSnapshot,
    EnvironmentSnapshot,
    UAVSnapshot,
)
from env.wind import WindForecastPoint


PLAN = {
    "UAV-00": {
        "route": ["DEPOT", "NODE-000", "DEPOT"],
        "load": [1.0, 0.0, 0.0, 0.0],
        "deliveries": {"NODE-000": [1.0, 0.0, 0.0, 0.0]},
    },
}


def _packet(packet_id: str, issued_at_h: float, wind=(0.0, 0.0)):
    valid_until_h = issued_at_h + 1.5
    return EnvironmentalPacket(
        packet_id=packet_id,
        issued_at_h=issued_at_h,
        valid_from_h=issued_at_h,
        valid_until_h=valid_until_h,
        wind=(
            WindForecastPoint(issued_at_h, wind[0], wind[1]),
            WindForecastPoint(valid_until_h, wind[0], wind[1]),
        ),
    )


def make_fixture():
    params = EnvParams()
    params.map.n_nodes = 1
    params.map.n_clusters = 1
    params.mission.T = 2.0
    params.mission.M = 1
    params = EnvParams.from_dict(params.to_dict())
    scenario = Scenario(
        seed=7,
        params=params.to_dict(),
        depot=[0.0, 0.0],
        nodes=[ScenarioNode(0, 2.0, 0.0, 1.0, [1.0, 0.0, 0.0, 0.0])],
        initial_inventory=[1.0, 0.0, 0.0, 0.0],
        environment_packets=[
            _packet("ENV-OLD", 0.0),
            _packet("ENV-RECEIVED", 0.5, wind=(8.0, 0.0)),
            _packet("ENV-FUTURE", 1.0, wind=(-50.0, 0.0)),
        ],
        generation_metadata={"schema": "information-aware-routing-v3"},
    )
    previous = scenario.environment_packets[0]
    received = scenario.environment_packets[1]
    epoch = EnvironmentSnapshot(
        time_h=0.5,
        nodes=(DemandNodeSnapshot(
            idx=0,
            position=np.asarray([2.0, 0.0]),
            vulnerability=1.0,
            priority=1.0,
            remaining_demand=np.asarray([1.0, 0.0, 0.0, 0.0]),
        ),),
        uavs=(UAVSnapshot(
            idx=0,
            position=np.asarray([0.0, 0.0]),
            battery=230.0,
            payload=np.zeros(4),
            mode=Mode.DEPOT,
            current_node=None,
            destination=None,
            active_route=None,
        ),),
        inventory=np.asarray([1.0, 0.0, 0.0, 0.0]),
        airspace_version=0,
        airspace_regions=(),
        wind_forecast=None,
        environment_packet=received,
        event_type=None,
        terminated=False,
    )
    return scenario, epoch, previous, received


def replace_packet(packet: EnvironmentalPacket, *, issued_at_h: float):
    return _packet(
        f"{packet.packet_id}-FUTURE",
        issued_at_h,
        wind=(0.0, 0.0),
    )


def _temporary_revision_packets():
    previous = EnvironmentalPacket(
        packet_id="ENV-OLD",
        issued_at_h=0.0,
        valid_from_h=0.0,
        valid_until_h=1.5,
        wind=(
            WindForecastPoint(0.0, 0.0, 0.0),
            WindForecastPoint(1.5, 0.0, 0.0),
        ),
    )
    received = EnvironmentalPacket(
        packet_id="ENV-RECEIVED",
        issued_at_h=0.5,
        valid_from_h=0.5,
        valid_until_h=2.0,
        wind=(
            WindForecastPoint(0.5, 0.0, 0.0),
            WindForecastPoint(0.52, -12.0, 0.0),
            WindForecastPoint(0.55, 0.0, 0.0),
            WindForecastPoint(2.0, 0.0, 0.0),
        ),
    )
    return previous, received


def _in_flight_epoch(scenario, position, committed_route, destination):
    return EnvironmentSnapshot(
        time_h=0.5,
        nodes=tuple(
            DemandNodeSnapshot(
                idx=node.idx,
                position=np.asarray([node.x, node.y]),
                vulnerability=node.vulnerability,
                priority=node.priority,
                remaining_demand=np.asarray(node.demand),
            )
            for node in scenario.nodes
        ),
        uavs=(UAVSnapshot(
            idx=0,
            position=np.asarray(position, dtype=float),
            battery=230.0,
            payload=np.array([1.0, 0.0, 0.0, 0.0]),
            mode=Mode.FLYING,
            current_node=None,
            destination=destination,
            active_route=np.asarray(committed_route, dtype=float),
            committed_route=np.asarray(committed_route, dtype=float),
            committed_destination=destination,
        ),),
        inventory=np.asarray(scenario.initial_inventory),
        airspace_version=0,
        airspace_regions=(),
        wind_forecast=None,
        environment_packet=scenario.environment_packets[1],
        event_type=None,
        terminated=False,
    )


def make_in_flight_fixture():
    scenario, _epoch, _previous, _received = make_fixture()
    previous, received = _temporary_revision_packets()
    scenario.environment_packets = [previous, received]
    scenario.nodes[0].x = 2.0
    scenario.nodes[0].y = 0.0
    epoch = _in_flight_epoch(
        scenario,
        position=[1.0, 0.0],
        committed_route=[[1.0, 0.0], [2.0, 0.0]],
        destination=0,
    )
    return scenario, epoch, previous, received


MULTI_LEG_PLAN = PLAN


def make_three_leg_fixture():
    scenario, epoch, previous, received = make_in_flight_fixture()
    epoch = EnvironmentSnapshot(
        time_h=epoch.time_h,
        nodes=epoch.nodes,
        uavs=(UAVSnapshot(
            idx=0,
            position=np.asarray([0.0, 0.0]),
            battery=230.0,
            payload=np.zeros(4),
            mode=Mode.DEPOT,
            current_node=None,
            destination=None,
            active_route=None,
            committed_route=None,
            committed_destination=None,
        ),),
        inventory=epoch.inventory,
        airspace_version=epoch.airspace_version,
        airspace_regions=epoch.airspace_regions,
        wind_forecast=epoch.wind_forecast,
        environment_packet=epoch.environment_packet,
        event_type=epoch.event_type,
        terminated=epoch.terminated,
    )
    return scenario, epoch, previous, received


def test_packet_update_requires_both_packets_to_be_visible_at_the_epoch():
    scenario, epoch, previous, received = make_fixture()
    future = replace_packet(received, issued_at_h=epoch.time_h + 0.1)

    with pytest.raises(ValueError, match="visible"):
        diagnose_environmental_packet_update(
            scenario, PLAN, epoch, previous, future
        )


def test_packet_update_identity_includes_packet_contents_not_only_packet_id():
    scenario, epoch, previous, received = make_fixture()
    same_id_different_content = replace(
        received,
        wind=(
            WindForecastPoint(received.valid_from_h, 9.0, 0.0),
            WindForecastPoint(received.valid_until_h, 9.0, 0.0),
        ),
    )

    with pytest.raises(ValueError, match="does not match"):
        diagnose_environmental_packet_update(
            scenario,
            PLAN,
            epoch,
            previous,
            same_id_different_content,
        )


def test_closure_serializes_to_json_compatible_values_without_future_timeline_data():
    scenario, epoch, previous, received = make_fixture()
    closure = diagnose_environmental_packet_update(
        scenario, PLAN, epoch, previous, received
    )

    payload = closure.to_dict()
    json.dumps(payload, allow_nan=False)
    assert payload["non_anticipative"] is True
    assert payload["previous_packet_id"] == previous.packet_id
    assert payload["received_packet_id"] == received.packet_id
    assert "environment_packets" not in json.dumps(payload)
    assert "truth_keyframes" not in json.dumps(payload)


def test_diagnostic_uses_committed_active_remainder_and_declared_suffix():
    scenario, epoch, previous, received = make_in_flight_fixture()

    closure = diagnose_environmental_packet_update(
        scenario, MULTI_LEG_PLAN, epoch, previous, received
    )

    assert [leg.destination for leg in closure.legs] == [
        "NODE-000", "DEPOT"
    ]
    assert closure.legs[0].geometry[0] == pytest.approx(
        tuple(epoch.uavs[0].position)
    )


def test_diagnostic_clips_a_full_active_polyline_to_the_flying_epoch_position():
    scenario, _epoch, previous, received = make_fixture()
    epoch = _in_flight_epoch(
        scenario,
        position=[1.0, 0.0],
        committed_route=[[0.0, 0.0], [2.0, 0.0]],
        destination=0,
    )

    closure = diagnose_environmental_packet_update(
        scenario, PLAN, epoch, previous, received
    )

    assert closure.legs[0].geometry == ((1.0, 0.0), (2.0, 0.0))


def test_packet_revision_marks_direct_leg_and_propagates_eta_energy_deadline_effects():
    scenario, epoch, previous, received = make_three_leg_fixture()
    closure = diagnose_environmental_packet_update(
        scenario,
        MULTI_LEG_PLAN,
        epoch,
        previous,
        received,
        deadlines_h={"DEPOT": 0.62},
    )

    direct = [leg for leg in closure.legs if leg.directly_affected]
    propagated = [leg for leg in closure.legs if leg.propagated]
    assert direct
    assert propagated
    assert all(not leg.directly_affected for leg in propagated)
    assert closure.summary["directly_affected_leg_count"] == len(direct)
    assert closure.legs[-1].delta_arrival_time_h is not None
    assert closure.legs[-1].delta_energy_wh is not None
    assert closure.legs[-1].revised.deadline_slack_h == pytest.approx(
        0.62 - closure.legs[-1].revised.arrival_time_h
    )
    assert closure.legs[0].payload_mass_kg == pytest.approx(0.25)
    assert closure.legs[1].payload_mass_kg == pytest.approx(0.0)


def test_region_revision_marks_only_a_remaining_leg_with_temporal_and_geometry_overlap():
    scenario, epoch, _previous, _received = make_fixture()
    off_route = WeatherRegion(
        "controlled-zone",
        ((0.5, 0.5), (1.5, 0.5), (1.5, 1.5), (0.5, 1.5)),
        "SOFT",
        0.5,
        0.545,
    )
    on_route = WeatherRegion(
        "controlled-zone",
        ((0.5, -0.1), (1.5, -0.1), (1.5, 0.1), (0.5, 0.1)),
        "SOFT",
        0.5,
        0.545,
    )
    previous = EnvironmentalPacket(
        packet_id="ENV-REGION-OLD",
        issued_at_h=0.0,
        valid_from_h=0.0,
        valid_until_h=1.5,
        wind=(WindForecastPoint(0.0, 0.0, 0.0), WindForecastPoint(1.5, 0.0, 0.0)),
        weather=(off_route,),
    )
    received = EnvironmentalPacket(
        packet_id="ENV-REGION-RECEIVED",
        issued_at_h=0.5,
        valid_from_h=0.5,
        valid_until_h=1.5,
        wind=(WindForecastPoint(0.5, 0.0, 0.0), WindForecastPoint(1.5, 0.0, 0.0)),
        weather=(on_route,),
    )
    epoch = replace(epoch, environment_packet=received)

    closure = diagnose_environmental_packet_update(
        scenario, PLAN, epoch, previous, received
    )

    assert closure.legs[0].directly_affected
    assert closure.legs[0].direct_changes[0].domain == "weather"
    assert not closure.legs[1].directly_affected


def test_uncovered_revision_reports_unknown_coverage_and_does_not_repair_suffix():
    scenario, epoch, previous, _received = make_fixture()
    received = EnvironmentalPacket(
        packet_id="ENV-SHORT",
        issued_at_h=0.5,
        valid_from_h=0.5,
        valid_until_h=0.52,
        wind=(WindForecastPoint(0.5, 0.0, 0.0), WindForecastPoint(0.52, 0.0, 0.0)),
    )
    epoch = replace(epoch, environment_packet=received)

    closure = diagnose_environmental_packet_update(
        scenario, PLAN, epoch, previous, received
    )

    assert closure.legs[0].revised.reason == "INVALID_ENVIRONMENTAL_COVERAGE"
    assert closure.legs[1].revised.reason == "UPSTREAM_PROPAGATION_UNKNOWN"
    assert closure.legs[0].revised.status.value == "undetermined"
    assert closure.legs[1].revised.status.value == "undetermined"
    assert closure.legs[0].directly_affected is True
    assert any(
        change.domain == "coverage"
        for change in closure.legs[0].direct_changes
    )
    assert closure.legs[0].geometry == ((0.0, 0.0), (2.0, 0.0))


def test_repeated_route_stop_uses_the_declared_current_route_occurrence():
    params = EnvParams()
    params.map.n_nodes = 2
    params.map.n_clusters = 1
    params.mission.T = 2.0
    params.mission.M = 1
    params = EnvParams.from_dict(params.to_dict())
    scenario = Scenario(
        seed=11,
        params=params.to_dict(),
        depot=[0.0, 0.0],
        nodes=[
            ScenarioNode(0, 2.0, 0.0, 1.0, [1.0, 0.0, 0.0, 0.0]),
            ScenarioNode(1, 3.0, 0.0, 1.0, [1.0, 0.0, 0.0, 0.0]),
        ],
        initial_inventory=[1.0, 0.0, 0.0, 0.0],
        environment_packets=[
            _packet("ENV-OLD", 0.0),
            _packet("ENV-RECEIVED", 0.5, wind=(8.0, 0.0)),
        ],
        generation_metadata={"schema": "information-aware-routing-v3"},
    )
    epoch = EnvironmentSnapshot(
        time_h=0.5,
        nodes=tuple(
            DemandNodeSnapshot(
                idx=node.idx,
                position=np.asarray([node.x, node.y]),
                vulnerability=node.vulnerability,
                priority=node.priority,
                remaining_demand=np.asarray(node.demand),
            )
            for node in scenario.nodes
        ),
        uavs=(UAVSnapshot(
            idx=0,
            position=np.asarray([2.0, 0.0]),
            battery=230.0,
            payload=np.zeros(4),
            mode=Mode.AT_NODE,
            current_node=0,
            destination=None,
            active_route=None,
        ),),
        inventory=np.asarray(scenario.initial_inventory),
        airspace_version=0,
        airspace_regions=(),
        wind_forecast=None,
        environment_packet=scenario.environment_packets[1],
        event_type=None,
        terminated=False,
    )
    plan = {
        "UAV-00": {
            "route": [
                "DEPOT",
                "NODE-000",
                "NODE-001",
                "NODE-000",
                "DEPOT",
            ],
            "current_route_index": 3,
            "load": [0.0, 0.0, 0.0, 0.0],
            "deliveries": {},
            "leg_geometries": {
                1: [[2.0, 0.0], [3.0, 0.0]],
                2: [[3.0, 0.0], [2.0, 0.0]],
            },
        },
    }

    closure = diagnose_environmental_packet_update(
        scenario,
        plan,
        epoch,
        scenario.environment_packets[0],
        scenario.environment_packets[1],
    )

    assert [leg.route_index for leg in closure.legs] == [3]
    assert [leg.destination for leg in closure.legs] == ["DEPOT"]


def test_repeated_depot_stop_is_rejected_without_a_route_cursor():
    scenario, epoch, previous, received = make_fixture()
    epoch = replace(
        epoch,
        uavs=(replace(
            epoch.uavs[0],
            position=np.asarray([0.0, 0.0]),
            mode=Mode.DEPOT,
            current_node=None,
        ),),
    )
    plan = {
        "UAV-00": {
            "route": ["DEPOT", "NODE-000", "DEPOT", "NODE-000", "DEPOT"],
            "load": [0.0, 0.0, 0.0, 0.0],
            "deliveries": {},
        },
    }

    with pytest.raises(ValueError, match="ambiguous"):
        diagnose_environmental_packet_update(
            scenario,
            plan,
            epoch,
            previous,
            received,
        )


def test_dependency_graph_separates_structural_material_and_reportable_sets():
    scenario, epoch, previous, received = make_fixture()

    closure = diagnose_environmental_packet_update(
        scenario, PLAN, epoch, previous, received
    )

    graph = closure.dependency_graph
    assert {vertex.kind for vertex in graph.vertices} >= {
        "packet_change",
        "environment",
        "state",
        "evaluator",
        "quantity",
        "status",
    }
    structural = set(graph.structural_closure_vertex_ids)
    material = set(graph.material_vertex_ids)
    seeds = set(graph.seed_vertex_ids)
    assert seeds <= structural
    assert material <= structural
    assert set(graph.reportable_vertex_ids) == seeds | material
    assert graph.is_acyclic is True


def test_direct_and_propagated_influence_can_coexist_on_one_leg():
    scenario, epoch, previous, received = make_fixture()

    closure = diagnose_environmental_packet_update(
        scenario, PLAN, epoch, previous, received
    )

    assert len(closure.legs) == 2
    second = closure.legs[1]
    assert second.directly_affected is True
    assert second.propagated is True
    assert closure.affected_task_ids == ("NODE-000",)
    assert "DEPOT" not in closure.affected_task_ids
