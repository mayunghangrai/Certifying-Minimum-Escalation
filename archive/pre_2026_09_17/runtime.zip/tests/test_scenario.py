"""Lean scenario serialization, validation, and seeded placement."""

from __future__ import annotations

import json

import numpy as np
import pytest

from env.energy import max_service_radius
from env.params import EnvParams
from env.robust_scenario_generator import generate_information_aware_scenario
from env.scenario import Scenario


@pytest.fixture(scope="module")
def scenario():
    return generate_information_aware_scenario(42)


def test_same_seed_is_identical_and_different_seed_changes_tasks(scenario):
    repeated = generate_information_aware_scenario(42)
    different = generate_information_aware_scenario(43)

    assert repeated.content_hash() == scenario.content_hash()
    assert repeated.nodes == scenario.nodes
    assert different.nodes != scenario.nodes


def test_nodes_are_inside_conservative_service_radius_and_map(scenario):
    params = scenario.env_params()
    radius = max_service_radius(params.physics, conservative=True)
    depot = np.asarray(scenario.depot)
    for node in scenario.nodes:
        position = np.array([node.x, node.y])
        assert np.linalg.norm(position - depot) <= radius + 1e-9
        assert np.all(position >= 0.0)
        assert np.all(position <= params.map.region_km)


def test_inventory_exactly_matches_known_initial_demand(scenario):
    expected = np.sum([node.demand for node in scenario.nodes], axis=0)
    np.testing.assert_allclose(scenario.initial_inventory, expected)


def test_json_round_trip_preserves_hash_and_rejects_schema_drift(scenario, tmp_path):
    path = tmp_path / "scenario.json"
    scenario.to_json(path)
    loaded = Scenario.from_json(path)
    assert loaded.content_hash() == scenario.content_hash()

    payload = json.loads(path.read_text(encoding="utf-8"))
    payload["unexpected"] = True
    with pytest.raises(ValueError, match="unknown keys"):
        Scenario.from_dict(payload)
    payload.pop("unexpected")
    payload.pop("relief_nodes")
    with pytest.raises(ValueError, match="missing keys"):
        Scenario.from_dict(payload)


def test_content_hash_excludes_only_the_embedded_hash(scenario):
    payload = scenario.to_dict()
    payload["metadata"]["scenario_hash"] = scenario.content_hash()
    restored = Scenario.from_dict(payload)
    assert restored.content_hash() == scenario.content_hash()
