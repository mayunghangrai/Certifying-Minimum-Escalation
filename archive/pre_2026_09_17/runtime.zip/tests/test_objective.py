"""Humanitarian objective contracts (priority-weighted delivery time).

The objective replaces deprivation as the optimization criterion: minimize
the normalized priority-weighted, quantity-weighted delivery time plus a
lambda-weighted maximin fill-ratio fairness shortfall.  Deprivation remains
an outcome metric.  Battery reserve, hard airspace, and forecast coverage
remain hard feasibility constraints (covered by test_route_evaluator and
test_simulator); the tests here pin the objective semantics and its
propagation from wind revisions into ETAs.
"""

from __future__ import annotations

import numpy as np
import pytest

from env import evaluate_episode
from env.entities import Mode
from env.objective import (
    ObjectiveParams,
    composite_objective,
    fill_ratios,
    min_fill_ratio,
    quantity_weighted_delivery_time,
    reference_delivery_time,
)
from env.params import EnvParams
from env.scenario import Scenario, ScenarioNode
from env.simulator import RoutingSimulator


def _run_single_uav_scenario(truth_u_kmh: float) -> dict:
    """Depot (6,6) -> node (7,6) with one unit of commodity 0 demanded."""
    params = EnvParams()
    params.map.n_nodes = 1
    params.map.n_clusters = 1
    params.mission.T = 2.0
    params.mission.M = 1
    params.mission.load_time_h = 0.0
    params.mission.charge_time_h = 0.0
    params.mission.service_time_h = 0.0
    wind_spec = {
        "model": "global_2d_v1",
        "vector_convention": "towards",
        "units": {"time": "h", "speed": "km/h"},
        "truth_keyframes": [
            [0.0, truth_u_kmh, 0.0], [2.0, truth_u_kmh, 0.0]
        ],
        "forecast_packets": [{
            "issued_at_h": 0.0,
            "horizon_h": 2.0,
            "points": [
                {"valid_time_h": 0.0, "u_kmh": truth_u_kmh, "v_kmh": 0.0},
                {"valid_time_h": 2.0, "u_kmh": truth_u_kmh, "v_kmh": 0.0},
            ],
        }],
    }
    scenario = Scenario(
        seed=9,
        params=params.to_dict(),
        depot=[6.0, 6.0],
        nodes=[ScenarioNode(
            idx=0, x=7.0, y=6.0, vulnerability=1.0,
            demand=[1.0, 0.0, 0.0, 0.0], priority=1.0,
        )],
        initial_inventory=[1.0, 0.0, 0.0, 0.0],
        no_fly_zones=[],
        hazard_regions=[],
        airspace_updates=[],
        wind_spec=wind_spec,
        generation_metadata={"schema": "information-aware-routing-v2"},
    )
    sim = RoutingSimulator()
    sim.reset(scenario)
    sim.prepare(0, [1.0, 0.0, 0.0, 0.0])
    sim.advance()
    sim.dispatch(0, 0, [[6.0, 6.0], [7.0, 6.0]])
    arrival = sim.advance()
    assert arrival.uavs[0].mode is Mode.AT_NODE
    sim.deliver(0, [1.0, 0.0, 0.0, 0.0])
    service = sim.advance()
    assert service.event_type.name == "SERVICE_COMPLETE"
    objective = sim.metrics.humanitarian_objective()
    assert objective is not None
    return {
        "arrival_time_h": arrival.time_h,
        "service_time_h": service.time_h,
        "j_time": objective["j_time"],
        "composite": objective["composite"],
        "min_fill_ratio": objective["min_fill_ratio"],
    }


def test_earlier_delivery_always_reduces_j_time():
    demand = np.array([[2.0, 0.0, 0.0, 0.0], [2.0, 0.0, 0.0, 0.0]])
    priorities = np.array([1.0, 1.0])
    horizon = 4.0
    late = [(0, [1.0, 0.0, 0.0, 0.0], 2.0), (1, [1.0, 0.0, 0.0, 0.0], 2.0)]
    early = [(0, [1.0, 0.0, 0.0, 0.0], 1.0), (1, [1.0, 0.0, 0.0, 0.0], 1.0)]

    assert quantity_weighted_delivery_time(
        priorities, demand, early, horizon
    ) < quantity_weighted_delivery_time(priorities, demand, late, horizon)


def test_delaying_the_higher_priority_location_penalizes_more():
    demand = np.array([[2.0, 0.0, 0.0, 0.0], [2.0, 0.0, 0.0, 0.0]])
    priorities = np.array([2.0, 1.0])  # p_A > p_B
    horizon = 4.0
    delay_high = [(0, [1.0, 0.0, 0.0, 0.0], 2.0), (1, [1.0, 0.0, 0.0, 0.0], 1.0)]
    delay_low = [(0, [1.0, 0.0, 0.0, 0.0], 1.0), (1, [1.0, 0.0, 0.0, 0.0], 2.0)]

    high = quantity_weighted_delivery_time(
        priorities, demand, delay_high, horizon
    )
    low = quantity_weighted_delivery_time(
        priorities, demand, delay_low, horizon
    )
    assert high > low


def test_imbalanced_service_scores_worse_than_equitable_at_equal_j_time():
    demand = np.array([[2.0, 0.0, 0.0, 0.0], [2.0, 0.0, 0.0, 0.0]])
    priorities = np.array([1.0, 1.0])
    horizon = 2.0
    balanced = [(0, [1.0, 0.0, 0.0, 0.0], 1.0), (1, [1.0, 0.0, 0.0, 0.0], 1.0)]
    imbalanced = [(0, [2.0, 0.0, 0.0, 0.0], 1.0)]

    balanced_j = quantity_weighted_delivery_time(
        priorities, demand, balanced, horizon
    )
    imbalanced_j = quantity_weighted_delivery_time(
        priorities, demand, imbalanced, horizon
    )
    # Identical humanitarian delivery time: 3 units at t=1, one unit at T=2.
    assert balanced_j == pytest.approx(imbalanced_j)

    balanced_score = evaluate_episode(priorities, demand, balanced, horizon)
    imbalanced_score = evaluate_episode(priorities, demand, imbalanced, horizon)
    assert balanced_score["min_fill_ratio"] == pytest.approx(0.5)
    assert imbalanced_score["min_fill_ratio"] == pytest.approx(0.0)
    assert imbalanced_score["composite"] > balanced_score["composite"]


def test_formula_matches_hand_computation_for_split_deliveries():
    demand = np.array([[3.0, 2.0, 0.0, 0.0], [0.0, 4.0, 0.0, 0.0]])
    priorities = np.array([2.0, 1.0])
    horizon = 6.0
    log = [
        (0, [1.0, 1.0, 0.0, 0.0], 1.0),
        (1, [0.0, 2.0, 0.0, 0.0], 1.5),
        (0, [2.0, 1.0, 0.0, 0.0], 2.5),
        (1, [0.0, 1.0, 0.0, 0.0], 3.0),
    ]

    report = evaluate_episode(priorities, demand, log, horizon)

    # Node A: 2 units at t=1.0, 3 at t=2.5 -> 9.5; fully delivered.
    # Node B: 2 at t=1.5, 1 at t=3.0 -> 6.0; 1 undelivered -> +6 = 12.0.
    assert report["j_time"] == pytest.approx(2.0 * 9.5 + 1.0 * 12.0)
    assert report["j_time_ref"] == pytest.approx(6.0 * (2.0 * 5.0 + 1.0 * 4.0))
    assert report["normalized_time"] == pytest.approx(31.0 / 84.0)
    np.testing.assert_allclose(report["fill_ratios"], [1.0, 0.75])
    assert report["min_fill_ratio"] == pytest.approx(0.75)
    assert report["composite"] == pytest.approx(31.0 / 84.0 + 0.25 * 0.25)


def test_fairness_weight_is_configurable_and_validated():
    assert ObjectiveParams().lambda_fair == pytest.approx(0.25)
    assert ObjectiveParams(lambda_fair=0.0).lambda_fair == 0.0
    with pytest.raises(ValueError, match="lambda_fair"):
        ObjectiveParams(lambda_fair=-0.1)
    with pytest.raises(ValueError, match="unknown objective keys"):
        ObjectiveParams.from_dict({"lambda_fair": 0.5, "extra": 1.0})


def test_fill_ratios_and_maximin_are_simple_and_bounded():
    demand = np.array([[4.0, 0.0, 0.0, 0.0], [2.0, 0.0, 0.0, 0.0]])
    delivered = np.array([[2.0, 0.0, 0.0, 0.0], [2.0, 0.0, 0.0, 0.0]])
    ratios = fill_ratios(delivered, demand)
    np.testing.assert_allclose(ratios, [0.5, 1.0])
    assert min_fill_ratio(ratios) == pytest.approx(0.5)
    # Zero-demand nodes are considered fully served.
    zero = np.array([[0.0, 0.0, 0.0, 0.0], [2.0, 0.0, 0.0, 0.0]])
    assert min_fill_ratio(fill_ratios(delivered, zero)) == pytest.approx(1.0)


def test_wind_revision_propagates_into_eta_and_the_objective():
    calm = _run_single_uav_scenario(truth_u_kmh=0.0)
    headwind = _run_single_uav_scenario(truth_u_kmh=-12.0)
    tailwind = _run_single_uav_scenario(truth_u_kmh=12.0)

    assert calm["arrival_time_h"] == pytest.approx(1.0 / 60.0)
    assert headwind["arrival_time_h"] == pytest.approx(1.0 / 48.0)
    assert tailwind["arrival_time_h"] == pytest.approx(1.0 / 72.0)
    assert headwind["service_time_h"] > calm["service_time_h"] > tailwind["service_time_h"]
    assert headwind["j_time"] > calm["j_time"] > tailwind["j_time"]
    assert headwind["composite"] > calm["composite"] > tailwind["composite"]


def test_hard_constraints_are_not_waived_by_objective_attractiveness():
    # A zero-delay plan is attractive, but a hard-blocked corridor or an
    # empty battery must still be rejected by the environment.
    from env.route_evaluator import evaluate_route

    params = EnvParams()
    from env.airspace import AirspaceMap, NoFlyZone, activation_update
    from env.wind import OnlineWindForecast, WindForecastPacket, WindForecastPoint

    forecast = OnlineWindForecast()
    forecast.receive(WindForecastPacket(
        issued_at_h=0.0, horizon_h=1.5,
        points=(
            WindForecastPoint(0.0, 0.0, 0.0),
            WindForecastPoint(1.5, 0.0, 0.0),
        ),
    ), now_h=0.0)
    zone = NoFlyZone(
        id="NFZ", polygon=[(2.0, 0.0), (3.0, 0.0), (3.0, 2.0), (2.0, 2.0)],
        active_from=0.0, active_until=None,
    )
    airspace = AirspaceMap(no_fly_zones=[zone], hazard_regions=[])
    airspace.apply_update(activation_update(zone))

    blocked = evaluate_route(
        [[1.0, 1.0], [4.0, 1.0]], 0.0, 0.0, 230.0, airspace, forecast, params
    )
    assert blocked.hard_blocked is True
    assert "hard-airspace-intersection" in blocked.reasons

    low_battery = evaluate_route(
        [[1.0, 1.0], [4.0, 1.0]], 0.0, 0.0,
        params.physics.beta_safe - 1e-6, AirspaceMap(), forecast, params,
    )
    assert low_battery.battery_feasible is False
    assert "insufficient-battery" in low_battery.reasons


def test_objective_helpers_are_reusable_across_decision_layers():
    # Every scoring layer (episode metrics today; future construction, local
    # repair, reassignment, and reoptimization) must use the same pure
    # functions, so the composite is a single documented entry point.
    demand = np.array([[2.0, 0.0, 0.0, 0.0]])
    priorities = np.array([1.0])
    log = [(0, [2.0, 0.0, 0.0, 0.0], 1.0)]
    report = evaluate_episode(priorities, demand, log, horizon_h=4.0)

    manual = composite_objective(
        quantity_weighted_delivery_time(priorities, demand, log, 4.0),
        reference_delivery_time(priorities, demand, 4.0),
        min_fill_ratio(fill_ratios(
            np.array([[2.0, 0.0, 0.0, 0.0]]), demand
        )),
        report["lambda_fair"],
    )
    assert manual == pytest.approx(report["composite"])
