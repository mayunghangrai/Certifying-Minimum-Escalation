"""Repository boundary for the approved method-neutral research core."""

from __future__ import annotations

import importlib
import subprocess
import sys
from pathlib import Path

import yaml

from env.robust_scenario_generator import (
    generate_information_aware_scenario,
    load_information_aware_config,
)


ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "configs" / "env" / "information_aware_routes.yaml"


def test_retained_runtime_modules_import_without_legacy_dependencies():
    modules = (
        "env.airspace", "env.deprivation", "env.energy", "env.entities",
        "env.events", "env.metrics", "env.objective", "env.params",
        "env.route_evaluator", "env.robust_scenario_generator", "env.scenario",
        "env.diagnostics",
        "env.simulator", "env.wind",
    )
    for module in modules:
        importlib.import_module(module)


def test_removed_algorithm_and_legacy_paths_are_absent():
    solver = "al" + "ns"
    old_information = "bel" + "ief"
    old_generator = "scenario_" + "generator.py"
    old_executor = "uav_" + "env.py"
    old_replanning = "online_" + "replanning.py"
    old_graph = "gr" + "aph.py"
    old_observation = "observation_" + "contract.py"
    old_trajectory = "trajec" + "tory.py"
    removed = (
        "src/agents", f"src/env/{solver}_scaffold.py",
        f"src/env/{old_information}.py",
        f"src/env/{old_graph}", f"src/env/{old_observation}",
        f"src/env/{old_replanning}", f"src/env/{old_generator}",
        f"src/env/{old_trajectory}", f"src/env/{old_executor}",
        f"scripts/run_{solver}_headroom_test.py",
        f"configs/env/{solver}_headroom_environment.yaml", "configs/method",
        f"results/{solver}_headroom_development",
    )
    assert all(not (ROOT / path).exists() for path in removed)


def test_only_retained_project_generator_executes_end_to_end(tmp_path):
    params, route_information, _objective = load_information_aware_config(CONFIG)
    direct = generate_information_aware_scenario(42, params, route_information)
    output = tmp_path / "seed.json"
    result = subprocess.run([
        sys.executable,
        str(ROOT / "scripts" / "generate_information_aware_scenario.py"),
        "--seed", "42", "--config", str(CONFIG), "--output", str(output),
    ], cwd=ROOT, check=False, capture_output=True, text=True)

    assert result.returncode == 0, result.stderr
    assert direct.content_hash() in result.stdout
    assert output.exists()


def test_environment_declares_only_the_lean_runtime_and_test_stack():
    payload = yaml.safe_load((ROOT / "environment.yml").read_text(encoding="utf-8"))
    dependencies = payload["dependencies"]
    names = {
        item.split("=")[0].lower() for item in dependencies if isinstance(item, str)
    }
    assert {"python", "numpy", "pyyaml", "shapely", "pytest"} <= names
    assert names <= {"python", "numpy", "pyyaml", "shapely", "pytest", "pip"}


def test_diagnostic_api_is_public_and_method_neutral():
    import env

    assert callable(env.diagnose_environmental_packet_update)
    assert callable(env.diagnose_packet_update)
    assert hasattr(env, "DisturbanceImpactClosure")
    source = (ROOT / "src" / "env" / "diagnostics.py").read_text(encoding="utf-8")
    assert "environment_packets" not in source
    assert "truth_keyframes" not in source
    assert "ALNS" not in source
    assert "replan" not in source.lower()
