"""Robust, project-specific route-information scenario generation."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import numpy as np
import pytest
from shapely.geometry import LineString, Point, box
from shapely.ops import unary_union

from env.airspace import AirspaceMap
from env.params import EnvParams
from env.robust_scenario_generator import (
    RouteDisruptionConfig,
    WindForecastConfig,
    generate_information_aware_scenario,
    load_information_aware_config,
)
from env.scenario import Scenario
from env.wind import forecast_packets_from_spec


ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "configs" / "env" / "information_aware_routes.yaml"


def _params() -> EnvParams:
    params = EnvParams()
    params.map.n_nodes = 8
    params.map.n_clusters = 2
    params.mission.T = 6.0
    params.mission.M = 2
    return params


def _profile(mode: str = "mixed") -> RouteDisruptionConfig:
    return RouteDisruptionConfig(
        mode=mode,
        weather_episodes=2,
        airspace_episodes=2,
        onset_window_frac=(0.15, 0.65),
        duration_h=(0.5, 0.9),
    )


@pytest.fixture(scope="module")
def scenario() -> Scenario:
    return generate_information_aware_scenario(7301, _params(), _profile())


def test_all_task_information_and_inventory_are_exact_at_time_zero(scenario):
    assert all(node.vulnerability > 0.0 for node in scenario.nodes)
    assert all(sum(node.demand) > 0.0 for node in scenario.nodes)
    expected = np.sum([node.demand for node in scenario.nodes], axis=0)
    np.testing.assert_allclose(scenario.initial_inventory, expected)


def test_vector_wind_is_dynamic_and_packets_are_rolling(scenario):
    assert scenario.wind_spec["model"] == "global_2d_v1"
    assert scenario.wind_spec["vector_convention"] == "towards"
    assert scenario.wind_spec["units"] == {"time": "h", "speed": "km/h"}
    assert len(scenario.environment_packets) > 2
    packets = forecast_packets_from_spec(scenario.wind_spec)
    assert packets[0].issued_at_h == pytest.approx(0.0)
    assert packets[1].issued_at_h - packets[0].issued_at_h == pytest.approx(0.5)
    assert packets[0].horizon_h == pytest.approx(1.5)
    assert packets[-1].valid_until_h == pytest.approx(6.0)
    assert not np.allclose(
        [point.u_kmh for point in scenario.environment_packets[0].wind],
        0.0,
    )


def test_mixed_profile_has_route_relevant_weather_and_airspace_events(scenario):
    assert len(scenario.hazard_regions) == 2
    assert len(scenario.no_fly_zones) == 2
    assert {region.hazard_type for region in scenario.hazard_regions} == {
        "high_wind", "convective_weather"
    }
    assert scenario.airspace_updates == sorted(
        scenario.airspace_updates,
        key=lambda event: (event.time_h, event.region_id, event.version),
    )
    assert all(0.0 <= event.time_h <= scenario.env_params().mission.T
               for event in scenario.airspace_updates)

    depot = np.asarray(scenario.depot, dtype=float)
    corridors = [
        LineString([depot, [node.x, node.y]]) for node in scenario.nodes
    ]
    protected = [Point(depot), *(
        Point(node.x, node.y) for node in scenario.nodes
    )]
    for region in [*scenario.no_fly_zones, *scenario.hazard_regions]:
        geometry = region.effective_geometry()
        assert any(corridor.intersects(geometry) for corridor in corridors)
        assert not any(geometry.covers(point) for point in protected)


def test_every_hard_airspace_state_preserves_task_reachability(scenario):
    airspace = AirspaceMap(scenario.no_fly_zones, scenario.hazard_regions)
    margin = scenario.env_params().route_validation.safe_corridor_margin_m / 1000.0
    boundary = box(0.0, 0.0, scenario.env_params().map.region_km,
                   scenario.env_params().map.region_km)
    positions = [np.asarray(scenario.depot, dtype=float), *(
        np.array([node.x, node.y]) for node in scenario.nodes
    )]

    for update in scenario.airspace_updates:
        airspace.apply_update(update)
        blocked = [shape.buffer(margin) for shape in airspace.hard_geometries(update.time_h)]
        free = boundary if not blocked else boundary.difference(unary_union(blocked))
        components = list(getattr(free, "geoms", [free]))
        depot_component = next(part for part in components
                               if part.contains(Point(positions[0])))
        assert all(depot_component.contains(Point(position)) for position in positions)


def test_modes_pair_tasks_and_keep_wind_independent_of_polygon_mode():
    params = _params()
    static = generate_information_aware_scenario(7302, params, _profile("static"))
    weather = generate_information_aware_scenario(7302, params, _profile("weather"))
    airspace = generate_information_aware_scenario(7302, params, _profile("airspace"))
    mixed = generate_information_aware_scenario(7302, params, _profile("mixed"))

    assert static.nodes == weather.nodes == airspace.nodes == mixed.nodes
    assert static.wind_spec == weather.wind_spec == airspace.wind_spec == mixed.wind_spec
    assert static.no_fly_zones == static.hazard_regions == []
    assert weather.no_fly_zones == [] and weather.hazard_regions
    assert airspace.hazard_regions == [] and airspace.no_fly_zones
    assert weather.hazard_regions == mixed.hazard_regions
    assert airspace.no_fly_zones == mixed.no_fly_zones


def test_disabled_wind_yields_a_known_calm_packet_sequence():
    profile = RouteDisruptionConfig(
        mode="static",
        weather_episodes=0,
        airspace_episodes=0,
        wind=WindForecastConfig(enabled=False),
    )
    scenario = generate_information_aware_scenario(7309, _params(), profile)
    packets = forecast_packets_from_spec(scenario.wind_spec)

    assert len(packets) == 12
    assert packets[0].issued_at_h == pytest.approx(0.0)
    assert packets[0].valid_until_h == pytest.approx(1.5)
    assert packets[-1].issued_at_h == pytest.approx(5.5)
    assert all(
        np.allclose(
            [[point.u_kmh, point.v_kmh] for point in packet.points],
            0.0,
        )
        for packet in packets
    )


@pytest.mark.parametrize("payload", [
    {"receive_delay_h": 0.05},
    {"weather_episodes": 1.5},
    {"airspace_episodes": True},
    {"onset_window_frac": (0.15, float("nan"))},
])
def test_profile_rejects_unknown_or_invalid_values(payload):
    with pytest.raises(ValueError):
        RouteDisruptionConfig.from_dict(payload)


def test_yaml_round_trip_and_cli(tmp_path):
    params, profile, _objective = load_information_aware_config(CONFIG)
    scenario = generate_information_aware_scenario(7305, params, profile)
    output = tmp_path / "scenario.json"
    scenario.to_json(output)
    loaded = Scenario.from_json(output)
    assert loaded.content_hash() == scenario.content_hash()

    cli_output = tmp_path / "cli.json"
    result = subprocess.run([
        sys.executable,
        str(ROOT / "scripts" / "generate_information_aware_scenario.py"),
        "--seed", "7306", "--config", str(CONFIG),
        "--output", str(cli_output), "--mode", "weather",
    ], cwd=ROOT, check=False, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    cli_scenario = Scenario.from_json(cli_output)
    assert f"scenario_hash={cli_scenario.content_hash()}" in result.stdout
    assert cli_scenario.hazard_regions and cli_scenario.no_fly_zones == []
