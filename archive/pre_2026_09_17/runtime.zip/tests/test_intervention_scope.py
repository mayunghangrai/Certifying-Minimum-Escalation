"""Tests for the hierarchical remaining-plan intervention contract."""

from __future__ import annotations

from dataclasses import replace

import pytest
import env

from env.intervention_scope import (
    InterventionScope,
    ScopeViolation,
    smallest_feasible_scope,
    scope_permissions,
    validate_scope_change,
    validate_scope_hierarchy,
)
from intervention_scope_fixtures import (
    all_scope_fixtures,
    global_scope_fixture,
    make_baseline_plan,
    path_repair_fixture,
    reassignment_fixture,
    sequence_repair_fixture,
    fixture_feasibility,
    plan_signature,
)


def test_scope_permissions_are_nested_and_cumulative():
    assert validate_scope_hierarchy() is True

    scopes = list(InterventionScope)
    permissions = [scope_permissions(scope) for scope in scopes]
    assert all(
        lower <= higher
        for lower, higher in zip(permissions[:-1], permissions[1:])
    )
    assert scope_permissions(InterventionScope.RETAIN) == frozenset()
    assert scope_permissions(InterventionScope.PATH_ONLY) == frozenset({"path"})
    assert scope_permissions(InterventionScope.SEQUENCE_ONLY) == frozenset(
        {"path", "sequence"}
    )
    assert scope_permissions(
        InterventionScope.AFFECTED_TASK_REASSIGNMENT
    ) == frozenset({"path", "sequence", "assignment"})


def test_scope_contract_is_available_from_the_env_package():
    assert env.InterventionScope is InterventionScope
    assert env.MissionPlan
    assert env.TaskDecision
    assert env.smallest_feasible_scope


def test_path_scope_allows_a_path_repair_but_not_sequence_repair():
    fixture = path_repair_fixture()
    validate_scope_change(
        fixture.baseline,
        fixture.candidates[InterventionScope.PATH_ONLY],
        InterventionScope.PATH_ONLY,
    )

    sequence_fixture = sequence_repair_fixture()
    with pytest.raises(ScopeViolation, match="sequence"):
        validate_scope_change(
            sequence_fixture.baseline,
            sequence_fixture.candidates[InterventionScope.SEQUENCE_ONLY],
            InterventionScope.PATH_ONLY,
        )


def test_sequence_scope_allows_reordering_without_reassignment():
    fixture = sequence_repair_fixture()
    validate_scope_change(
        fixture.baseline,
        fixture.candidates[InterventionScope.SEQUENCE_ONLY],
        InterventionScope.SEQUENCE_ONLY,
    )

    reassignment = reassignment_fixture()
    with pytest.raises(ScopeViolation, match="assignment"):
        validate_scope_change(
            reassignment.baseline,
            reassignment.candidates[InterventionScope.AFFECTED_TASK_REASSIGNMENT],
            InterventionScope.SEQUENCE_ONLY,
            affected_tasks=reassignment.affected_tasks,
        )


def test_reassignment_scope_limits_assignment_changes_to_affected_tasks():
    fixture = reassignment_fixture()
    validate_scope_change(
        fixture.baseline,
        fixture.candidates[InterventionScope.AFFECTED_TASK_REASSIGNMENT],
        InterventionScope.AFFECTED_TASK_REASSIGNMENT,
        affected_tasks=fixture.affected_tasks,
    )

    with pytest.raises(ScopeViolation, match="not affected"):
        validate_scope_change(
            fixture.baseline,
            fixture.candidates[InterventionScope.AFFECTED_TASK_REASSIGNMENT],
            InterventionScope.AFFECTED_TASK_REASSIGNMENT,
            affected_tasks={"alpha"},
        )


def test_reassignment_scope_rejects_unknown_affected_tasks():
    baseline = make_baseline_plan()

    with pytest.raises(ScopeViolation, match="not in the remaining task set"):
        validate_scope_change(
            baseline,
            baseline,
            InterventionScope.AFFECTED_TASK_REASSIGNMENT,
            affected_tasks={"missing"},
        )


def test_committed_decisions_remain_immutable_at_unrestricted_scope():
    baseline = make_baseline_plan()
    changed_committed = dict(baseline.decisions)
    changed_committed["locked"] = replace(
        changed_committed["locked"],
        path=("DEPOT", "CHANGED", "LOCKED"),
    )

    with pytest.raises(ScopeViolation, match="committed"):
        validate_scope_change(
            baseline,
            type(baseline)(decisions=changed_committed),
            InterventionScope.UNRESTRICTED,
        )


def test_scope_change_rejects_added_or_removed_remaining_tasks():
    baseline = make_baseline_plan()
    changed = dict(baseline.decisions)
    changed.pop("beta")

    with pytest.raises(ScopeViolation, match="task set"):
        validate_scope_change(
            baseline,
            type(baseline)(decisions=changed),
            InterventionScope.UNRESTRICTED,
        )


@pytest.mark.parametrize(
    "fixture",
    all_scope_fixtures(),
    ids=lambda fixture: fixture.name,
)
def test_fixture_reports_smallest_feasible_scope(fixture):
    report = smallest_feasible_scope(
        fixture.baseline,
        fixture.candidates,
        fixture.forecast,
        fixture_feasibility,
        affected_tasks=fixture.affected_tasks,
    )

    assert report.minimum_scope is fixture.expected_scope
    assert report.to_dict()["smallest_feasible_scope"] == int(
        fixture.expected_scope
    )


def test_feasibility_receives_only_the_exact_received_forecast():
    fixture = path_repair_fixture()
    received = []

    def checker(plan, forecast):
        received.append(forecast)
        return plan_signature(plan) in forecast.feasible_signatures

    report = smallest_feasible_scope(
        fixture.baseline,
        fixture.candidates,
        fixture.forecast,
        checker,
    )

    assert report.minimum_scope is InterventionScope.PATH_ONLY
    assert received
    assert all(forecast is fixture.forecast for forecast in received)


def test_scope_assessment_reports_all_levels_in_order():
    fixture = global_scope_fixture()
    report = smallest_feasible_scope(
        fixture.baseline,
        fixture.candidates,
        fixture.forecast,
        fixture_feasibility,
        affected_tasks=fixture.affected_tasks,
    )

    assert [evaluation.scope for evaluation in report.evaluations] == list(
        InterventionScope
    )
    assert [evaluation.compliant for evaluation in report.evaluations] == [
        True,
        True,
        True,
        True,
        True,
    ]
    assert [evaluation.feasible for evaluation in report.evaluations] == [
        False,
        False,
        False,
        False,
        True,
    ]


def test_no_candidate_is_feasible_under_received_forecast():
    fixture = global_scope_fixture()
    forecast = replace(fixture.forecast, feasible_signatures=frozenset())

    report = smallest_feasible_scope(
        fixture.baseline,
        fixture.candidates,
        forecast,
        fixture_feasibility,
        affected_tasks=fixture.affected_tasks,
    )

    assert report.minimum_scope is None
    assert all(
        evaluation.feasible is False
        for evaluation in report.evaluations
        if evaluation.compliant
    )
