"""Contracts for authoritative environmental packets and transitions."""

from __future__ import annotations

import importlib

import pytest

from env.wind import WindForecastPoint


def _environment_module():
    module = importlib.import_module("env.environment")
    for name in (
        "AirspaceRestriction",
        "EnvironmentalPacket",
        "WeatherRegion",
        "compare_environmental_packets",
    ):
        assert hasattr(module, name), f"env.environment must define {name}"
    return module


def _packet(module, *, packet_id: str, issued_at: float, wind_points, weather=(), airspace=()):
    return module.EnvironmentalPacket(
        packet_id=packet_id,
        issued_at_h=issued_at,
        valid_from_h=issued_at,
        valid_until_h=issued_at + 1.5,
        wind=tuple(WindForecastPoint(*point) for point in wind_points),
        weather=tuple(weather),
        airspace=tuple(airspace),
    )


def test_authoritative_packet_round_trip_preserves_interval_and_regions():
    environment = _environment_module()
    weather = environment.WeatherRegion(
        id="WX-1",
        geometry=[(1.0, 0.0), (2.0, 0.0), (2.0, 1.0), (1.0, 1.0)],
        severity="SOFT",
        valid_from_h=0.5,
        valid_until_h=1.25,
    )
    airspace = environment.AirspaceRestriction(
        id="NFZ-1",
        geometry=[(3.0, 0.0), (4.0, 0.0), (4.0, 1.0), (3.0, 1.0)],
        valid_from_h=0.75,
        valid_until_h=1.5,
    )
    packet = _packet(
        environment,
        packet_id="ENV-1",
        issued_at=0.5,
        wind_points=((0.5, 4.0, 1.0), (1.0, 6.0, 2.0), (2.0, 8.0, 3.0)),
        weather=(weather,),
        airspace=(airspace,),
    )

    restored = environment.EnvironmentalPacket.from_dict(packet.to_dict())

    assert restored == packet
    assert packet.packet_id == "ENV-1"
    assert packet.valid_from_h == pytest.approx(0.5)
    assert packet.valid_until_h == pytest.approx(2.0)
    assert packet.weather[0].severity == "SOFT"
    assert packet.airspace[0].id == "NFZ-1"


def test_weather_severity_normalizes_soft_and_hard_states():
    environment = _environment_module()
    soft = environment.WeatherRegion(
        id="soft",
        geometry=[(0, 0), (1, 0), (1, 1), (0, 1)],
        severity="degraded",
        valid_from_h=0.0,
        valid_until_h=1.0,
    )
    hard = environment.WeatherRegion(
        id="hard",
        geometry=[(0, 0), (1, 0), (1, 1), (0, 1)],
        severity="blocked",
        valid_from_h=0.0,
        valid_until_h=1.0,
    )

    assert soft.severity == "SOFT"
    assert soft.is_hard is False
    assert hard.severity == "HARD"
    assert hard.is_hard is True


def test_packet_accepts_compact_wind_point_sequences():
    environment = _environment_module()

    packet = environment.EnvironmentalPacket(
        packet_id="ENV-compact",
        issued_at_h=0.0,
        valid_from_h=0.0,
        valid_until_h=1.0,
        wind=((0.0, 2.0, -1.0), (1.0, 3.0, 0.5)),
    )

    assert packet.wind[0].valid_time_h == pytest.approx(0.0)
    assert packet.wind[0].u_kmh == pytest.approx(2.0)
    assert packet.wind[1].v_kmh == pytest.approx(0.5)


def test_packet_comparison_separates_overlap_revisions_from_new_horizon():
    environment = _environment_module()
    first = _packet(
        environment,
        packet_id="ENV-0",
        issued_at=0.0,
        wind_points=((0.0, 2.0, 0.0), (0.5, 3.0, 0.0), (1.5, 4.0, 0.0)),
    )
    second = _packet(
        environment,
        packet_id="ENV-1",
        issued_at=0.5,
        wind_points=((0.5, 5.0, 0.0), (1.0, 6.0, 0.0), (2.0, 8.0, 0.0)),
    )

    transition = environment.compare_environmental_packets(first, second)

    assert transition.overlap == pytest.approx((0.5, 1.5))
    assert transition.revised
    assert transition.newly_revealed
    assert transition["revised"] == transition.revised
    assert transition["newly_revealed"] == transition.newly_revealed


def test_packet_horizon_extension_is_new_information_not_a_spurious_revision():
    environment = _environment_module()
    first_weather = environment.WeatherRegion(
        id="WX-1",
        geometry=[(1, 0), (2, 0), (2, 1), (1, 1)],
        severity="SOFT",
        valid_from_h=0.5,
        valid_until_h=1.5,
    )
    second_weather = environment.WeatherRegion(
        id="WX-1",
        geometry=[(1, 0), (2, 0), (2, 1), (1, 1)],
        severity="SOFT",
        valid_from_h=0.5,
        valid_until_h=2.0,
    )
    first = _packet(
        environment,
        packet_id="ENV-0",
        issued_at=0.0,
        wind_points=((0.0, 0.0, 0.0), (1.5, 0.0, 0.0)),
        weather=(first_weather,),
    )
    second = _packet(
        environment,
        packet_id="ENV-1",
        issued_at=0.5,
        wind_points=((0.5, 0.0, 0.0), (2.0, 0.0, 0.0)),
        weather=(second_weather,),
    )

    transition = environment.compare_environmental_packets(first, second)

    assert not [change for change in transition.revised if change.domain == "weather"]
    assert any(
        change.domain == "weather" and change.key == "WX-1"
        for change in transition.newly_revealed
    )


def test_packet_comparison_covers_interpolated_wind_difference_between_samples():
    environment = _environment_module()
    previous = environment.EnvironmentalPacket(
        packet_id="old",
        issued_at_h=0.0,
        valid_from_h=0.0,
        valid_until_h=1.0,
        wind=((0.0, 0.0, 0.0), (1.0, 0.0, 0.0)),
    )
    current = environment.EnvironmentalPacket(
        packet_id="new",
        issued_at_h=0.0,
        valid_from_h=0.0,
        valid_until_h=1.0,
        wind=((0.0, 0.0, 0.0), (1.0, 2.0, 0.0)),
    )

    transition = environment.compare_environmental_packets(previous, current)

    wind_changes = [
        change for change in transition.revised if change.domain == "wind"
    ]
    assert any(
        left <= 0.5 <= right and right > left
        for left, right in (change.interval for change in wind_changes)
    )


def test_packet_comparison_reports_withdrawn_coverage():
    environment = _environment_module()
    previous = environment.EnvironmentalPacket(
        packet_id="old",
        issued_at_h=0.0,
        valid_from_h=0.0,
        valid_until_h=2.0,
        wind=((0.0, 0.0, 0.0), (2.0, 0.0, 0.0)),
    )
    current = environment.EnvironmentalPacket(
        packet_id="new",
        issued_at_h=0.5,
        valid_from_h=0.5,
        valid_until_h=1.0,
        wind=((0.5, 0.0, 0.0), (1.0, 0.0, 0.0)),
    )

    transition = environment.compare_environmental_packets(previous, current)

    assert any(
        change.domain == "coverage"
        and change.before is True
        and change.after is False
        and change.interval[0] <= 1.5 <= change.interval[1]
        for change in transition.revised
    )
