"""End-to-end contracts for the canonical scenario and its HTML inspection."""

from __future__ import annotations

import subprocess
import sys
from html.parser import HTMLParser
from pathlib import Path

from env.scenario import Scenario


ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "configs" / "env" / "information_aware_routes.yaml"


class _TimeSliderParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.attributes = None

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if tag == "input" and values.get("data-role") == "time-slider":
            self.attributes = values


def test_seed_42_profile_and_self_contained_renderer(tmp_path):
    scenario_path = tmp_path / "seed_42.json"
    html_path = tmp_path / "seed_42.html"
    generate = subprocess.run(
        [
            sys.executable,
            str(ROOT / "scripts" / "generate_information_aware_scenario.py"),
            "--seed", "42",
            "--config", str(CONFIG),
            "--output", str(scenario_path),
        ],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
    )
    assert generate.returncode == 0, generate.stderr

    scenario = Scenario.from_json(str(scenario_path))
    assert scenario.seed == 42
    assert len(scenario.nodes) == 20
    assert scenario.env_params().mission.M == 3
    assert scenario.env_params().mission.T == 12.0
    assert scenario.hazard_regions and scenario.no_fly_zones
    assert scenario.wind_forecast_timeline()
    assert all(node.vulnerability > 0.0 for node in scenario.nodes)
    assert all(sum(node.demand) > 0.0 for node in scenario.nodes)
    payload_text = scenario_path.read_text(encoding="utf-8")
    assert '"initial_inventory"' in payload_text
    assert '"vulnerability"' in payload_text
    assert '"demand"' in payload_text
    for legacy_field in ("mu" + "0", "sigma" + "0", "p1" + "_reports",
                         "p3" + "_mutations"):
        assert f'"{legacy_field}"' not in payload_text
    assert "nodes=20" in generate.stdout
    assert "uavs=3" in generate.stdout
    assert "horizon_h=12" in generate.stdout

    render = subprocess.run(
        [
            sys.executable,
            str(ROOT / "scripts" / "render_information_aware_scenario.py"),
            "--input", str(scenario_path),
            "--output", str(html_path),
        ],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
    )
    assert render.returncode == 0, render.stderr
    html = html_path.read_text(encoding="utf-8")
    assert "<!doctype html>" in html.lower()
    assert scenario.content_hash() in html
    assert "Authoritative environmental packets" in html
    assert "Current authoritative wind" in html
    assert "Packet revision" in html
    assert 'data-role="impact-closure"' in html
    assert "Controlled packet-revision disturbance-impact closure" in html
    assert "Directly affected legs" in html
    assert "Propagated legs" in html
    assert "ETA delta" in html
    assert "Energy delta" in html
    assert "Deadline slack" in html
    assert "environment_packets" in html
    assert "valid interval" in html
    assert "data-role=\"time-slider\"" in html
    assert "data-role=\"packet-horizon\"" in html
    assert "fetch(" not in html
    parser = _TimeSliderParser()
    parser.feed(html)
    assert parser.attributes is not None
    assert parser.attributes.get("value") == "0"
