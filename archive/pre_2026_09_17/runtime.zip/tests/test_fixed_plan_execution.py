"""Deterministic fixed-plan execution and runtime accounting contracts."""

from __future__ import annotations

import copy
from pathlib import Path

import pytest

from env.entities import Mode, UAVParameters
from env.environment import EnvironmentalPacket
from env.fixed_plan import execute_fixed_plan
from env.params import EnvParams
from env.scenario import Scenario, ScenarioNode
from env.simulator import RoutingSimulator
from env.wind import WindForecastPoint


def _packet(wind=(0.0, 0.0), *, packet_id="FIXED-ENV"):
    return EnvironmentalPacket(
        packet_id=packet_id,
        issued_at_h=0.0,
        valid_from_h=0.0,
        valid_until_h=2.0,
        wind=(
            WindForecastPoint(0.0, wind[0], wind[1]),
            WindForecastPoint(2.0, wind[0], wind[1]),
        ),
    )


def make_fixed_scenario(wind=(0.0, 0.0)) -> Scenario:
    params = EnvParams()
    params.map.n_nodes = 2
    params.map.n_clusters = 1
    params.mission.T = 2.0
    params.mission.M = 1
    params.mission.load_time_h = 0.05
    params.mission.charge_time_h = 0.0
    params.mission.service_time_h = 0.01
    params.physics.W_max = 5.0
    params.commodities.w_k = [1.0, 1.0, 1.0, 1.0]
    params = EnvParams.from_dict(params.to_dict())
    return Scenario(
        seed=123,
        params=params.to_dict(),
        depot=[0.0, 0.0],
        nodes=[
            ScenarioNode(0, 1.0, 0.0, 1.0, [2.0, 0.0, 0.0, 0.0]),
            ScenarioNode(1, 2.0, 0.0, 1.0, [3.0, 0.0, 0.0, 0.0]),
        ],
        initial_inventory=[5.0, 0.0, 0.0, 0.0],
        environment_packets=[_packet(wind)],
        generation_metadata={"schema": "information-aware-routing-v3"},
    )


FIXED_PLAN = {
    "UAV-00": {
        "route": ["DEPOT", "NODE-000", "NODE-001", "DEPOT"],
        "load": [5.0, 0.0, 0.0, 0.0],
        "deliveries": {
            "NODE-000": [2.0, 0.0, 0.0, 0.0],
            "NODE-001": [3.0, 0.0, 0.0, 0.0],
        },
    },
}

SEED_42 = Path(__file__).parents[1] / "scenarios" / "information_aware" / "seed_42.json"


def seed_42_plan(scenario: Scenario) -> dict:
    node = scenario.nodes[0]
    quantity = [0.0] * 4
    quantity[0] = min(1.0, node.demand[0])
    return {
        "UAV-00": {
            "route": ["DEPOT", f"NODE-{node.idx:03d}", "DEPOT"],
            "load": quantity,
            "deliveries": {f"NODE-{node.idx:03d}": quantity},
        }
    }


def test_fixed_plan_executes_payload_drop_and_return():
    result = execute_fixed_plan(make_fixed_scenario(), FIXED_PLAN)

    assert result.completed is True
    assert result.simulator.uavs[0].mode is Mode.DEPOT
    assert result.metrics.completed_services == 2
    assert result.metrics.delivery_log[0][2] < result.metrics.delivery_log[1][2]
    assert result.conservation["all_within_tolerance"] is True
    assert [event["payload_before_mass_kg"] for event in result.flight_events] == pytest.approx(
        [5.0, 3.0, 0.0]
    )


def test_fixed_plan_is_deterministic_and_keeps_trace_out_of_scenario():
    scenario = make_fixed_scenario()
    before = copy.deepcopy(scenario.to_dict())

    first = execute_fixed_plan(scenario, FIXED_PLAN)
    second = execute_fixed_plan(make_fixed_scenario(), FIXED_PLAN)

    assert first.event_log == second.event_log
    assert first.total_travel_time_h == pytest.approx(second.total_travel_time_h)
    assert first.total_energy_wh == pytest.approx(second.total_energy_wh)
    assert scenario.to_dict() == before


def test_disturbance_changes_fixed_plan_physics_without_replanning():
    calm = execute_fixed_plan(make_fixed_scenario((0.0, 0.0)), FIXED_PLAN)
    headwind = execute_fixed_plan(make_fixed_scenario((-12.0, 0.0)), FIXED_PLAN)

    assert headwind.completed is True
    assert headwind.total_travel_time_h > calm.total_travel_time_h
    assert headwind.total_energy_wh > calm.total_energy_wh
    assert headwind.final_reserve_margin_wh < calm.final_reserve_margin_wh


def test_generated_seed_42_fixed_plan_has_real_runtime_quantities():
    scenario = Scenario.from_json(SEED_42)
    result = execute_fixed_plan(scenario, seed_42_plan(scenario))

    assert result.completed is True
    assert len(result.flight_events) >= 2
    assert result.environment_packets_encountered
    assert result.conservation["all_within_tolerance"] is True


def test_multiple_uavs_keep_independent_battery_balances():
    scenario = make_fixed_scenario()
    params = scenario.env_params()
    params.mission.M = 2
    scenario.params = params.to_dict()
    scenario.fleet = [
        UAVParameters.from_physics(index, params.physics)
        for index in range(2)
    ]
    plan = {
        "UAV-00": {
            "route": ["DEPOT", "NODE-000", "DEPOT"],
            "load": [2.0, 0.0, 0.0, 0.0],
            "deliveries": {"NODE-000": [2.0, 0.0, 0.0, 0.0]},
        },
        "UAV-01": {
            "route": ["DEPOT", "NODE-001", "DEPOT"],
            "load": [3.0, 0.0, 0.0, 0.0],
            "deliveries": {"NODE-001": [3.0, 0.0, 0.0, 0.0]},
        },
    }

    result = execute_fixed_plan(scenario, plan)

    assert result.completed is True
    assert result.conservation["all_within_tolerance"] is True
    assert result.conservation["battery_residual_wh"] == pytest.approx([0.0, 0.0])


def test_reset_simulator_can_execute_the_same_fixed_plan_api():
    simulator = RoutingSimulator()
    simulator.reset(make_fixed_scenario())

    result = simulator.execute_fixed_plan(FIXED_PLAN)

    assert result.completed is True
    assert result.simulator is simulator


def _revision_scenario(after_wind=(0.0, 0.0)) -> Scenario:
    scenario = make_fixed_scenario()
    scenario.environment_packets = [
        EnvironmentalPacket(
            packet_id="FIXED-OLD",
            issued_at_h=0.0,
            valid_from_h=0.0,
            valid_until_h=1.0,
            wind=(
                WindForecastPoint(0.0, 0.0, 0.0),
                WindForecastPoint(1.0, 0.0, 0.0),
            ),
        ),
        EnvironmentalPacket(
            packet_id="FIXED-NEW",
            issued_at_h=0.06,
            valid_from_h=0.06,
            valid_until_h=2.0,
            wind=(
                WindForecastPoint(0.06, after_wind[0], after_wind[1]),
                WindForecastPoint(2.0, after_wind[0], after_wind[1]),
            ),
        ),
    ]
    return scenario


def test_packet_revision_changes_downstream_physics_without_replanning():
    calm = execute_fixed_plan(_revision_scenario((0.0, 0.0)), FIXED_PLAN)
    headwind = execute_fixed_plan(_revision_scenario((-12.0, 0.0)), FIXED_PLAN)

    assert calm.completed is True
    assert headwind.completed is True
    assert len(calm.environment_packets_encountered) == 2
    assert len(headwind.environment_packets_encountered) == 2
    assert headwind.total_travel_time_h > calm.total_travel_time_h
    assert headwind.total_energy_wh > calm.total_energy_wh
    assert headwind.final_reserve_margin_wh < calm.final_reserve_margin_wh
