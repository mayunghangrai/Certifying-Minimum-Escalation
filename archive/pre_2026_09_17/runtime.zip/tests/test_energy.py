"""Energy model tests against the manuscript equations (sec: uav_fleet)."""

import importlib
import importlib.util
import math

import numpy as np
import pytest

import env.energy as energy
from env.energy import (flight_energy, is_safe_return_feasible,
                        max_service_radius, nominal_power,
                        safe_return_energy, service_energy, sortie_energy)
from env.params import PhysicsParams


@pytest.fixture
def phys():
    return PhysicsParams()  # manuscript constants


def test_manuscript_constants(phys):
    assert phys.W_max == 2.5
    assert phys.m0 == 4.0
    assert phys.B_max == 230.0
    assert phys.e_c == 3.125
    assert phys.e_v == 2.5


def test_flight_energy_formula(phys):
    # eq:flight_energy: E = L * e_c * (m0 + w_pay)
    assert flight_energy(2.0, 1.5, phys) == pytest.approx(2.0 * 3.125 * 5.5)
    assert flight_energy(0.0, 2.5, phys) == 0.0
    # fully loaded, 1 km: 3.125 * 6.5 = 20.3125 Wh
    assert flight_energy(1.0, 2.5, phys) == pytest.approx(20.3125)


def test_service_energy(phys):
    assert service_energy(phys) == 2.5  # eq:service_energy


def test_sortie_energy_two_stops(phys):
    # depot -> A (2 km, full 2.5 kg) -> B (1 km, 1.0 kg left) -> depot (3 km, empty)
    legs = [2.0, 1.0, 3.0]
    masses = [2.5, 1.0, 0.0]
    expected = (2.0 * 3.125 * 6.5 + 2.5      # leg 1 + service at A
                + 1.0 * 3.125 * 5.0 + 2.5    # leg 2 + service at B
                + 3.0 * 3.125 * 4.0)         # return leg, no service
    assert sortie_energy(legs, masses, phys) == pytest.approx(expected)


def test_safe_return_constraint_boundary(phys):
    # eq:safe_return_constraint: b >= E(q->i) + e_v + E(i->0) + beta_safe
    need = safe_return_energy(3.0, 3.0, 2.5, 0.0, phys)
    expected = 3.0 * 3.125 * 6.5 + 2.5 + 3.0 * 3.125 * 4.0
    assert need == pytest.approx(expected)
    b_exact = need + phys.beta_safe
    assert is_safe_return_feasible(b_exact, 3.0, 3.0, 2.5, 0.0, phys)
    assert not is_safe_return_feasible(b_exact - 1e-6, 3.0, 3.0, 2.5, 0.0, phys)


def test_max_service_radius(phys):
    # conservative: (B_max - beta - e_v) / (e_c * (2 m0 + 2 W_max))
    r_cons = max_service_radius(phys, conservative=True)
    assert r_cons == pytest.approx((230.0 - 23.0 - 2.5) / (3.125 * 13.0))
    # optimistic (empty return) is larger
    r_opt = max_service_radius(phys, conservative=False)
    assert r_opt > r_cons
    assert r_opt == pytest.approx((230.0 - 23.0 - 2.5) / (3.125 * 10.5))
    # a fully loaded out-and-back at the conservative radius is C5-feasible
    need = safe_return_energy(r_cons, r_cons, 2.5, 2.5, phys)
    assert phys.B_max >= need + phys.beta_safe - 1e-9


def test_directional_energy_matches_calm_model_at_zero_wind(phys):
    directional = getattr(energy, "directional_flight_energy", None)
    assert callable(directional)

    actual = directional((0.0, 0.0), (2.0, 0.0), 1.5, (0.0, 0.0), phys)

    assert actual == pytest.approx(flight_energy(2.0, 1.5, phys))


def test_nominal_power_always_keeps_payload_dependence(phys):
    # P_nominal = e_c * (m_u + m_payload) * v_uav; payload is a linear mass
    # term and must never be eliminated from the power law.
    light = nominal_power(0.0, phys)
    assert light == pytest.approx(phys.e_c * phys.m0 * phys.v_uav)
    loaded = nominal_power(2.5, phys)
    assert loaded == pytest.approx(phys.e_c * (phys.m0 + 2.5) * phys.v_uav)
    assert loaded > light
    # Strictly increasing and exactly linear in payload mass.
    mid = nominal_power(1.25, phys)
    assert mid == pytest.approx(0.5 * (light + loaded))


def test_directional_energy_is_nominal_power_times_wind_time(phys):
    directional = getattr(energy, "directional_flight_energy", None)
    assert callable(directional)
    for payload in (0.0, 1.5, 2.5):
        tail = directional((0.0, 0.0), (2.0, 0.0), payload, (12.0, 0.0), phys)
        assert tail == pytest.approx(nominal_power(payload, phys) * (2.0 / 72.0))
        head = directional((0.0, 0.0), (2.0, 0.0), payload, (-12.0, 0.0), phys)
        assert head == pytest.approx(nominal_power(payload, phys) * (2.0 / 48.0))
    # Heavier payload strictly costs more energy on every leg.
    assert directional((0.0, 0.0), (2.0, 0.0), 2.5, (-12.0, 0.0), phys) > \
        directional((0.0, 0.0), (2.0, 0.0), 0.0, (-12.0, 0.0), phys)


def test_forecast_and_realized_energy_scale_with_payload(phys):
    wind_module = importlib.import_module("env.wind") if importlib.util.find_spec(
        "env.wind"
    ) else None
    assert wind_module is not None
    packet = wind_module.WindForecastPacket(
        issued_at_h=0.0,
        horizon_h=1.5,
        points=(
            wind_module.WindForecastPoint(0.0, 12.0, 0.0),
            wind_module.WindForecastPoint(1.5, 12.0, 0.0),
        ),
    )
    forecast = wind_module.OnlineWindForecast()
    forecast.receive(packet, now_h=0.0)
    forecast_kinematics = getattr(energy, "forecast_route_kinematics", None)
    realized_arrival = getattr(energy, "realized_route_arrival", None)
    assert callable(forecast_kinematics) and callable(realized_arrival)
    spec = {
        "truth_keyframes": [[0.0, 12.0, 0.0], [2.0, 12.0, 0.0]],
        "forecast_packets": [],
    }

    forecast_light = forecast_kinematics(
        ((0.0, 0.0), (6.0, 0.0)), 0.0, (1.0,), forecast, phys
    )
    forecast_heavy = forecast_kinematics(
        ((0.0, 0.0), (6.0, 0.0)), 0.0, (2.5,), forecast, phys
    )
    _, realized_light = realized_arrival(
        ((0.0, 0.0), (6.0, 0.0)), 0.0, 1.0, spec, phys
    )
    _, realized_heavy = realized_arrival(
        ((0.0, 0.0), (6.0, 0.0)), 0.0, 2.5, spec, phys
    )

    # Same wind -> same time aloft; energy ratio is the payload mass ratio.
    assert forecast_heavy[0] / forecast_light[0] == pytest.approx(
        (phys.m0 + 2.5) / (phys.m0 + 1.0)
    )
    assert realized_heavy / realized_light == pytest.approx(
        (phys.m0 + 2.5) / (phys.m0 + 1.0)
    )
    assert realized_heavy > realized_light


def test_head_tail_and_crosswind_follow_constant_airspeed_equation(phys):
    directional = getattr(energy, "directional_flight_energy", None)
    assert callable(directional)
    calm = flight_energy(2.0, 1.5, phys)

    tail = directional((0.0, 0.0), (2.0, 0.0), 1.5, (12.0, 0.0), phys)
    head = directional((0.0, 0.0), (2.0, 0.0), 1.5, (-12.0, 0.0), phys)
    cross = directional((0.0, 0.0), (2.0, 0.0), 1.5, (0.0, 12.0), phys)

    # Ground speeds: tail 72, head 48, cross sqrt(60^2 - 12^2) km/h; energy is
    # constant nominal power (e_c (m0 + w) v_uav) times time aloft (L / s).
    assert tail == pytest.approx(calm * 60.0 / 72.0)
    assert head == pytest.approx(calm * 60.0 / 48.0)
    assert cross == pytest.approx(calm * 60.0 / math.sqrt(60.0 ** 2 - 12.0 ** 2))
    assert head > cross > calm > tail


def test_same_wind_makes_opposite_route_directions_asymmetric(phys):
    directional = getattr(energy, "directional_flight_energy", None)
    assert callable(directional)

    eastbound = directional((0.0, 0.0), (2.0, 0.0), 1.0, (12.0, 0.0), phys)
    westbound = directional((2.0, 0.0), (0.0, 0.0), 1.0, (12.0, 0.0), phys)

    assert westbound > eastbound


def test_directional_safe_return_uses_each_leg_heading(phys):
    safe_return = getattr(energy, "directional_safe_return_energy", None)
    directional = getattr(energy, "directional_flight_energy", None)
    assert callable(safe_return) and callable(directional)
    wind = (12.0, 0.0)

    actual = safe_return(
        (0.0, 0.0), (2.0, 0.0), (0.0, 0.0),
        1.5, 0.5, wind, wind, phys,
    )
    expected = (
        directional((0.0, 0.0), (2.0, 0.0), 1.5, wind, phys)
        + service_energy(phys)
        + directional((2.0, 0.0), (0.0, 0.0), 0.5, wind, phys)
    )

    assert actual == pytest.approx(expected)


def test_forecast_route_kinematics_refuses_uncovered_segment(phys):
    wind_module = importlib.import_module("env.wind") if importlib.util.find_spec(
        "env.wind"
    ) else None
    route_kinematics = getattr(energy, "forecast_route_kinematics", None)
    assert wind_module is not None and callable(route_kinematics)
    packet = wind_module.WindForecastPacket(
        issued_at_h=0.0,
        horizon_h=1.5,
        points=(
            wind_module.WindForecastPoint(0.0, 12.0, 0.0),
            wind_module.WindForecastPoint(1.5, 12.0, 0.0),
        ),
    )
    forecast = wind_module.OnlineWindForecast()
    forecast.receive(packet, now_h=0.0)

    covered = route_kinematics(
        ((0.0, 0.0), (6.0, 0.0)), 0.0, (1.0,), forecast, phys,
    )
    uncovered = route_kinematics(
        ((0.0, 0.0), (6.0, 0.0)), 1.45, (1.0,), forecast, phys,
    )

    assert covered is not None
    energy_value, duration = covered
    assert energy_value == pytest.approx(
        energy.directional_flight_energy(
            (0.0, 0.0), (6.0, 0.0), 1.0, (12.0, 0.0), phys,
        )
    )
    # 6 km with a 12 km/h tailwind along the track: ground speed 72 km/h.
    assert duration == pytest.approx(6.0 / 72.0)
    assert uncovered is None
