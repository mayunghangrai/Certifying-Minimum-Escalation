import pytest

from env.entities import UAVParameters
from env.environment import AirspaceRestriction, EnvironmentalPacket, WeatherRegion
from env.energy import LegEvaluation, evaluate_leg
from env.network import NetworkEdge
from env.params import PhysicsParams
from env.wind import WindForecastPoint


def _uav(*, speed=60.0):
    return UAVParameters(
        id="uav-0",
        nominal_airspeed_kmh=speed,
        empty_mass_kg=4.0,
        max_payload_kg=2.5,
        battery_capacity_wh=230.0,
        reserve_requirement_wh=23.0,
        energy_coefficient_wh_per_km_kg=3.125,
        service_energy_wh=2.5,
    )


def _packet(*, wind=((0.0, 0.0, 0.0), (4.0, 0.0, 0.0)), weather=(), airspace=(), valid_until=4.0):
    return EnvironmentalPacket(
        packet_id="packet-0",
        issued_at_h=0.0,
        valid_from_h=0.0,
        valid_until_h=valid_until,
        wind=tuple(WindForecastPoint(*point) for point in wind),
        weather=weather,
        airspace=airspace,
    )


def test_evaluate_leg_uses_directed_wind_formula_and_payload_mass():
    edge = NetworkEdge("e-east", "a", "b", ((0.0, 0.0), (2.0, 0.0)))
    evaluation = evaluate_leg(edge, 0.0, 1.5, _uav(), _packet(wind=((0.0, 12.0, 0.0), (4.0, 12.0, 0.0))))

    assert isinstance(evaluation, LegEvaluation)
    assert evaluation.feasible
    assert evaluation.reason is None
    assert evaluation.along_track_wind_kmh == pytest.approx(12.0)
    assert evaluation.cross_track_wind_kmh == pytest.approx(0.0)
    assert evaluation.ground_speed_kmh == pytest.approx(72.0)
    assert evaluation.travel_time_h == pytest.approx(2.0 / 72.0)
    assert evaluation.energy_wh == pytest.approx(3.125 * 5.5 * 60.0 * (2.0 / 72.0))


def test_evaluate_leg_integrates_a_leg_across_time_varying_packet_segments():
    edge = NetworkEdge("e-long", "a", "b", ((0.0, 0.0), (15.0, 0.0)))
    packet = _packet(
        wind=((0.0, 0.0, 0.0), (1.0, 0.0, 0.0), (2.0, 5.0, 0.0)),
        valid_until=2.0,
    )

    evaluation = evaluate_leg(edge, 0.0, 0.0, _uav(speed=10.0), packet)

    assert evaluation.feasible
    assert evaluation.travel_time_h > 1.0
    assert evaluation.travel_time_h < 2.0
    assert evaluation.energy_wh == pytest.approx(
        3.125 * 4.0 * 10.0 * evaluation.travel_time_h
    )


def test_evaluate_leg_returns_explicit_crosswind_failure():
    edge = NetworkEdge("e-east", "a", "b", ((0.0, 0.0), (2.0, 0.0)))
    evaluation = evaluate_leg(
        edge,
        0.0,
        0.0,
        _uav(speed=10.0),
        _packet(wind=((0.0, 0.0, 11.0), (4.0, 0.0, 11.0))),
    )

    assert not evaluation.feasible
    assert evaluation.reason == "CROSSWIND_EXCEEDS_AIRSPEED"
    assert evaluation.travel_time_h is None
    assert evaluation.energy_wh is None


def test_evaluate_leg_returns_explicit_stalled_progress_failure():
    edge = NetworkEdge("e-east", "a", "b", ((0.0, 0.0), (2.0, 0.0)))
    evaluation = evaluate_leg(
        edge,
        0.0,
        0.0,
        _uav(speed=10.0),
        _packet(wind=((0.0, -10.0, 0.0), (4.0, -10.0, 0.0))),
    )

    assert not evaluation.feasible
    assert evaluation.reason == "NONPOSITIVE_GROUND_SPEED"


def test_evaluate_leg_fails_when_the_packet_cannot_cover_the_traversal():
    edge = NetworkEdge("e-long", "a", "b", ((0.0, 0.0), (20.0, 0.0)))
    evaluation = evaluate_leg(
        edge,
        0.0,
        0.0,
        _uav(),
        _packet(
            wind=((0.0, 0.0, 0.0), (0.1, 0.0, 0.0)),
            valid_until=0.1,
        ),
    )

    assert not evaluation.feasible
    assert evaluation.reason == "ENVIRONMENT_COVERAGE_UNKNOWN"


def test_evaluate_leg_accepts_the_legacy_physics_record_through_the_same_path():
    edge = NetworkEdge("e-east", "a", "b", ((0.0, 0.0), (2.0, 0.0)))
    evaluation = evaluate_leg(
        edge,
        0.0,
        1.5,
        PhysicsParams(),
        _packet(wind=((0.0, 0.0, 0.0), (4.0, 0.0, 0.0))),
    )

    assert evaluation.feasible
    assert evaluation.ground_speed_kmh == pytest.approx(60.0)


@pytest.mark.parametrize(
    "environment, reason",
    [
        (
            {
                "weather": (
                    WeatherRegion(
                        "storm",
                        ((0.5, -0.5), (1.5, -0.5), (1.5, 0.5), (0.5, 0.5)),
                        "HARD",
                        0.0,
                        4.0,
                    ),
                ),
            },
            "HARD_WEATHER_BLOCK",
        ),
        (
            {
                "airspace": (
                    AirspaceRestriction(
                        "closure",
                        ((0.5, -0.5), (1.5, -0.5), (1.5, 0.5), (0.5, 0.5)),
                        0.0,
                        4.0,
                    ),
                ),
            },
            "AIRSPACE_BLOCK",
        ),
    ],
)
def test_evaluate_leg_returns_explicit_geometry_block(environment, reason):
    edge = NetworkEdge("e-east", "a", "b", ((0.0, 0.0), (2.0, 0.0)))
    evaluation = evaluate_leg(edge, 0.0, 0.0, _uav(), _packet(**environment))

    assert not evaluation.feasible
    assert evaluation.reason == reason


def test_evaluate_leg_reports_soft_weather_without_blocking():
    edge = NetworkEdge("e-east", "a", "b", ((0.0, 0.0), (2.0, 0.0)))
    packet = _packet(
        weather=(
            WeatherRegion(
                "degraded",
                ((0.5, -0.5), (1.5, -0.5), (1.5, 0.5), (0.5, 0.5)),
                "DEGRADED",
                0.0,
                4.0,
            ),
        ),
    )

    evaluation = evaluate_leg(edge, 0.0, 0.0, _uav(), packet)

    assert evaluation.feasible
    assert evaluation.reason is None
    assert evaluation.weather_state == "SOFT"
    assert evaluation.airspace_state == "CLEAR"
