"""Generator contracts for packet-authoritative scenarios."""

from __future__ import annotations

import json
from pathlib import Path

from env.environment import compare_environmental_packets
from env.robust_scenario_generator import (
    RouteDisruptionConfig,
    WindForecastConfig,
    generate_information_aware_scenario,
    load_information_aware_config,
)


ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "configs" / "env" / "information_aware_routes.yaml"


def test_generator_emits_reproducible_packet_sequence_with_real_revisions():
    params, route_information, _ = load_information_aware_config(CONFIG)
    first = generate_information_aware_scenario(1042, params, route_information)
    repeated = generate_information_aware_scenario(1042, params, route_information)
    different = generate_information_aware_scenario(1043, params, route_information)

    assert first.content_hash() == repeated.content_hash()
    assert first.to_dict() == repeated.to_dict()
    assert first.content_hash() != different.content_hash()
    assert first.environment_packets
    assert all(
        packet.valid_until_h <= first.mission["horizon_h"] + 1e-9
        for packet in first.environment_packets
    )
    assert first.environment_packets[-1].valid_until_h == 12.0
    transitions = [
        compare_environmental_packets(previous, current)
        for previous, current in zip(
            first.environment_packets[:-1], first.environment_packets[1:]
        )
    ]
    assert any(transition.revised for transition in transitions)
    assert any(transition.newly_revealed for transition in transitions)


def test_generator_is_controller_independent_and_uses_no_error_model():
    scenario = generate_information_aware_scenario(1042)
    serialized = json.dumps(scenario.to_dict())

    assert len(scenario.nodes) == 20
    assert len(scenario.fleet) == 3
    assert len(scenario.network.edges) == 40
    assert all(
        not hasattr(node, "route") for node in scenario.nodes
    )
    assert not any(
        token in serialized
        for token in (
            "truth_keyframes",
            "forecast_error",
            "wind_forecast_error",
            "expected_escalation",
            "GLOBAL_REOPT_REQUIRED",
        )
    )
    assert scenario.scenario_descriptors["number_of_environment_packets"] == 24
    assert scenario.scenario_descriptors["packet_revision_count"] > 0
    assert scenario.scenario_descriptors["number_of_weather_regions"] >= 1
    assert scenario.scenario_descriptors["number_of_airspace_announcements"] >= 1


def test_new_config_names_are_serializable_and_revision_magnitude_is_controllable():
    config = RouteDisruptionConfig(
        wind=WindForecastConfig(
            update_interval_h=0.5,
            lookahead_h=1.5,
            time_step_h=0.5,
            revision_magnitude_kmh=0.0,
        )
    )

    assert config.wind.to_dict()["revision_magnitude_kmh"] == 0.0
    scenario = generate_information_aware_scenario(8, route_information=config)
    transitions = [
        compare_environmental_packets(previous, current)
        for previous, current in zip(
            scenario.environment_packets[:-1], scenario.environment_packets[1:]
        )
    ]
    assert all(
        not any(change.domain == "wind" for change in transition.revised)
        for transition in transitions
    )

