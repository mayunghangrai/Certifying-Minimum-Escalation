"""Operational wind-forecast contracts for information-aware routing."""

from __future__ import annotations

import importlib
import importlib.util

import numpy as np
import pytest


def _wind_module():
    """Load the wished-for API while keeping the initial RED run collectible."""
    assert importlib.util.find_spec("env.wind") is not None, (
        "env.wind must define the online wind-information contract"
    )
    return importlib.import_module("env.wind")


def _packet(issued_at_h: float, points):
    wind = _wind_module()
    point_type = getattr(wind, "WindForecastPoint", None)
    packet_type = getattr(wind, "WindForecastPacket", None)
    assert point_type is not None and packet_type is not None
    return packet_type(
        issued_at_h=issued_at_h,
        horizon_h=1.5,
        points=tuple(point_type(*point) for point in points),
    )


def test_vector_interpolation_uses_east_north_components():
    wind = _wind_module()
    interpolate = getattr(wind, "interpolate_wind_vector", None)
    assert callable(interpolate)

    actual = interpolate(((0.0, 6.0, -2.0), (1.0, 10.0, 4.0)), 0.25)

    np.testing.assert_allclose(actual, [7.0, -0.5])


def test_packet_round_trip_preserves_issue_and_validity():
    wind = _wind_module()
    packet_type = getattr(wind, "WindForecastPacket", None)
    assert packet_type is not None
    packet = _packet(0.5, ((0.5, 4.0, 2.0), (1.0, 6.0, 4.0), (2.0, 8.0, 6.0)))

    restored = packet_type.from_dict(packet.to_dict())

    assert restored == packet
    assert restored.valid_until_h == pytest.approx(2.0)


def test_operational_state_rejects_future_packet_and_horizon_extrapolation():
    wind = _wind_module()
    state_type = getattr(wind, "OnlineWindForecast", None)
    assert state_type is not None
    state = state_type()
    packet = _packet(1.0, ((1.0, 3.0, 0.0), (1.5, 5.0, 0.0), (2.5, 7.0, 0.0)))

    with pytest.raises(ValueError, match="before its issue time"):
        state.receive(packet, now_h=0.75)
    assert state.vector_at(1.0) is None

    assert state.receive(packet, now_h=1.0)
    np.testing.assert_allclose(state.vector_at(1.25), [4.0, 0.0])
    assert state.vector_at(0.99) is None
    assert state.vector_at(2.51) is None
    assert state.covers(1.0, 2.5)
    assert not state.covers(1.0, 2.500001)


def test_new_packet_revises_same_valid_time_without_exposing_later_packet_early():
    wind = _wind_module()
    state_type = getattr(wind, "OnlineWindForecast", None)
    assert state_type is not None
    state = state_type()
    first = _packet(0.0, ((0.0, 2.0, 0.0), (0.5, 4.0, 0.0), (1.5, 8.0, 0.0)))
    revision = _packet(0.5, ((0.5, 3.0, 1.0), (1.0, 5.0, 1.0), (2.0, 9.0, 1.0)))

    state.receive(first, now_h=0.0)
    before = state.vector_at(1.0)
    with pytest.raises(ValueError, match="before its issue time"):
        state.receive(revision, now_h=0.49)
    np.testing.assert_allclose(state.vector_at(1.0), before)

    state.receive(revision, now_h=0.5)
    np.testing.assert_allclose(state.vector_at(1.0), [5.0, 1.0])
    assert not np.allclose(state.vector_at(1.0), before)


def test_truth_helper_is_explicit_and_independent_of_operational_state():
    wind = _wind_module()
    truth_vector = getattr(wind, "truth_wind_vector", None)
    state_type = getattr(wind, "OnlineWindForecast", None)
    assert callable(truth_vector) and state_type is not None
    spec = {
        "truth_keyframes": [[0.0, -4.0, 2.0], [2.0, 4.0, 6.0]],
        "forecast_packets": [],
    }

    np.testing.assert_allclose(truth_vector(spec, 1.0), [0.0, 4.0])
    assert state_type().vector_at(1.0) is None
