"""Closed-form deprivation for known demand present from time zero."""

from __future__ import annotations

import numpy as np
import pytest

from env.deprivation import deprivation_integral, f_waiting, f_waiting_integral


def test_waiting_cost_starts_at_zero_and_increases():
    assert f_waiting(0.0, 1.3, 0.4) == pytest.approx(0.0)
    ages = np.linspace(0.0, 10.0, 100)
    assert np.all(np.diff(f_waiting(ages, 0.7, 0.25)) > 0.0)


def test_closed_form_waiting_integral_matches_numerical_quadrature():
    trapezoid = getattr(np, "trapezoid", None) or np.trapz
    age, duration, alpha, kappa = 1.5, 0.7, 2.0, 0.6
    offsets = np.linspace(0.0, duration, 200001)
    expected = trapezoid(f_waiting(age + offsets, alpha, kappa), offsets)

    assert f_waiting_integral(age, duration, alpha, kappa) == pytest.approx(
        expected, rel=1e-8
    )


def test_known_demand_deprivation_is_weighted_by_vulnerability_and_quantity():
    residual = np.array([2.0, 0.0, 1.0, 0.0])
    lambda_k = np.array([4.0, 2.0, 3.0, 1.0])
    alpha_k = np.ones(4)
    kappa_k = np.array([0.35, 0.2, 0.3, 0.1])
    start, duration, vulnerability = 2.0, 0.5, 1.5
    expected = vulnerability * (
        4.0 * 2.0 * f_waiting_integral(start, duration, 1.0, 0.35)
        + 3.0 * 1.0 * f_waiting_integral(start, duration, 1.0, 0.3)
    )

    actual = deprivation_integral(
        vulnerability, residual, start, duration,
        lambda_k, alpha_k, kappa_k,
    )

    assert actual == pytest.approx(expected)


def test_zero_duration_or_zero_residual_has_zero_deprivation():
    ones = np.ones(4)
    assert deprivation_integral(1.0, ones, 2.0, 0.0, ones, ones, ones) == 0.0
    assert deprivation_integral(1.0, np.zeros(4), 2.0, 1.0,
                                ones, ones, ones) == 0.0

