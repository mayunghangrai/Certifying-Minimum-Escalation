"""Small deterministic plans used by the intervention-scope contract tests."""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Mapping

from env.intervention_scope import (
    InterventionScope,
    MissionPlan,
    TaskDecision,
)


@dataclass(frozen=True)
class FixtureForecast:
    """The only forecast information the fixture feasibility oracle reads."""

    name: str
    feasible_signatures: frozenset[tuple]


@dataclass(frozen=True)
class ScopeFixture:
    name: str
    baseline: MissionPlan
    candidates: Mapping[InterventionScope, MissionPlan]
    forecast: FixtureForecast
    affected_tasks: frozenset[str]
    expected_scope: InterventionScope


def plan_signature(plan: MissionPlan) -> tuple:
    """Return a stable, forecast-independent representation for fixture checks."""

    return tuple(
        (
            task_id,
            decision.uav_id,
            decision.sequence,
            decision.path,
        )
        for task_id, decision in sorted(plan.decisions.items())
    )


def fixture_feasibility(plan: MissionPlan, forecast: FixtureForecast) -> bool:
    """Evaluate a plan using only the received fixture forecast."""

    return plan_signature(plan) in forecast.feasible_signatures


def make_baseline_plan() -> MissionPlan:
    """Return a two-UAV plan with one immutable committed task."""

    return MissionPlan(
        decisions={
            "locked": TaskDecision(
                task_id="locked",
                uav_id="uav-0",
                sequence=0,
                path=("DEPOT", "LOCKED"),
                committed=True,
            ),
            "alpha": TaskDecision(
                task_id="alpha",
                uav_id="uav-0",
                sequence=1,
                path=("DEPOT", "ALPHA"),
            ),
            "beta": TaskDecision(
                task_id="beta",
                uav_id="uav-0",
                sequence=2,
                path=("ALPHA", "BETA"),
            ),
            "gamma": TaskDecision(
                task_id="gamma",
                uav_id="uav-1",
                sequence=0,
                path=("DEPOT", "GAMMA"),
            ),
        }
    )


def _update(plan: MissionPlan, task_id: str, **changes) -> MissionPlan:
    decisions = dict(plan.decisions)
    decisions[task_id] = replace(decisions[task_id], **changes)
    return MissionPlan(decisions=decisions)


def _candidates(
    retained: MissionPlan,
    path: MissionPlan,
    sequence: MissionPlan,
    reassignment: MissionPlan,
    unrestricted: MissionPlan,
) -> dict[InterventionScope, MissionPlan]:
    return {
        InterventionScope.RETAIN: retained,
        InterventionScope.PATH_ONLY: path,
        InterventionScope.SEQUENCE_ONLY: sequence,
        InterventionScope.AFFECTED_TASK_REASSIGNMENT: reassignment,
        InterventionScope.UNRESTRICTED: unrestricted,
    }


def _fixture(
    name: str,
    baseline: MissionPlan,
    candidates: dict[InterventionScope, MissionPlan],
    expected_scope: InterventionScope,
    *,
    affected_tasks: frozenset[str] = frozenset(),
) -> ScopeFixture:
    feasible = candidates[expected_scope]
    forecast = FixtureForecast(
        name=name,
        feasible_signatures=frozenset({plan_signature(feasible)}),
    )
    return ScopeFixture(
        name=name,
        baseline=baseline,
        candidates=candidates,
        forecast=forecast,
        affected_tasks=affected_tasks,
        expected_scope=expected_scope,
    )


def retained_fixture() -> ScopeFixture:
    baseline = make_baseline_plan()
    return _fixture(
        "retained",
        baseline,
        _candidates(baseline, baseline, baseline, baseline, baseline),
        InterventionScope.RETAIN,
    )


def path_repair_fixture() -> ScopeFixture:
    baseline = make_baseline_plan()
    repaired = _update(
        baseline,
        "alpha",
        path=("DEPOT", "SAFE-CORRIDOR", "ALPHA"),
    )
    return _fixture(
        "path-repair",
        baseline,
        _candidates(baseline, repaired, repaired, repaired, repaired),
        InterventionScope.PATH_ONLY,
    )


def sequence_repair_fixture() -> ScopeFixture:
    baseline = make_baseline_plan()
    path_only = _update(
        baseline,
        "alpha",
        path=("DEPOT", "SAFE-CORRIDOR", "ALPHA"),
    )
    reordered = _update(path_only, "alpha", sequence=3)
    reordered = _update(reordered, "beta", sequence=1)
    reordered = _update(reordered, "alpha", sequence=2)
    return _fixture(
        "sequence-repair",
        baseline,
        _candidates(baseline, path_only, reordered, reordered, reordered),
        InterventionScope.SEQUENCE_ONLY,
    )


def reassignment_fixture() -> ScopeFixture:
    baseline = make_baseline_plan()
    path_only = _update(
        baseline,
        "beta",
        path=("ALPHA", "SAFE-CORRIDOR", "BETA"),
    )
    reordered = _update(path_only, "alpha", sequence=3)
    reordered = _update(reordered, "beta", sequence=1)
    reordered = _update(reordered, "alpha", sequence=2)
    reassigned = _update(
        reordered,
        "beta",
        uav_id="uav-1",
        sequence=1,
        path=("DEPOT", "BETA"),
    )
    return _fixture(
        "reassignment",
        baseline,
        _candidates(
            baseline,
            path_only,
            reordered,
            reassigned,
            reassigned,
        ),
        InterventionScope.AFFECTED_TASK_REASSIGNMENT,
        affected_tasks=frozenset({"beta"}),
    )


def global_scope_fixture() -> ScopeFixture:
    baseline = make_baseline_plan()
    path_only = _update(
        baseline,
        "alpha",
        path=("DEPOT", "SAFE-CORRIDOR", "ALPHA"),
    )
    reordered = _update(path_only, "alpha", sequence=3)
    reordered = _update(reordered, "beta", sequence=1)
    reordered = _update(reordered, "alpha", sequence=2)
    affected_reassignment = _update(
        reordered,
        "alpha",
        uav_id="uav-1",
        sequence=1,
        path=("DEPOT", "ALPHA"),
    )
    unrestricted = _update(
        affected_reassignment,
        "beta",
        uav_id="uav-1",
        sequence=2,
        path=("ALPHA", "BETA"),
    )
    return _fixture(
        "global-scope",
        baseline,
        _candidates(
            baseline,
            path_only,
            reordered,
            affected_reassignment,
            unrestricted,
        ),
        InterventionScope.UNRESTRICTED,
        affected_tasks=frozenset({"alpha"}),
    )


def all_scope_fixtures() -> tuple[ScopeFixture, ...]:
    return (
        retained_fixture(),
        path_repair_fixture(),
        sequence_repair_fixture(),
        reassignment_fixture(),
        global_scope_fixture(),
    )
