import pytest

from env.environment import EnvironmentalPacket, WeatherRegion
from env.entities import UAVParameters
from env.events import EventType
from env.params import EnvParams
from env.route_evaluator import evaluate_route
from env.scenario import Scenario, ScenarioNode
from env.simulator import RoutingSimulator
from env.wind import WindForecastPoint


def _packet(issue, *, wind=(0.0, 0.0), weather=()):
    end = min(issue + 1.0, 2.0)
    return EnvironmentalPacket(
        packet_id=f"ENV-{int(issue * 10):03d}",
        issued_at_h=issue,
        valid_from_h=issue,
        valid_until_h=end,
        wind=(
            WindForecastPoint(issue, wind[0], wind[1]),
            WindForecastPoint(end, wind[0], wind[1]),
        ),
        weather=weather,
    )


def _scenario():
    params = EnvParams()
    params.map.n_nodes = 1
    params.map.n_clusters = 1
    params.mission.T = 2.0
    params.mission.M = 1
    return Scenario(
        seed=7,
        params=params.to_dict(),
        depot=[1.0, 1.0],
        nodes=[ScenarioNode(0, 2.0, 1.0, 1.0, [1.0, 0.0, 0.0, 0.0])],
        initial_inventory=[1.0, 0.0, 0.0, 0.0],
        environment_packets=[_packet(0.0), _packet(1.0, wind=(4.0, 0.0))],
        generation_metadata={"schema": "information-aware-routing-v3"},
    )


def test_route_evaluator_accepts_one_authoritative_environment_packet():
    result = evaluate_route(
        [[1.0, 1.0], [2.0, 1.0]],
        0.0,
        0.0,
        230.0,
        None,
        None,
        EnvParams(),
        environmental_packet=_packet(0.0),
    )

    assert result.forecast_covered
    assert result.hard_blocked is False
    assert result.forecast_energy_wh is not None
    assert result.duration_h == pytest.approx(1.0 / 60.0)


def test_route_evaluator_derives_hard_weather_block_from_packet_geometry():
    storm = WeatherRegion(
        "storm",
        ((1.4, 0.5), (1.6, 0.5), (1.6, 1.5), (1.4, 1.5)),
        "BLOCKED",
        0.0,
        1.0,
    )
    result = evaluate_route(
        [[1.0, 1.0], [2.0, 1.0]],
        0.0,
        0.0,
        230.0,
        None,
        None,
        EnvParams(),
        environmental_packet=_packet(0.0, weather=(storm,)),
    )

    assert result.hard_blocked
    assert "HARD_WEATHER_BLOCK" in result.reasons
    assert result.feasible is False
    assert "HARD_WEATHER_BLOCK" in result.reason_codes


def test_route_evaluator_propagates_per_leg_payload_masses_to_shared_physics():
    result = evaluate_route(
        [[1.0, 1.0], [2.0, 1.0], [3.0, 1.0]],
        0.0,
        [0.0, 2.0],
        230.0,
        None,
        None,
        EnvParams(),
        environmental_packet=_packet(0.0),
    )

    assert result.forecast_covered
    assert result.forecast_energy_wh == pytest.approx(12.5 + 18.75)


def test_simulator_queues_and_exposes_the_full_packet_sequence():
    scenario = _scenario()
    simulator = RoutingSimulator()

    initial = simulator.reset(scenario)
    assert initial.environment_packet == scenario.environment_packets[0]
    assert len(scenario.environment_packet_timeline()) == 2
    assert len(simulator.queue) == 2

    update = simulator.advance()
    assert update.event_type is EventType.ENVIRONMENT_PACKET_UPDATE
    assert update.environment_packet == scenario.environment_packets[1]


def test_simulator_uses_the_selected_canonical_fleet_parameters():
    scenario = _scenario()
    scenario.fleet = [
        UAVParameters(
            id="uav-slow",
            nominal_airspeed_kmh=30.0,
            empty_mass_kg=4.0,
            max_payload_kg=2.5,
            battery_capacity_wh=180.0,
            reserve_requirement_wh=18.0,
            energy_coefficient_wh_per_km_kg=3.125,
            service_energy_wh=2.5,
        ),
    ]
    simulator = RoutingSimulator()
    simulator.reset(scenario)
    simulator.prepare(0, [1.0, 0.0, 0.0, 0.0])
    simulator.advance()

    simulator.dispatch(0, 0, [[1.0, 1.0], [2.0, 1.0]])

    assert simulator.uavs[0].battery == pytest.approx(180.0)
    assert simulator.uavs[0].route_arrival_h == pytest.approx(simulator.time_h + 1.0 / 30.0)


def test_packet_replacement_settles_under_prior_packet_and_awaits_new_route():
    scenario = _scenario()
    scenario.nodes[0].x = 10.0
    scenario.environment_packets = [
        _packet(0.0),
        _packet(0.2, wind=(4.0, 0.0)),
    ]
    simulator = RoutingSimulator()
    simulator.reset(scenario)
    simulator.prepare(0, [1.0, 0.0, 0.0, 0.0])
    simulator.advance()
    simulator.dispatch(0, 0, [[1.0, 1.0], [10.0, 1.0]])

    update = simulator.advance()

    assert update.event_type is EventType.ENVIRONMENT_PACKET_UPDATE
    assert update.uavs[0].mode.value == "awaiting_route"
    assert update.uavs[0].active_route is None
    assert 1.0 < update.uavs[0].position[0] < 10.0
    assert update.environment_packet == scenario.environment_packets[1]


def test_packet_update_snapshot_and_convenience_diagnostic_use_only_visible_packets():
    scenario = _scenario()
    scenario.nodes[0].x = 10.0
    scenario.environment_packets = [
        _packet(0.0),
        _packet(0.2, wind=(4.0, 0.0)),
        _packet(0.8, wind=(-40.0, 0.0)),
    ]
    simulator = RoutingSimulator()
    simulator.reset(scenario)
    simulator.prepare(0, [1.0, 0.0, 0.0, 0.0])
    simulator.advance()
    simulator.dispatch(0, 0, [[1.0, 1.0], [10.0, 1.0]])

    update = simulator.advance()
    before = simulator.snapshot()
    closure = simulator.diagnose_packet_update({
        "UAV-00": {
            "route": ["DEPOT", "NODE-000", "DEPOT"],
            "load": [1.0, 0.0, 0.0, 0.0],
            "deliveries": {"NODE-000": [1.0, 0.0, 0.0, 0.0]},
        },
    })
    after = simulator.snapshot()

    assert update.uavs[0].committed_route is not None
    assert update.uavs[0].committed_destination == 0
    assert closure.previous_packet_id == scenario.environment_packets[0].packet_id
    assert closure.received_packet_id == scenario.environment_packets[1].packet_id
    assert len(closure.legs) == 2
    assert simulator.time_h == before.time_h == after.time_h
    assert simulator.environment_packet == before.environment_packet == after.environment_packet


def test_packet_update_diagnostic_expires_after_resuming_the_committed_route():
    scenario = _scenario()
    scenario.nodes[0].x = 10.0
    scenario.environment_packets = [
        _packet(0.0),
        _packet(0.2, wind=(4.0, 0.0)),
    ]
    simulator = RoutingSimulator()
    simulator.reset(scenario)
    simulator.prepare(0, [1.0, 0.0, 0.0, 0.0])
    simulator.advance()
    simulator.dispatch(0, 0, [[1.0, 1.0], [10.0, 1.0]])
    simulator.advance()
    simulator.resume_current_leg(0)

    with pytest.raises(ValueError, match="decision epoch"):
        simulator.diagnose_packet_update({
            "UAV-00": {
                "route": ["DEPOT", "NODE-000", "DEPOT"],
                "load": [1.0, 0.0, 0.0, 0.0],
                "deliveries": {"NODE-000": [1.0, 0.0, 0.0, 0.0]},
            },
        })


def test_packet_replacement_preserves_remainder_for_explicit_resume():
    scenario = _scenario()
    scenario.nodes[0].x = 10.0
    scenario.environment_packets = [
        _packet(0.0),
        _packet(0.2, wind=(4.0, 0.0)),
    ]
    simulator = RoutingSimulator()
    simulator.reset(scenario)
    simulator.prepare(0, [1.0, 0.0, 0.0, 0.0])
    simulator.advance()
    simulator.dispatch(0, 0, [[1.0, 1.0], [10.0, 1.0]])

    update = simulator.advance()
    position_at_update = update.uavs[0].position.copy()
    battery_at_update = update.uavs[0].battery

    simulator.resume_current_leg(0)
    assert simulator.uavs[0].mode.value == "flying"
    assert simulator.uavs[0].position[0] == pytest.approx(position_at_update[0])
    simulator.advance()

    assert simulator.uavs[0].position[0] == pytest.approx(10.0)
    assert simulator.uavs[0].battery < battery_at_update
    assert len(simulator.metrics.flight_log) == 2


def test_packet_update_at_exact_arrival_does_not_create_a_phantom_remainder():
    scenario = _scenario()
    arrival_time = 0.15 + 1.0 / 60.0
    scenario.environment_packets = [
        _packet(0.0),
        _packet(arrival_time, wind=(4.0, 0.0)),
    ]
    simulator = RoutingSimulator()
    simulator.reset(scenario)
    simulator.prepare(0, [1.0, 0.0, 0.0, 0.0])
    simulator.advance()
    simulator.dispatch(
        0,
        0,
        [scenario.depot, [scenario.nodes[0].x, scenario.nodes[0].y]],
    )

    update = simulator.advance()

    assert update.uavs[0].mode.value == "at_node"
    assert simulator.uavs[0].pending_route is None
