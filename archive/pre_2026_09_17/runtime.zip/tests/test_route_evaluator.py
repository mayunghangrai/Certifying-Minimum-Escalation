"""Behavioral tests for evaluating caller-supplied routes without search."""

from __future__ import annotations

import copy
import math

import numpy as np
import pytest

from env.airspace import AirspaceMap, HazardRegion, NoFlyZone, activation_update
from env.energy import realized_route_arrival
from env.params import EnvParams
from env.route_evaluator import evaluate_route
from env.wind import (
    OnlineWindForecast,
    WindForecastPacket,
    WindForecastPoint,
)


@pytest.fixture
def params() -> EnvParams:
    return EnvParams()


def _forecast(vectors=((0.0, 0.0), (0.0, 0.0)),
              times=(0.0, 1.5)) -> OnlineWindForecast:
    state = OnlineWindForecast()
    state.receive(WindForecastPacket(
        issued_at_h=0.0,
        horizon_h=1.5,
        points=tuple(
            WindForecastPoint(time_h, vector[0], vector[1])
            for time_h, vector in zip(times, vectors)
        ),
    ), now_h=0.0)
    return state


def _active_map(region) -> AirspaceMap:
    airspace = AirspaceMap(
        no_fly_zones=[region] if isinstance(region, NoFlyZone) else [],
        hazard_regions=[region] if isinstance(region, HazardRegion) else [],
    )
    airspace.apply_update(activation_update(region))
    return airspace


def test_evaluator_rejects_malformed_or_out_of_bounds_polyline(params):
    with pytest.raises(ValueError, match="at least two"):
        evaluate_route([[1.0, 1.0]], 0.0, 0.0, 230.0,
                       AirspaceMap(), _forecast(), params)
    with pytest.raises(ValueError, match="inside the map"):
        evaluate_route([[1.0, 1.0], [13.0, 1.0]], 0.0, 0.0, 230.0,
                       AirspaceMap(), _forecast(), params)


def test_evaluator_preserves_supplied_waypoints_and_sums_literal_distances(params):
    points = [[1.0, 1.0], [2.0, 3.0], [4.0, 4.0]]
    original = copy.deepcopy(points)

    result = evaluate_route(
        points, 0.0, 0.0, 230.0, AirspaceMap(), _forecast(), params
    )

    assert points == original
    assert result.distance_km == pytest.approx(math.sqrt(5.0) + math.sqrt(5.0))
    assert result.duration_h == pytest.approx(result.distance_km / 60.0)
    assert result.hard_blocked is False
    assert result.forecast_covered is True


def test_hard_polygon_and_safety_margin_fail_closed(params):
    zone = NoFlyZone(
        id="NFZ", polygon=[(2.0, 0.0), (3.0, 0.0), (3.0, 2.0), (2.0, 2.0)],
        active_from=0.0, active_until=None,
    )
    blocked = evaluate_route(
        [[1.0, 1.0], [4.0, 1.0]], 0.0, 0.0, 230.0,
        _active_map(zone), _forecast(), params,
    )
    assert blocked.hard_blocked is True
    assert "hard-airspace-intersection" in blocked.reasons

    close = evaluate_route(
        [[1.0, 2.01], [4.0, 2.01]], 0.0, 0.0, 230.0,
        _active_map(zone), _forecast(), params,
    )
    assert close.hard_blocked is True


def test_soft_hazard_reports_positive_exposure_without_blocking(params):
    hazard = HazardRegion(
        id="WX", polygon=[(2.0, 0.0), (3.0, 0.0), (3.0, 2.0), (2.0, 2.0)],
        severity=0.5, hazard_type="wind", active_from=0.0,
        active_until=None, hard_threshold=0.8,
    )

    result = evaluate_route(
        [[1.0, 1.0], [4.0, 1.0]], 0.0, 0.0, 230.0,
        _active_map(hazard), _forecast(), params,
    )

    assert result.hard_blocked is False
    assert result.hazard_exposure == pytest.approx(0.5)


def test_missing_or_partial_forecast_never_claims_energy_feasibility(params):
    missing = evaluate_route(
        [[1.0, 1.0], [4.0, 1.0]], 0.0, 0.0, 230.0,
        AirspaceMap(), OnlineWindForecast(), params,
    )
    partial = evaluate_route(
        [[1.0, 1.0], [4.0, 1.0]], 0.99, 0.0, 230.0,
        AirspaceMap(), _forecast(times=(0.0, 1.0)), params,
    )

    for result in (missing, partial):
        assert result.forecast_covered is False
        assert result.forecast_energy_wh is None
        assert result.duration_h is None
        assert result.battery_feasible is None
        assert "forecast-not-covered" in result.reasons


def test_headwind_tailwind_and_reverse_direction_change_energy(params):
    east = [[1.0, 1.0], [5.0, 1.0]]
    west = list(reversed(east))
    calm = _forecast()
    eastward = _forecast(((12.0, 0.0), (12.0, 0.0)))
    westward = _forecast(((-12.0, 0.0), (-12.0, 0.0)))

    calm_e = evaluate_route(east, 0.0, 1.0, 230.0,
                            AirspaceMap(), calm, params).forecast_energy_wh
    tail_e = evaluate_route(east, 0.0, 1.0, 230.0,
                            AirspaceMap(), eastward, params).forecast_energy_wh
    head_e = evaluate_route(east, 0.0, 1.0, 230.0,
                            AirspaceMap(), westward, params).forecast_energy_wh
    tail_w = evaluate_route(west, 0.0, 1.0, 230.0,
                            AirspaceMap(), westward, params).forecast_energy_wh
    head_w = evaluate_route(west, 0.0, 1.0, 230.0,
                            AirspaceMap(), eastward, params).forecast_energy_wh

    assert head_e > calm_e > tail_e
    assert head_w > tail_w
    assert head_e == pytest.approx(head_w)
    assert tail_e == pytest.approx(tail_w)

    tail_duration = evaluate_route(
        east, 0.0, 1.0, 230.0, AirspaceMap(), eastward, params
    ).duration_h
    head_duration = evaluate_route(
        east, 0.0, 1.0, 230.0, AirspaceMap(), westward, params
    ).duration_h
    calm_duration = evaluate_route(
        east, 0.0, 1.0, 230.0, AirspaceMap(), calm, params
    ).duration_h
    assert head_duration == pytest.approx(4.0 / 48.0)
    assert calm_duration == pytest.approx(4.0 / 60.0)
    assert tail_duration == pytest.approx(4.0 / 72.0)


def test_battery_feasibility_includes_the_reserved_energy(params):
    route = [[1.0, 1.0], [5.0, 1.0]]
    reference = evaluate_route(
        route, 0.0, 1.0, 230.0, AirspaceMap(), _forecast(), params
    )
    assert reference.forecast_energy_wh is not None
    required = reference.forecast_energy_wh + params.physics.beta_safe

    exact = evaluate_route(
        route, 0.0, 1.0, required, AirspaceMap(), _forecast(), params
    )
    short = evaluate_route(
        route, 0.0, 1.0, required - 1e-6, AirspaceMap(), _forecast(), params
    )
    assert exact.battery_feasible is True
    assert short.battery_feasible is False
    assert "insufficient-battery" in short.reasons


def test_realized_arrival_and_energy_follow_the_truth_wind(params):
    wind_spec = {
        "truth_keyframes": [[0.0, -12.0, 0.0], [2.0, -12.0, 0.0]],
        "forecast_packets": [],
    }
    head_arrival, head_energy = realized_route_arrival(
        [[1.0, 1.0], [5.0, 1.0]], 0.0, 1.0,
        wind_spec, params.physics,
    )
    tail_arrival, tail_energy = realized_route_arrival(
        [[5.0, 1.0], [1.0, 1.0]], 0.0, 1.0,
        wind_spec, params.physics,
    )

    assert head_energy > tail_energy
    assert np.isfinite(head_energy)
    # 4 km east into a 12 km/h westward headwind: ground speed 48 km/h.
    assert head_arrival == pytest.approx(4.0 / 48.0)
    # The same leg westbound rides a 12 km/h tailwind: ground speed 72 km/h.
    assert tail_arrival == pytest.approx(4.0 / 72.0)
    assert head_arrival > tail_arrival
