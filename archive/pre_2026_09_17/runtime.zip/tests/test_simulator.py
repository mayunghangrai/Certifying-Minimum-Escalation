"""Command lifecycle and information-boundary tests for the lean executor."""

from __future__ import annotations

import copy

import numpy as np
import pytest

from env.airspace import NoFlyZone
from env.entities import Mode
from env.events import Event, EventQueue, EventType
from env.params import EnvParams
from env.scenario import Scenario, ScenarioNode
from env.simulator import RoutingSimulator


def _wind_spec(*, update_at: float | None = None) -> dict:
    packets = [{
        "issued_at_h": 0.0,
        "horizon_h": 2.0,
        "points": [
            {"valid_time_h": 0.0, "u_kmh": 0.0, "v_kmh": 0.0},
            {"valid_time_h": 2.0, "u_kmh": 0.0, "v_kmh": 0.0},
        ],
    }]
    if update_at is not None:
        packets.append({
            "issued_at_h": update_at,
            "horizon_h": 2.0,
            "points": [
                {"valid_time_h": update_at, "u_kmh": 2.0, "v_kmh": 0.0},
                {"valid_time_h": 2.0, "u_kmh": 2.0, "v_kmh": 0.0},
            ],
        })
    return {
        "model": "global_2d_v1",
        "vector_convention": "towards",
        "units": {"time": "h", "speed": "km/h"},
        "truth_keyframes": [[0.0, 0.0, 0.0], [2.0, 0.0, 0.0]],
        "forecast_packets": packets,
    }


def _scenario(*, wind=True, no_fly=False, update_at=None) -> Scenario:
    params = EnvParams()
    params.map.n_nodes = 1
    params.map.n_clusters = 1
    params.mission.T = 2.0
    params.mission.M = 1
    params.mission.load_time_h = 0.1
    params.mission.charge_time_h = 0.2
    params.mission.service_time_h = 0.05
    zones = []
    if no_fly:
        zones.append(NoFlyZone(
            id="NFZ",
            polygon=[(6.4, 5.5), (6.7, 5.5), (6.7, 6.5), (6.4, 6.5)],
            active_from=0.0,
            active_until=None,
        ))
    if update_at is not None:
        zones.append(NoFlyZone(
            id="LATE-NFZ",
            polygon=[(6.8, 5.5), (7.2, 5.5), (7.2, 6.5), (6.8, 6.5)],
            active_from=update_at,
            active_until=None,
        ))
    return Scenario(
        seed=11,
        params=params.to_dict(),
        depot=[6.0, 6.0],
        nodes=[ScenarioNode(
            idx=0, x=7.0, y=6.0, vulnerability=1.5,
            demand=[2.0, 1.0, 0.0, 0.0],
        )],
        initial_inventory=[2.0, 1.0, 0.0, 0.0],
        no_fly_zones=zones,
        hazard_regions=[],
        airspace_updates=[],
        wind_spec=_wind_spec(update_at=update_at) if wind else {
            "truth_keyframes": [[0.0, 0.0, 0.0], [2.0, 0.0, 0.0]],
            "forecast_packets": [],
        },
        generation_metadata={"schema": "information-aware-routing-v2"},
    )


def _loaded_simulator() -> RoutingSimulator:
    sim = RoutingSimulator()
    sim.reset(_scenario())
    sim.prepare(0, [1.0, 0.0, 0.0, 0.0])
    epoch = sim.advance()
    assert epoch.event_type is EventType.LOAD_COMPLETE
    return sim


def test_reset_exposes_known_tasks_but_no_future_or_truth_information():
    scenario = _scenario(update_at=0.05)
    sim = RoutingSimulator()

    snapshot = sim.reset(scenario)

    assert len(snapshot.nodes) == 1
    np.testing.assert_allclose(snapshot.nodes[0].remaining_demand, [2.0, 1.0, 0.0, 0.0])
    assert snapshot.wind_forecast is not None
    assert snapshot.wind_forecast.issued_at_h == pytest.approx(0.0)
    assert not hasattr(snapshot, "future_airspace_updates")
    assert not hasattr(snapshot, "wind_truth")
    assert all(region.id != "LATE-NFZ" for region in snapshot.airspace_regions)


def test_snapshot_arrays_are_copies_and_read_only():
    sim = RoutingSimulator()
    first = sim.reset(_scenario())

    with pytest.raises(ValueError):
        first.nodes[0].remaining_demand[0] = 999.0
    second = sim.snapshot()
    assert second.nodes[0].remaining_demand[0] == pytest.approx(2.0)


def test_caller_drives_prepare_dispatch_deliver_and_return_lifecycle():
    scenario = _scenario()
    sim = RoutingSimulator()
    start = sim.reset(scenario)
    initial_inventory = start.inventory.copy()

    sim.prepare(0, [1.0, 0.0, 0.0, 0.0])
    np.testing.assert_allclose(sim.snapshot().inventory,
                               initial_inventory - [1.0, 0.0, 0.0, 0.0])
    load_epoch = sim.advance()
    assert load_epoch.event_type is EventType.LOAD_COMPLETE
    assert load_epoch.uavs[0].mode is Mode.READY

    node_position = [scenario.nodes[0].x, scenario.nodes[0].y]
    sim.dispatch(0, 0, [sim.uavs[0].position, node_position])
    arrival_epoch = sim.advance()
    assert arrival_epoch.event_type is EventType.WAYPOINT_REACHED
    assert arrival_epoch.uavs[0].mode is Mode.AT_NODE

    sim.deliver(0, [1.0, 0.0, 0.0, 0.0])
    service_epoch = sim.advance()
    assert service_epoch.event_type is EventType.SERVICE_COMPLETE
    assert service_epoch.nodes[0].remaining_demand[0] == pytest.approx(1.0)
    assert service_epoch.uavs[0].payload[0] == pytest.approx(0.0)

    sim.dispatch(0, -1, [sim.uavs[0].position, scenario.depot])
    return_epoch = sim.advance()
    assert return_epoch.uavs[0].mode is Mode.DEPOT
    np.testing.assert_allclose(return_epoch.uavs[0].position, scenario.depot)
    assert sim.metrics.energy_consumed_wh > 0.0
    assert sim.metrics.total_deprivation > 0.0
    assert sim.metrics.completed_services == 1
    np.testing.assert_allclose(sim.metrics.delivered_units, [1.0, 0.0, 0.0, 0.0])


def test_negative_battery_is_rejected_instead_of_clamped():
    sim = _loaded_simulator()
    sim.uavs[0].battery = 0.01

    with pytest.raises(ValueError, match="INSUFFICIENT_BATTERY"):
        sim.consume_battery(0, 0.02)

    assert sim.uavs[0].battery == pytest.approx(0.01)


def test_flight_log_and_conservation_audit_capture_runtime_state():
    sim = _loaded_simulator()
    scenario = sim.scenario
    assert scenario is not None
    sim.dispatch(0, 0, [scenario.depot, [scenario.nodes[0].x, scenario.nodes[0].y]])
    sim.advance()

    assert sim.metrics.flight_log
    flight = sim.metrics.flight_log[0]
    assert {
        "uav", "origin", "destination", "departure_time_h", "arrival_time_h",
        "payload_before", "payload_after", "battery_before", "battery_after",
        "packet_id", "energy_wh", "weather_state", "airspace_state",
        "feasible", "reason", "edge_geometry", "travel_time_h",
        "ground_speed_kmh", "wind_vector_kmh", "along_track_wind_kmh",
        "cross_track_wind_kmh", "airspeed_kmh", "power_w",
    } <= set(flight)
    audit = sim.conservation_audit()
    assert audit["all_within_tolerance"] is True


def test_delivery_log_contains_residual_demand_and_actual_payload_state():
    sim = _loaded_simulator()
    scenario = sim.scenario
    assert scenario is not None
    sim.dispatch(0, 0, [scenario.depot, [scenario.nodes[0].x, scenario.nodes[0].y]])
    sim.advance()
    sim.deliver(0, [1.0, 0.0, 0.0, 0.0])
    sim.advance()

    delivery = sim.metrics.delivery_events[0]
    assert {
        "node_id", "time_h", "quantities", "payload_before", "payload_after",
        "battery_before", "battery_after", "residual_demand", "packet_id",
        "feasible", "reason",
    } <= set(delivery)


def test_rejected_dispatch_is_recorded_with_a_canonical_reason():
    sim = _loaded_simulator()
    scenario = sim.scenario
    assert scenario is not None
    sim.uavs[0].battery = sim.params.physics.beta_safe

    with pytest.raises(ValueError, match="INSUFFICIENT_BATTERY"):
        sim.dispatch(0, 0, [scenario.depot, [scenario.nodes[0].x, scenario.nodes[0].y]])

    rejected = sim.metrics.flight_log[-1]
    assert rejected["feasible"] is False
    assert rejected["reason"] == "INSUFFICIENT_BATTERY"
    assert rejected["energy_wh"] == pytest.approx(0.0)


def test_delivery_rejects_reserve_shortfall_even_when_battery_is_nonzero():
    sim = _loaded_simulator()
    scenario = sim.scenario
    assert scenario is not None
    sim.dispatch(0, 0, [scenario.depot, [scenario.nodes[0].x, scenario.nodes[0].y]])
    sim.advance()
    sim.uavs[0].battery = 30.0

    with pytest.raises(ValueError, match="SAFE_RETURN_RESERVE_VIOLATION"):
        sim.deliver(0, [1.0, 0.0, 0.0, 0.0])

    assert sim.uavs[0].mode is Mode.AT_NODE
    assert sim.uavs[0].payload[0] == pytest.approx(1.0)


@pytest.mark.parametrize("quantities, message", [
    ([20.0, 0.0, 0.0, 0.0], "payload capacity"),
    ([3.0, 0.0, 0.0, 0.0], "inventory"),
    ([-1.0, 0.0, 0.0, 0.0], "nonnegative"),
])
def test_prepare_failures_are_atomic(quantities, message):
    sim = RoutingSimulator()
    before = sim.reset(_scenario())
    with pytest.raises(ValueError, match=message):
        sim.prepare(0, quantities)
    after = sim.snapshot()
    np.testing.assert_allclose(after.inventory, before.inventory)
    assert after.uavs[0].mode is Mode.DEPOT


def test_dispatch_rejects_wrong_mode_destination_endpoints_and_missing_forecast():
    sim = RoutingSimulator()
    scenario = _scenario()
    sim.reset(scenario)
    with pytest.raises(ValueError, match="not ready"):
        sim.dispatch(0, 0, [scenario.depot, [7.0, 6.0]])

    sim = _loaded_simulator()
    before = sim.snapshot()
    with pytest.raises(ValueError, match="destination"):
        sim.dispatch(0, 4, [scenario.depot, [7.0, 6.0]])
    with pytest.raises(ValueError, match="start"):
        sim.dispatch(0, 0, [[6.1, 6.0], [7.0, 6.0]])
    with pytest.raises(ValueError, match="end"):
        sim.dispatch(0, 0, [scenario.depot, [6.9, 6.0]])
    assert sim.snapshot().uavs[0].mode is before.uavs[0].mode

    no_forecast = RoutingSimulator()
    scenario_without_forecast = _scenario(wind=False)
    no_forecast.reset(scenario_without_forecast)
    no_forecast.prepare(0, [1.0, 0.0, 0.0, 0.0])
    no_forecast.advance()
    with pytest.raises(ValueError, match="forecast"):
        no_forecast.dispatch(0, 0, [scenario_without_forecast.depot, [7.0, 6.0]])
    assert no_forecast.uavs[0].mode is Mode.READY


def test_dispatch_rejects_hard_block_and_insufficient_battery():
    blocked = RoutingSimulator()
    blocked_scenario = _scenario(no_fly=True)
    blocked.reset(blocked_scenario)
    blocked.prepare(0, [1.0, 0.0, 0.0, 0.0])
    blocked.advance()
    with pytest.raises(ValueError, match="hard airspace"):
        blocked.dispatch(0, 0, [blocked_scenario.depot, [7.0, 6.0]])
    assert blocked.uavs[0].mode is Mode.READY

    low = _loaded_simulator()
    low.uavs[0].battery = low.params.physics.beta_safe
    with pytest.raises(ValueError, match="battery"):
        low.dispatch(0, 0, [[6.0, 6.0], [7.0, 6.0]])
    assert low.uavs[0].mode is Mode.READY


def test_deliver_rejects_wrong_mode_and_excess_quantities_atomically():
    sim = _loaded_simulator()
    with pytest.raises(ValueError, match="at a demand node"):
        sim.deliver(0, [1.0, 0.0, 0.0, 0.0])

    sim.dispatch(0, 0, [[6.0, 6.0], [7.0, 6.0]])
    sim.advance()
    sim.nodes[0].remaining_demand[0] = 0.5
    before = sim.snapshot()
    with pytest.raises(ValueError, match="onboard payload"):
        sim.deliver(0, [2.0, 0.0, 0.0, 0.0])
    with pytest.raises(ValueError, match="residual demand"):
        sim.deliver(0, [1.0, 0.0, 0.0, 0.0])
    after = sim.snapshot()
    np.testing.assert_allclose(after.nodes[0].remaining_demand,
                               before.nodes[0].remaining_demand)
    np.testing.assert_allclose(after.uavs[0].payload, before.uavs[0].payload)
    assert after.uavs[0].mode is Mode.AT_NODE


def test_midflight_information_update_stops_and_awaits_external_route():
    scenario = _scenario(update_at=0.11)
    sim = RoutingSimulator()
    sim.reset(scenario)
    sim.prepare(0, [1.0, 0.0, 0.0, 0.0])
    sim.advance()
    sim.dispatch(0, 0, [[6.0, 6.0], [7.0, 6.0]])

    epoch = sim.advance()

    assert epoch.event_type is EventType.AIRSPACE_UPDATE
    assert epoch.time_h == pytest.approx(0.11)
    assert 6.0 < epoch.uavs[0].position[0] < 7.0
    assert epoch.uavs[0].mode is Mode.AWAITING_ROUTE
    assert epoch.uavs[0].active_route is None
    assert sim.uavs[0].waypoint_event_id is None
    assert any(region.id == "LATE-NFZ" for region in epoch.airspace_regions)


def test_event_queue_rejects_nonmonotone_insertion_after_progress():
    queue = EventQueue()
    queue.push(Event(1.0, EventType.HORIZON))
    assert queue.pop().time_h == pytest.approx(1.0)
    with pytest.raises(ValueError, match="earlier than"):
        queue.push(Event(0.5, EventType.HORIZON))
