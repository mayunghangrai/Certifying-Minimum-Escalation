"""Canonical scenario schema and legacy migration contracts."""

from __future__ import annotations

import json
import dataclasses
from pathlib import Path

from env.robust_scenario_generator import generate_information_aware_scenario
from env.scenario import Scenario, ScenarioNode


ROOT = Path(__file__).resolve().parents[1]


def test_generated_scenario_emits_canonical_v3_shape_without_truth_or_error_fields():
    scenario = generate_information_aware_scenario(42)
    payload = scenario.to_dict()

    assert set(payload) == {
        "schema_version",
        "metadata",
        "mission",
        "depot",
        "commodities",
        "relief_nodes",
        "fleet",
        "network",
        "environment_packets",
        "scenario_descriptors",
    }
    assert set(payload["metadata"]) == {
        "seed", "generator_version", "config_hash", "scenario_hash"
    }
    assert payload["mission"] == {
        "horizon_h": 12.0,
        "environment_update_interval_h": 0.5,
        "forecast_horizon_h": 1.5,
    }
    assert len(payload["relief_nodes"]) == 20
    assert len(payload["fleet"]) == 3
    assert {"id", "origin", "destination", "length_km", "bearing_rad", "geometry"} <= set(
        payload["network"]["edges"][0]
    )
    assert not any(
        forbidden in json.dumps(payload)
        for forbidden in ("truth_keyframes", "forecast_error", "wind_forecast_error")
    )
    assert payload["metadata"]["scenario_hash"] == scenario.content_hash()


def test_legacy_v2_json_is_adapted_to_canonical_output():
    source = generate_information_aware_scenario(42)
    legacy_payload = {
        "seed": source.seed,
        "params": source.params,
        "depot": list(source.depot),
        "nodes": [dataclasses.asdict(node) for node in source.nodes],
        "initial_inventory": list(source.initial_inventory),
        "no_fly_zones": [dataclasses.asdict(zone) for zone in source.no_fly_zones],
        "hazard_regions": [dataclasses.asdict(region) for region in source.hazard_regions],
        "airspace_updates": [
            dataclasses.asdict(update) for update in source.airspace_updates
        ],
        "wind_spec": {
            **source.wind_spec,
            "truth_keyframes": [[0.0, 0.0, 0.0], [12.0, 0.0, 0.0]],
        },
        "generation_metadata": {"schema": "information-aware-routing-v2"},
    }

    migrated = Scenario.from_dict(legacy_payload)
    canonical = migrated.to_dict()

    assert migrated.seed == 42
    assert len(migrated.nodes) == 20
    assert canonical["schema_version"] != "information-aware-routing-v2"
    assert canonical["metadata"]["seed"] == 42
    assert canonical["environment_packets"]
    assert "truth_keyframes" not in json.dumps(canonical)


def test_scenario_hash_is_stable_when_only_embedded_hash_changes():
    scenario = generate_information_aware_scenario(7)
    payload = scenario.to_dict()
    expected = scenario.content_hash()
    payload["metadata"]["scenario_hash"] = "different"

    restored = Scenario.from_dict(payload)

    assert restored.content_hash() == expected
    assert restored.to_dict()["metadata"]["scenario_hash"] == expected
