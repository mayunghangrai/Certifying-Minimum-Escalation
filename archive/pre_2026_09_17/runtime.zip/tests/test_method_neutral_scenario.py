"""Method-neutral contracts for the canonical information-aware scenario."""

from __future__ import annotations

import dataclasses
from pathlib import Path

import pytest

from env.params import EnvParams
from env.robust_scenario_generator import (
    generate_information_aware_scenario,
    load_information_aware_config,
)


ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "configs" / "env" / "information_aware_routes.yaml"


def test_environment_parameters_reject_unknown_sections_and_fields():
    with pytest.raises(ValueError, match="unknown environment sections"):
        EnvParams.from_dict({"obsolete_method": {"iterations": 10}})
    with pytest.raises(ValueError, match="unknown physics keys"):
        EnvParams.from_dict({"physics": {"unmodelled_drag": 1.0}})


def test_information_aware_config_has_only_method_neutral_sections():
    params, route_information, objective = load_information_aware_config(CONFIG)

    assert set(params.to_dict()) == {
        "physics", "commodities", "map", "route_validation", "mission"
    }
    assert route_information.mode == "mixed"
    assert params.map.n_nodes == 20
    assert params.mission.M == 3
    assert params.mission.T == pytest.approx(12.0)
    # Documented a priori fairness weight from the YAML objective section.
    assert objective.lambda_fair == pytest.approx(0.25)


def test_generated_scenario_uses_known_task_v3_schema():
    params, route_information, objective = load_information_aware_config(CONFIG)
    del objective
    scenario = generate_information_aware_scenario(42, params, route_information)
    payload = scenario.to_dict()

    assert set(payload) == {
        "schema_version", "metadata", "mission", "depot", "commodities",
        "relief_nodes", "fleet", "network", "environment_packets",
        "scenario_descriptors",
    }
    assert payload["schema_version"] == "information-aware-routing-v3"
    assert set(payload["metadata"]) == {
        "seed", "generator_version", "config_hash", "scenario_hash"
    }
    assert payload["mission"] == {
        "horizon_h": 12.0,
        "environment_update_interval_h": 0.5,
        "forecast_horizon_h": 1.5,
    }
    assert set(payload["relief_nodes"][0]) == {
        "id", "position", "priority", "vulnerability", "demand"
    }
    assert len(payload["relief_nodes"]) == 20
    assert len(payload["fleet"]) == 3
    assert len(payload["network"]["edges"]) == 40
    assert len(payload["environment_packets"]) == 24
    assert all(sum(node["demand"]) > 0.0 for node in payload["relief_nodes"])
    assert "truth_keyframes" not in str(payload)
    assert "forecast_error" not in str(payload)
    assert all(update.time_h >= 0.0 for update in scenario.airspace_updates)


def test_disabling_weather_polygons_does_not_change_tasks_airspace_or_wind():
    params, mixed, _objective = load_information_aware_config(CONFIG)
    without_weather = dataclasses.replace(mixed, mode="airspace")

    a = generate_information_aware_scenario(42, params, mixed)
    b = generate_information_aware_scenario(42, params, without_weather)

    assert a.nodes == b.nodes
    assert a.no_fly_zones == b.no_fly_zones
    assert a.wind_spec == b.wind_spec
    assert a.hazard_regions
    assert b.hazard_regions == []


def test_generator_is_deterministic_and_tasks_are_seed_sensitive():
    params, route_information, _objective = load_information_aware_config(CONFIG)

    first = generate_information_aware_scenario(42, params, route_information)
    repeated = generate_information_aware_scenario(42, params, route_information)
    different = generate_information_aware_scenario(43, params, route_information)

    assert first.content_hash() == repeated.content_hash()
    assert first.nodes == repeated.nodes
    assert first.nodes != different.nodes
