import subprocess
import sys
from pathlib import Path

from env.scenario import Scenario


ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "configs" / "env" / "information_aware_routes.yaml"


def test_renderer_consumes_canonical_packets_without_truth_or_forecast_error_ui(tmp_path):
    scenario_path = tmp_path / "scenario.json"
    html_path = tmp_path / "scenario.html"
    generated = subprocess.run(
        [
            sys.executable,
            str(ROOT / "scripts" / "generate_information_aware_scenario.py"),
            "--seed", "42",
            "--config", str(CONFIG),
            "--output", str(scenario_path),
        ],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
    )
    assert generated.returncode == 0, generated.stderr
    scenario = Scenario.from_json(scenario_path)

    rendered = subprocess.run(
        [
            sys.executable,
            str(ROOT / "scripts" / "render_information_aware_scenario.py"),
            "--input", str(scenario_path),
            "--output", str(html_path),
        ],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
    )
    assert rendered.returncode == 0, rendered.stderr
    html = html_path.read_text(encoding="utf-8")

    assert scenario.content_hash() in html
    assert "Current authoritative wind" in html
    assert "Packet revision" in html
    assert 'data-role="impact-closure"' in html
    assert "Controlled packet-revision disturbance-impact closure" in html
    assert "Directly affected legs" in html
    assert "Propagated legs" in html
    assert "ETA delta" in html
    assert "Energy delta" in html
    assert "Deadline slack" in html
    assert 'data-role="packet-horizon"' in html
    assert "environment_packets" in html
    assert "fetch(" not in html
    assert "truth_keyframes" not in html
    assert "forecast_error" not in html
    assert "latent truth" not in html.lower()
