# Online Information-Aware Multi-UAV Routing Core

This repository provides a clean, method-neutral research environment for
post-disaster UAV routing. Every relief task is known at mission time zero;
weather, temporary airspace restrictions, and rolling environmental packets
change the feasibility and energy cost of routes online.

The code intentionally does **not** choose task assignments, visit sequences,
routes, or replacement paths. Algorithm selection is deferred. A future method
can propose decisions through the executor’s command interface and can be
compared on identical frozen scenarios.

## Current scope

- Exact task locations, four-commodity demands, vulnerabilities, and depot
  inventory at time zero.
- Seeded weather polygons and temporary no-fly regions revealed when they take
  effect.
- Seeded global two-dimensional wind packets with rolling, revisable horizons.
- Constant-airspeed flight: wind changes both travel time and energy along a
  directed segment, so a packet revision directly changes ETAs and battery
  feasibility.
- Strict packet coverage: an uncovered route has unknown battery feasibility.
- Pure evaluation of caller-supplied polylines; no route construction.
- Event-driven execution of caller commands with mid-flight packet-update
  interruptions and no automatic replanning.
- Known humanitarian priorities per relief node, and exact metrics: priority-
  weighted delivery time, maximin fill-ratio fairness, deprivation, energy,
  violations, and fill rate. The optimization objective is the normalized
  priority-weighted delivery time plus a configurable fairness term
  (`src/env/objective.py`); energy and safe return are hard feasibility
  constraints, not objective terms.

Unknown demand, sensing tasks, victim discovery, three-dimensional wind,
spatial wind grids, and a routing/allocation algorithm are outside this
milestone.

## Repository layout

- `src/env/robust_scenario_generator.py` is the only scenario generator.
- `src/env/scenario.py` defines the canonical replayable packet schema and the
  explicit legacy migration adapter.
- `src/env/airspace.py` and `src/env/wind.py` hold online environmental state.
- `src/env/energy.py` and `src/env/route_evaluator.py` evaluate supplied paths.
- `src/env/simulator.py` executes explicit prepare, dispatch, deliver, and
  advance commands.
- `scripts/` generates and renders the canonical scenario.
- `configs/env/information_aware_routes.yaml` is the canonical configuration.
- `scenarios/information_aware/seed_42.json` is the frozen 20-node scenario.
- `outputs/information_aware_seed_42.html` is its self-contained inspection page.
- `tests/` enforces reproducibility, no leakage, physics, and command behavior.

## Information boundary

The scenario JSON stores the full exogenous packet timeline so experiments are
exactly replayable. The online snapshot exposes only current tasks and fleet
state, active geometry-derived regions, and the latest packet whose issue time
has passed. It never exposes future packets or an unobserved truth/error stream.

An environmental packet during flight settles the UAV at its physically
integrated position under the previous packet, accounts for packet-aware
energy, cancels the pending arrival, and changes the UAV to `AWAITING_ROUTE`.
The committed remainder can be resumed explicitly with the same geometry after
the new packet is received.

At a packet-update decision epoch, `env.diagnostics.diagnose_packet_update`
can compare an externally supplied incumbent plan suffix under the previous
and received packets. It returns a read-only disturbance-impact closure with
directly touched legs, downstream ETA/energy/deadline propagation, reserve
effects, and canonical infeasibility reasons. The comparison consumes only
the two packet arguments, static scenario geometry/vehicle data, and the
supplied snapshot; it does not choose or repair a route and does not inspect
the unrevealed packet timeline.

For an incumbent route that revisits the observed stop, provide the entry's
zero-based `current_route_index`; ambiguous repeated stops are rejected rather
than guessed (the ordinary initial/terminal depot pair defaults to the
initial depot). The simulator convenience wrapper is usable only before the
next controller command.

## Reproduce seed 42

From the repository root:

```powershell
python scripts/generate_information_aware_scenario.py --seed 42 --config configs/env/information_aware_routes.yaml --output scenarios/information_aware/seed_42.json
python scripts/render_information_aware_scenario.py --input scenarios/information_aware/seed_42.json --output outputs/information_aware_seed_42.html
```

The JSON includes a deterministic SHA-256 content hash. The HTML embeds the
scenario and uses no network requests.

To run the deterministic core-physics verification mission and print its
separate runtime trace:

```powershell
python scripts/verify_core_uav_physics.py --scenario scenarios/information_aware/seed_42.json
```

The report contains only packets encountered by the fixed execution. Runtime
logs are not written into the frozen scenario JSON.

## Use the executor

```python
from env.simulator import RoutingSimulator

sim = RoutingSimulator()
snapshot = sim.reset(scenario)
sim.prepare(0, [1.0, 0.0, 0.0, 0.0])
snapshot = sim.advance()
sim.dispatch(0, destination=3, waypoints_xy=[[6.0, 6.0], [7.2, 5.4]])
snapshot = sim.advance()
```

The example waypoints are external input, not a route produced by this package.

## Run tests

```powershell
$env:PYTHONDONTWRITEBYTECODE='1'
python -m pytest -p no:cacheprovider tests -q
```
