"""Lean parameters for known-task, information-aware route execution.

Canonical physical units are kilometres, hours, km/h, kilograms, and Wh.
Power is represented in watts; with the configured coefficient this is
numerically ``Wh / (km * kg) * kg * km/h``.  The parameter model deliberately
contains no solver or learning settings.
"""

from __future__ import annotations

import dataclasses
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Mapping, TypeVar

import numpy as np


N_COMMODITIES = 4
COMMODITY_NAMES = ("medical", "food", "water", "shelter")
# These tolerances are for floating-point comparisons only.  They must never
# be used to make an invalid physical square-root argument valid.
DISTANCE_TOL_KM = 1e-9
TIME_TOL_H = 1e-9
ENERGY_TOL_WH = 1e-9
STATE_TOL = 1e-9
_T = TypeVar("_T")


def _finite_positive(name: str, value: float, *, allow_zero: bool = False) -> None:
    try:
        number = float(value)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{name} must be numeric") from error
    if not math.isfinite(number) or (number < 0.0 if allow_zero else number <= 0.0):
        condition = "nonnegative" if allow_zero else "positive"
        raise ValueError(f"{name} must be finite and {condition}")


def _strict_dataclass(klass: type[_T], payload: Mapping[str, Any] | None,
                      section: str) -> _T:
    values = dict(payload or {})
    valid = {item.name for item in dataclasses.fields(klass)}
    unknown = sorted(set(values) - valid)
    if unknown:
        raise ValueError(f"unknown {section} keys: {unknown}")
    return klass(**values)


@dataclass
class PhysicsParams:
    W_max: float = 2.5
    m0: float = 4.0
    B_max: float = 230.0
    e_c: float = 3.125
    e_v: float = 2.5
    beta_safe: float = 23.0
    v_uav: float = 60.0

    def __post_init__(self) -> None:
        for name in ("W_max", "m0", "B_max", "e_c", "v_uav"):
            _finite_positive(f"physics.{name}", getattr(self, name))
        for name in ("e_v", "beta_safe"):
            _finite_positive(f"physics.{name}", getattr(self, name), allow_zero=True)
        if self.beta_safe >= self.B_max:
            raise ValueError("physics.beta_safe must be below B_max")


@dataclass
class CommodityParams:
    w_k: List[float] = field(default_factory=lambda: [0.25, 0.5, 1.0, 2.5])
    lambda_k: List[float] = field(default_factory=lambda: [4.0, 2.0, 3.0, 1.0])
    alpha_k: List[float] = field(default_factory=lambda: [1.0, 1.0, 1.0, 1.0])
    kappa_k: List[float] = field(default_factory=lambda: [0.35, 0.20, 0.30, 0.10])

    def __post_init__(self) -> None:
        for name in ("w_k", "lambda_k", "alpha_k", "kappa_k"):
            values = [float(value) for value in getattr(self, name)]
            if len(values) != N_COMMODITIES:
                raise ValueError(f"commodities.{name} must have {N_COMMODITIES} values")
            if not all(math.isfinite(value) and value >= 0.0 for value in values):
                raise ValueError(f"commodities.{name} must be finite and nonnegative")
            setattr(self, name, values)
        if any(value <= 0.0 for value in self.w_k):
            raise ValueError("commodities.w_k must be positive")

    def as_arrays(self):
        return tuple(np.asarray(getattr(self, name), dtype=float)
                     for name in ("w_k", "lambda_k", "alpha_k", "kappa_k"))


@dataclass
class MapParams:
    region_km: float = 12.0
    n_nodes: int = 20
    n_clusters: int = 3
    cluster_std_km: float = 0.9
    feasible_frac: float = 0.95
    min_node_sep_km: float = 0.35
    nu_range: List[float] = field(default_factory=lambda: [0.5, 3.0])
    priority_range: List[float] = field(default_factory=lambda: [0.5, 1.5])
    demand_mean_k: List[float] = field(default_factory=lambda: [2.0, 3.0, 2.5, 0.8])

    def __post_init__(self) -> None:
        if isinstance(self.n_nodes, bool) or int(self.n_nodes) != self.n_nodes or self.n_nodes <= 0:
            raise ValueError("map.n_nodes must be a positive integer")
        if isinstance(self.n_clusters, bool) or int(self.n_clusters) != self.n_clusters or self.n_clusters <= 0:
            raise ValueError("map.n_clusters must be a positive integer")
        self.n_nodes = int(self.n_nodes)
        self.n_clusters = int(self.n_clusters)
        if self.n_clusters > self.n_nodes:
            raise ValueError("map.n_clusters cannot exceed n_nodes")
        for name in ("region_km", "cluster_std_km", "min_node_sep_km"):
            _finite_positive(f"map.{name}", getattr(self, name))
        _finite_positive("map.feasible_frac", self.feasible_frac)
        if self.feasible_frac > 1.0:
            raise ValueError("map.feasible_frac must not exceed 1")
        self.nu_range = [float(value) for value in self.nu_range]
        if len(self.nu_range) != 2 or not (0.0 < self.nu_range[0] < self.nu_range[1]):
            raise ValueError("map.nu_range must satisfy 0 < low < high")
        self.priority_range = [float(value) for value in self.priority_range]
        if len(self.priority_range) != 2 or any(
            not math.isfinite(value) for value in self.priority_range
        ) or not (0.0 < self.priority_range[0] <= self.priority_range[1]):
            raise ValueError("map.priority_range must satisfy 0 < low <= high")
        self.demand_mean_k = [float(value) for value in self.demand_mean_k]
        if len(self.demand_mean_k) != N_COMMODITIES or any(
            not math.isfinite(value) or value <= 0.0 for value in self.demand_mean_k
        ):
            raise ValueError("map.demand_mean_k must contain four positive values")


@dataclass
class RouteValidationParams:
    safe_corridor_margin_m: float = 20.0

    def __post_init__(self) -> None:
        _finite_positive("route_validation.safe_corridor_margin_m",
                         self.safe_corridor_margin_m, allow_zero=True)


@dataclass
class MissionParams:
    T: float = 12.0
    M: int = 3
    environment_update_interval_h: float = 0.5
    forecast_horizon_h: float = 1.5
    load_time_h: float = 0.15
    charge_time_h: float = 0.5
    service_time_h: float = 0.02
    n_depot_bays: int = 2

    def __post_init__(self) -> None:
        _finite_positive("mission.T", self.T)
        for name in (
            "environment_update_interval_h",
            "forecast_horizon_h",
            "load_time_h",
            "charge_time_h",
            "service_time_h",
        ):
            _finite_positive(f"mission.{name}", getattr(self, name), allow_zero=True)
        for name in ("M", "n_depot_bays"):
            value = getattr(self, name)
            if isinstance(value, bool) or int(value) != value or value <= 0:
                raise ValueError(f"mission.{name} must be a positive integer")
            setattr(self, name, int(value))

    @property
    def horizon_h(self) -> float:
        """Canonical scenario alias for the legacy ``T`` field."""
        return float(self.T)

    @property
    def fleet_size(self) -> int:
        """Canonical scenario alias for the legacy ``M`` field."""
        return int(self.M)


@dataclass
class EnvParams:
    physics: PhysicsParams = field(default_factory=PhysicsParams)
    commodities: CommodityParams = field(default_factory=CommodityParams)
    map: MapParams = field(default_factory=MapParams)
    route_validation: RouteValidationParams = field(default_factory=RouteValidationParams)
    mission: MissionParams = field(default_factory=MissionParams)

    def to_dict(self) -> Dict[str, Any]:
        return dataclasses.asdict(self)

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any] | None) -> "EnvParams":
        values = dict(payload or {})
        loaders = {
            "physics": PhysicsParams,
            "commodities": CommodityParams,
            "map": MapParams,
            "route_validation": RouteValidationParams,
            "mission": MissionParams,
        }
        unknown = sorted(set(values) - set(loaders))
        if unknown:
            raise ValueError(f"unknown environment sections: {unknown}")
        return cls(**{
            name: _strict_dataclass(klass, values.get(name), name)
            for name, klass in loaders.items()
        })

    @classmethod
    def from_yaml(cls, path: str | Path) -> "EnvParams":
        import yaml

        with open(path, "r", encoding="utf-8") as handle:
            return cls.from_dict(yaml.safe_load(handle) or {})
