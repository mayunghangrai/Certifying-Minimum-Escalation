"""Physical state owned by the method-neutral routing executor."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Mapping, Optional

import numpy as np

from .params import N_COMMODITIES


@dataclass(frozen=True)
class UAVParameters:
    """Physical parameters carried by one canonical fleet record."""

    id: str
    nominal_airspeed_kmh: float
    empty_mass_kg: float
    max_payload_kg: float
    battery_capacity_wh: float
    reserve_requirement_wh: float
    energy_coefficient_wh_per_km_kg: float
    service_energy_wh: float

    def __post_init__(self) -> None:
        vehicle_id = str(self.id)
        if not vehicle_id:
            raise ValueError("UAV id must be nonempty")
        object.__setattr__(self, "id", vehicle_id)
        for name in (
            "nominal_airspeed_kmh",
            "empty_mass_kg",
            "max_payload_kg",
            "battery_capacity_wh",
            "energy_coefficient_wh_per_km_kg",
        ):
            value = float(getattr(self, name))
            if not np.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive")
            object.__setattr__(self, name, value)
        reserve = float(self.reserve_requirement_wh)
        service = float(self.service_energy_wh)
        if not np.isfinite(reserve) or reserve < 0.0:
            raise ValueError("reserve_requirement_wh must be finite and nonnegative")
        if not np.isfinite(service) or service < 0.0:
            raise ValueError("service_energy_wh must be finite and nonnegative")
        if reserve >= float(self.battery_capacity_wh):
            raise ValueError("reserve_requirement_wh must be below battery capacity")
        object.__setattr__(self, "reserve_requirement_wh", reserve)
        object.__setattr__(self, "service_energy_wh", service)

    @property
    def v_uav(self) -> float:
        return self.nominal_airspeed_kmh

    @property
    def m0(self) -> float:
        return self.empty_mass_kg

    @property
    def W_max(self) -> float:
        return self.max_payload_kg

    @property
    def B_max(self) -> float:
        return self.battery_capacity_wh

    @property
    def beta_safe(self) -> float:
        return self.reserve_requirement_wh

    @property
    def e_c(self) -> float:
        return self.energy_coefficient_wh_per_km_kg

    @property
    def e_v(self) -> float:
        return self.service_energy_wh

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "nominal_airspeed_kmh": self.nominal_airspeed_kmh,
            "empty_mass_kg": self.empty_mass_kg,
            "max_payload_kg": self.max_payload_kg,
            "battery_capacity_wh": self.battery_capacity_wh,
            "reserve_requirement_wh": self.reserve_requirement_wh,
            "energy_coefficient_wh_per_km_kg": self.energy_coefficient_wh_per_km_kg,
            "service_energy_wh": self.service_energy_wh,
        }

    @classmethod
    def from_dict(cls, payload: Mapping) -> "UAVParameters":
        return cls(
            id=payload["id"],
            nominal_airspeed_kmh=payload["nominal_airspeed_kmh"],
            empty_mass_kg=payload["empty_mass_kg"],
            max_payload_kg=payload["max_payload_kg"],
            battery_capacity_wh=payload["battery_capacity_wh"],
            reserve_requirement_wh=payload["reserve_requirement_wh"],
            energy_coefficient_wh_per_km_kg=payload["energy_coefficient_wh_per_km_kg"],
            service_energy_wh=payload["service_energy_wh"],
        )

    @classmethod
    def from_physics(cls, index: int, physics) -> "UAVParameters":
        return cls(
            id=f"UAV-{int(index):02d}",
            nominal_airspeed_kmh=physics.v_uav,
            empty_mass_kg=physics.m0,
            max_payload_kg=physics.W_max,
            battery_capacity_wh=physics.B_max,
            reserve_requirement_wh=physics.beta_safe,
            energy_coefficient_wh_per_km_kg=physics.e_c,
            service_energy_wh=physics.e_v,
        )


FleetVehicle = UAVParameters
UAVSpec = UAVParameters


class Mode(Enum):
    DEPOT = "depot"
    PREPARING = "preparing"
    READY = "ready"
    FLYING = "flying"
    AT_NODE = "at_node"
    SERVICING = "servicing"
    AWAITING_ROUTE = "awaiting_route"


def _commodity_vector(values, name: str) -> np.ndarray:
    vector = np.asarray(values, dtype=float).copy()
    if vector.shape != (N_COMMODITIES,):
        raise ValueError(f"{name} must contain {N_COMMODITIES} quantities")
    if not np.all(np.isfinite(vector)) or np.any(vector < 0.0):
        raise ValueError(f"{name} must be finite and nonnegative")
    return vector


@dataclass
class DemandNodeState:
    idx: int
    position: np.ndarray
    vulnerability: float
    initial_demand: np.ndarray
    remaining_demand: np.ndarray
    priority: float = 1.0

    def __post_init__(self) -> None:
        self.position = np.asarray(self.position, dtype=float).copy()
        if self.position.shape != (2,) or not np.all(np.isfinite(self.position)):
            raise ValueError("node position must contain two finite coordinates")
        self.initial_demand = _commodity_vector(self.initial_demand, "initial_demand")
        self.remaining_demand = _commodity_vector(
            self.remaining_demand, "remaining_demand"
        )
        if np.any(self.remaining_demand > self.initial_demand + 1e-9):
            raise ValueError("remaining demand cannot exceed initial demand")
        self.vulnerability = float(self.vulnerability)
        if not np.isfinite(self.vulnerability) or self.vulnerability <= 0.0:
            raise ValueError("node vulnerability must be finite and positive")
        self.priority = float(self.priority)
        if not np.isfinite(self.priority) or self.priority <= 0.0:
            raise ValueError("node priority must be finite and positive")


@dataclass
class UAVState:
    idx: int
    position: np.ndarray
    battery: float
    payload: np.ndarray = field(default_factory=lambda: np.zeros(N_COMMODITIES))
    mode: Mode = Mode.DEPOT
    current_node: Optional[int] = None
    destination: Optional[int] = None
    active_route: Optional[np.ndarray] = None
    route_departure_h: float = 0.0
    route_arrival_h: float = 0.0
    waypoint_event_id: Optional[int] = None
    pending_load: np.ndarray = field(default_factory=lambda: np.zeros(N_COMMODITIES))
    pending_delivery: np.ndarray = field(default_factory=lambda: np.zeros(N_COMMODITIES))
    battery_capacity_wh: Optional[float] = None
    pending_route: Optional[np.ndarray] = None
    pending_destination: Optional[int] = None
    pending_packet_id: Optional[str] = None

    def __post_init__(self) -> None:
        self.position = np.asarray(self.position, dtype=float).copy()
        if self.position.shape != (2,) or not np.all(np.isfinite(self.position)):
            raise ValueError("UAV position must contain two finite coordinates")
        self.payload = _commodity_vector(self.payload, "payload")
        self.pending_load = _commodity_vector(self.pending_load, "pending_load")
        self.pending_delivery = _commodity_vector(
            self.pending_delivery, "pending_delivery"
        )
        self.battery = float(self.battery)
        if not np.isfinite(self.battery) or self.battery < 0.0:
            raise ValueError("UAV battery must be finite and nonnegative")
        if self.battery_capacity_wh is not None:
            capacity = float(self.battery_capacity_wh)
            if not np.isfinite(capacity) or capacity <= 0.0:
                raise ValueError("UAV battery capacity must be finite and positive")
            if self.battery > capacity + 1e-9:
                raise ValueError("UAV battery cannot exceed battery capacity")
            self.battery_capacity_wh = capacity
        if self.active_route is not None:
            self.active_route = np.asarray(self.active_route, dtype=float).copy()
        if self.pending_route is not None:
            self.pending_route = np.asarray(self.pending_route, dtype=float).copy()

    def payload_mass(self, unit_masses: np.ndarray) -> float:
        return float(np.dot(np.asarray(unit_masses, dtype=float), self.payload))


@dataclass
class DepotInventory:
    quantities: np.ndarray
    bay_available_h: np.ndarray

    def __post_init__(self) -> None:
        self.quantities = _commodity_vector(self.quantities, "inventory")
        self.bay_available_h = np.asarray(self.bay_available_h, dtype=float).copy()
        if self.bay_available_h.ndim != 1 or len(self.bay_available_h) == 0:
            raise ValueError("at least one depot bay is required")
        if not np.all(np.isfinite(self.bay_available_h)) or np.any(
            self.bay_available_h < 0.0
        ):
            raise ValueError("bay availability times must be finite and nonnegative")

    def can_reserve(self, quantities: np.ndarray) -> bool:
        return bool(np.all(quantities <= self.quantities + 1e-9))

    def reserve(self, quantities: np.ndarray) -> None:
        if not self.can_reserve(quantities):
            raise ValueError("requested quantities exceed available inventory")
        updated = self.quantities - np.asarray(quantities, dtype=float)
        if np.any(updated < -1e-9):
            raise ValueError("requested quantities exceed available inventory")
        updated[updated < 0.0] = 0.0
        self.quantities = updated

    def allocate_bay(self, now_h: float, duration_h: float) -> float:
        bay = int(np.argmin(self.bay_available_h))
        start = max(float(now_h), float(self.bay_available_h[bay]))
        finish = start + float(duration_h)
        self.bay_available_h[bay] = finish
        return finish
