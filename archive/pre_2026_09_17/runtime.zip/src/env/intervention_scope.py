"""Method-neutral validation for interventions on a remaining mission plan.

The contract describes how much of an already proposed plan may change after a
forecast is received.  It validates externally supplied candidate plans and
delegates feasibility to a caller-provided forecast oracle; it never constructs
or optimizes a plan.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum
from types import MappingProxyType
from typing import Any, Callable, Iterable, Mapping, Optional, TypeVar


_PATH = "path"
_SEQUENCE = "sequence"
_ASSIGNMENT = "assignment"
_DIMENSIONS = frozenset({_PATH, _SEQUENCE, _ASSIGNMENT})


class InterventionScope(IntEnum):
    """Cumulative intervention levels for the uncommitted remaining plan."""

    RETAIN = 0
    PATH_ONLY = 1
    SEQUENCE_ONLY = 2
    AFFECTED_TASK_REASSIGNMENT = 3
    UNRESTRICTED = 4

    @classmethod
    def coerce(cls, value: "InterventionScope | int") -> "InterventionScope":
        if isinstance(value, bool):
            raise ValueError("intervention scope must be an integer from 0 to 4")
        if isinstance(value, cls):
            return value
        try:
            return cls(int(value))
        except (TypeError, ValueError) as error:
            raise ValueError(
                "intervention scope must be one of 0, 1, 2, 3, or 4"
            ) from error


_SCOPE_PERMISSIONS: Mapping[InterventionScope, frozenset[str]] = {
    InterventionScope.RETAIN: frozenset(),
    InterventionScope.PATH_ONLY: frozenset({_PATH}),
    # This level is cumulative so the hierarchy remains nested: sequence
    # repair may also need to update paths for the new order.
    InterventionScope.SEQUENCE_ONLY: frozenset({_PATH, _SEQUENCE}),
    InterventionScope.AFFECTED_TASK_REASSIGNMENT: frozenset(
        {_PATH, _SEQUENCE, _ASSIGNMENT}
    ),
    InterventionScope.UNRESTRICTED: _DIMENSIONS,
}


def scope_permissions(
    scope: InterventionScope | int,
) -> frozenset[str]:
    """Return the cumulative decision dimensions permitted by ``scope``."""

    return _SCOPE_PERMISSIONS[InterventionScope.coerce(scope)]


def validate_scope_hierarchy() -> bool:
    """Verify that each higher scope contains every lower-scope permission."""

    scopes = list(InterventionScope)
    for lower, higher in zip(scopes[:-1], scopes[1:]):
        if not scope_permissions(lower) <= scope_permissions(higher):
            raise ValueError(
                f"intervention scope {int(lower)} is not nested in "
                f"scope {int(higher)}"
            )
    return True


def _freeze_value(value: Any) -> Any:
    """Copy common container values into equality-safe immutable values."""

    if isinstance(value, Mapping):
        items = [(_freeze_value(key), _freeze_value(item)) for key, item in value.items()]
        return tuple(sorted(items, key=repr))
    if isinstance(value, (list, tuple)):
        return tuple(_freeze_value(item) for item in value)
    if isinstance(value, (set, frozenset)):
        return frozenset(_freeze_value(item) for item in value)
    return value


def _json_value(value: Any) -> Any:
    if isinstance(value, tuple):
        return [_json_value(item) for item in value]
    if isinstance(value, frozenset):
        return sorted((_json_value(item) for item in value), key=repr)
    return value


@dataclass(frozen=True)
class TaskDecision:
    """The remaining-plan decisions associated with one task.

    A committed task is immutable as a whole: its assignment, sequence
    position, and path must all remain equal in every candidate plan,
    including an unrestricted candidate.
    """

    task_id: str
    uav_id: str
    sequence: int
    path: tuple[Any, ...]
    committed: bool = False

    def __post_init__(self) -> None:
        if not isinstance(self.task_id, str) or not self.task_id:
            raise ValueError("task_id must be a nonempty string")
        if not isinstance(self.uav_id, str) or not self.uav_id:
            raise ValueError("uav_id must be a nonempty string")
        if isinstance(self.sequence, bool):
            raise ValueError("sequence must be a nonnegative integer")
        try:
            sequence = int(self.sequence)
        except (TypeError, ValueError) as error:
            raise ValueError("sequence must be a nonnegative integer") from error
        if sequence != self.sequence or sequence < 0:
            raise ValueError("sequence must be a nonnegative integer")
        if isinstance(self.path, (str, bytes)):
            raise ValueError("path must be an ordered sequence")
        try:
            path = tuple(_freeze_value(item) for item in self.path)
        except TypeError as error:
            raise ValueError("path must be an ordered sequence") from error
        if not isinstance(self.committed, bool):
            raise ValueError("committed must be boolean")
        object.__setattr__(self, "sequence", sequence)
        object.__setattr__(self, "path", path)

    def to_dict(self) -> dict[str, Any]:
        return {
            "task_id": self.task_id,
            "uav_id": self.uav_id,
            "sequence": self.sequence,
            "path": [_json_value(item) for item in self.path],
            "committed": self.committed,
        }


@dataclass(frozen=True)
class MissionPlan:
    """An externally supplied remaining plan, keyed by task identifier."""

    decisions: Mapping[str, TaskDecision]

    def __post_init__(self) -> None:
        if not isinstance(self.decisions, Mapping):
            raise ValueError("mission plan decisions must be a mapping")
        normalized: dict[str, TaskDecision] = {}
        sequence_positions: dict[str, set[int]] = {}
        for task_id, decision in self.decisions.items():
            if not isinstance(task_id, str) or not task_id:
                raise ValueError("mission plan task keys must be nonempty strings")
            if not isinstance(decision, TaskDecision):
                raise ValueError(
                    f"mission plan decision for {task_id!r} must be TaskDecision"
                )
            if decision.task_id != task_id:
                raise ValueError(
                    f"mission plan key {task_id!r} does not match decision task_id"
                )
            positions = sequence_positions.setdefault(decision.uav_id, set())
            if decision.sequence in positions:
                raise ValueError(
                    f"UAV {decision.uav_id!r} has duplicate sequence position "
                    f"{decision.sequence}"
                )
            positions.add(decision.sequence)
            normalized[task_id] = decision
        object.__setattr__(self, "decisions", MappingProxyType(normalized))

    @property
    def task_ids(self) -> frozenset[str]:
        return frozenset(self.decisions)

    def to_dict(self) -> dict[str, dict[str, Any]]:
        return {
            task_id: decision.to_dict()
            for task_id, decision in sorted(self.decisions.items())
        }


class ScopeViolation(ValueError):
    """Raised when a candidate plan exceeds its declared intervention scope."""

    def __init__(self, violations: Iterable[str]):
        self.violations = tuple(str(violation) for violation in violations)
        if not self.violations:
            raise ValueError("ScopeViolation requires at least one violation")
        super().__init__("; ".join(self.violations))


def _changed_dimensions(
    before: TaskDecision,
    after: TaskDecision,
) -> frozenset[str]:
    changed: set[str] = set()
    if before.uav_id != after.uav_id:
        changed.add(_ASSIGNMENT)
    if before.sequence != after.sequence:
        changed.add(_SEQUENCE)
    if before.path != after.path:
        changed.add(_PATH)
    return frozenset(changed)


def scope_violations(
    baseline: MissionPlan,
    candidate: MissionPlan,
    scope: InterventionScope | int,
    *,
    affected_tasks: Iterable[str] = (),
) -> tuple[str, ...]:
    """Return all contract violations for a candidate at ``scope``.

    The candidate must contain exactly the same remaining task set.  The
    ``affected_tasks`` restriction applies only to assignment changes at
    ``k=3``; all other permissions remain cumulative.
    """

    if not isinstance(baseline, MissionPlan):
        raise TypeError("baseline must be a MissionPlan")
    if not isinstance(candidate, MissionPlan):
        raise TypeError("candidate must be a MissionPlan")
    level = InterventionScope.coerce(scope)
    affected = frozenset(str(task_id) for task_id in affected_tasks)
    violations: list[str] = []

    if baseline.task_ids != candidate.task_ids:
        violations.append("remaining task set changed")

    if level is InterventionScope.AFFECTED_TASK_REASSIGNMENT:
        unknown = sorted(affected - baseline.task_ids)
        violations.extend(
            f"affected task {task_id!r} is not in the remaining task set"
            for task_id in unknown
        )

    for task_id in sorted(baseline.task_ids & candidate.task_ids):
        before = baseline.decisions[task_id]
        after = candidate.decisions[task_id]
        changed = _changed_dimensions(before, after)

        if before.committed:
            if before != after:
                violations.append(
                    f"committed decision changed for task {task_id!r}"
                )
            continue
        if before.committed != after.committed:
            violations.append(
                f"commitment status changed for task {task_id!r}"
            )

        for dimension in sorted(changed):
            if dimension not in scope_permissions(level):
                violations.append(
                    f"{dimension} change for task {task_id!r} is not permitted "
                    f"at scope k={int(level)}"
                )
                continue
            if (
                dimension == _ASSIGNMENT
                and level is InterventionScope.AFFECTED_TASK_REASSIGNMENT
                and task_id not in affected
            ):
                violations.append(
                    f"assignment changed for task {task_id!r}, which is not affected"
                )
    return tuple(violations)


def validate_scope_change(
    baseline: MissionPlan,
    candidate: MissionPlan,
    scope: InterventionScope | int,
    *,
    affected_tasks: Iterable[str] = (),
) -> None:
    """Raise ``ScopeViolation`` unless ``candidate`` fits ``scope``."""

    violations = scope_violations(
        baseline,
        candidate,
        scope,
        affected_tasks=affected_tasks,
    )
    if violations:
        raise ScopeViolation(violations)


@dataclass(frozen=True)
class ScopeEvaluation:
    """Validation and forecast-feasibility result for one scope level."""

    scope: InterventionScope
    compliant: bool
    feasible: Optional[bool]
    violations: tuple[str, ...] = ()

    @property
    def valid(self) -> bool:
        return self.compliant

    def to_dict(self) -> dict[str, Any]:
        return {
            "scope": int(self.scope),
            "compliant": self.compliant,
            "feasible": self.feasible,
            "violations": list(self.violations),
        }


@dataclass(frozen=True)
class ScopeAssessment:
    """Ordered report of the supplied candidates and their minimum scope."""

    minimum_scope: Optional[InterventionScope]
    evaluations: tuple[ScopeEvaluation, ...]

    @property
    def smallest_feasible_scope(self) -> Optional[InterventionScope]:
        return self.minimum_scope

    def to_dict(self) -> dict[str, Any]:
        return {
            "smallest_feasible_scope": (
                None if self.minimum_scope is None else int(self.minimum_scope)
            ),
            "evaluations": [evaluation.to_dict() for evaluation in self.evaluations],
        }


ForecastT = TypeVar("ForecastT")


def smallest_feasible_scope(
    baseline: MissionPlan,
    candidates: Mapping[InterventionScope | int, MissionPlan],
    forecast: ForecastT,
    feasibility_checker: Callable[[MissionPlan, ForecastT], bool],
    *,
    affected_tasks: Iterable[str] = (),
) -> ScopeAssessment:
    """Evaluate supplied plans and return the first feasible scope.

    Feasibility is deliberately delegated as ``feasibility_checker(plan,
    forecast)``.  The contract supplies no truth state, alternate forecast, or
    planning method, and it never creates candidates.  All five scope entries
    must be supplied so a reported minimum is auditable.
    """

    if not isinstance(candidates, Mapping):
        raise TypeError("candidates must be a mapping from scope to MissionPlan")
    normalized: dict[InterventionScope, MissionPlan] = {}
    for raw_scope, candidate in candidates.items():
        scope = InterventionScope.coerce(raw_scope)
        if scope in normalized:
            raise ValueError(f"duplicate candidate for scope k={int(scope)}")
        if not isinstance(candidate, MissionPlan):
            raise TypeError(
                f"candidate for scope k={int(scope)} must be a MissionPlan"
            )
        normalized[scope] = candidate

    missing = [scope for scope in InterventionScope if scope not in normalized]
    if missing:
        levels = ", ".join(f"k={int(scope)}" for scope in missing)
        raise ValueError(f"candidates missing required scope levels: {levels}")

    affected = tuple(affected_tasks)
    evaluations: list[ScopeEvaluation] = []
    minimum: Optional[InterventionScope] = None
    for scope in InterventionScope:
        candidate = normalized[scope]
        violations = scope_violations(
            baseline,
            candidate,
            scope,
            affected_tasks=affected,
        )
        if violations:
            evaluations.append(
                ScopeEvaluation(
                    scope=scope,
                    compliant=False,
                    feasible=None,
                    violations=violations,
                )
            )
            continue

        feasible = feasibility_checker(candidate, forecast)
        if not isinstance(feasible, bool):
            raise TypeError("feasibility_checker must return bool")
        evaluations.append(
            ScopeEvaluation(
                scope=scope,
                compliant=True,
                feasible=feasible,
            )
        )
        if feasible and minimum is None:
            minimum = scope

    return ScopeAssessment(minimum_scope=minimum, evaluations=tuple(evaluations))


__all__ = [
    "InterventionScope",
    "MissionPlan",
    "ScopeAssessment",
    "ScopeEvaluation",
    "ScopeViolation",
    "TaskDecision",
    "scope_permissions",
    "scope_violations",
    "smallest_feasible_scope",
    "validate_scope_change",
    "validate_scope_hierarchy",
]
