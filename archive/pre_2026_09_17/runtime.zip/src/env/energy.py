"""
UAV energy model (manuscript sec: uav_fleet).

Implements eq:flight_energy, eq:service_energy, eq:sortie_energy and the
safe-return feasibility constraint C5 (eq:safe_return_constraint).

Directional flight uses a constant-airspeed model: the UAV holds nominal
airspeed ``v_uav`` and crabs to stay on the directed track, so wind changes
the ground speed, the travel time, and therefore the energy (constant power
times time aloft).  A tailwind shortens and cheapens a leg; a headwind or
crosswind lengthens and raises its cost.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, List, Mapping, Optional, Sequence, Tuple

import numpy as np
from shapely.geometry import LineString, Polygon

from .environment import EnvironmentalPacket
from .params import (
    DISTANCE_TOL_KM,
    ENERGY_TOL_WH,
    STATE_TOL,
    TIME_TOL_H,
    PhysicsParams,
)
from .wind import WindForecastPoint, truth_keyframe_times, truth_wind_vector


_EPS = 1e-12


class InfeasibilityReason(str, Enum):
    """Canonical hard physical/operational rejection codes."""

    CROSSWIND_EXCEEDS_AIRSPEED = "CROSSWIND_EXCEEDS_AIRSPEED"
    NONPOSITIVE_GROUND_PROGRESS = "NONPOSITIVE_GROUND_PROGRESS"
    HARD_WEATHER_BLOCK = "HARD_WEATHER_BLOCK"
    AIRSPACE_BLOCK = "AIRSPACE_BLOCK"
    INSUFFICIENT_BATTERY = "INSUFFICIENT_BATTERY"
    SAFE_RETURN_RESERVE_VIOLATION = "SAFE_RETURN_RESERVE_VIOLATION"
    PAYLOAD_CAPACITY_EXCEEDED = "PAYLOAD_CAPACITY_EXCEEDED"
    INSUFFICIENT_DEPOT_INVENTORY = "INSUFFICIENT_DEPOT_INVENTORY"
    INVALID_COMMODITY_LOAD = "INVALID_COMMODITY_LOAD"
    MISSION_HORIZON_EXCEEDED = "MISSION_HORIZON_EXCEEDED"
    INVALID_EDGE = "INVALID_EDGE"
    INVALID_ENVIRONMENTAL_COVERAGE = "INVALID_ENVIRONMENTAL_COVERAGE"


_LEGACY_REASON_ALIASES = {
    InfeasibilityReason.NONPOSITIVE_GROUND_PROGRESS.value: {
        "NONPOSITIVE_GROUND_SPEED",
    },
    InfeasibilityReason.PAYLOAD_CAPACITY_EXCEEDED.value: {
        "PAYLOAD_EXCEEDS_CAPACITY",
    },
    InfeasibilityReason.INVALID_ENVIRONMENTAL_COVERAGE.value: {
        "ENVIRONMENT_COVERAGE_UNKNOWN",
    },
}


class _CompatibleReason(str):
    """Canonical string that still compares equal to old public spellings."""

    def __new__(cls, value: str):
        instance = str.__new__(cls, value)
        instance._aliases = _LEGACY_REASON_ALIASES.get(value, set())
        return instance

    def __eq__(self, other):
        if isinstance(other, InfeasibilityReason):
            other = other.value
        return str.__eq__(self, other) or other in self._aliases

    def __hash__(self):
        return str.__hash__(self)


def _reason_value(reason: str | InfeasibilityReason) -> _CompatibleReason:
    value = reason.value if isinstance(reason, InfeasibilityReason) else str(reason)
    aliases = {
        "NONPOSITIVE_GROUND_SPEED": InfeasibilityReason.NONPOSITIVE_GROUND_PROGRESS.value,
        "PAYLOAD_EXCEEDS_CAPACITY": InfeasibilityReason.PAYLOAD_CAPACITY_EXCEEDED.value,
        "ENVIRONMENT_COVERAGE_UNKNOWN": InfeasibilityReason.INVALID_ENVIRONMENTAL_COVERAGE.value,
    }
    return _CompatibleReason(aliases.get(value, value))


@dataclass(frozen=True)
class LegEvaluation:
    """Authoritative evaluation of one directed network edge.

    The evaluator returns one stable result shape for both feasible and
    infeasible legs.  None travel/energy values mean that the leg could
    not be completed under the supplied packet; reason then contains the
    machine-readable rejection code.
    """

    feasible: bool
    reason: Optional[str]
    travel_time_h: Optional[float]
    ground_speed_kmh: Optional[float]
    energy_wh: Optional[float]
    along_track_wind_kmh: Optional[float]
    cross_track_wind_kmh: Optional[float]
    weather_state: str
    airspace_state: str
    distance_km: float
    departure_time_h: float = 0.0
    arrival_time_h: Optional[float] = None
    airspeed_kmh: Optional[float] = None
    wind_vector_kmh: Optional[Tuple[float, float]] = None
    payload_mass_kg: float = 0.0
    power_w: Optional[float] = None
    packet_id: Optional[str] = None
    diagnostics: dict = field(default_factory=dict)

    @property
    def travel_time(self) -> Optional[float]:
        return self.travel_time_h

    @property
    def ground_speed(self) -> Optional[float]:
        return self.ground_speed_kmh

    @property
    def energy(self) -> Optional[float]:
        return self.energy_wh

    @property
    def along_wind_kmh(self) -> Optional[float]:
        return self.along_track_wind_kmh

    @property
    def cross_wind_kmh(self) -> Optional[float]:
        return self.cross_track_wind_kmh

    @property
    def reason_code(self) -> Optional[InfeasibilityReason]:
        if self.reason is None:
            return None
        try:
            return InfeasibilityReason(str(self.reason))
        except ValueError:
            legacy = {
                "NONPOSITIVE_GROUND_SPEED": InfeasibilityReason.NONPOSITIVE_GROUND_PROGRESS,
                "PAYLOAD_EXCEEDS_CAPACITY": InfeasibilityReason.PAYLOAD_CAPACITY_EXCEEDED,
                "ENVIRONMENT_COVERAGE_UNKNOWN": InfeasibilityReason.INVALID_ENVIRONMENTAL_COVERAGE,
            }
            return legacy.get(str(self.reason))

    def to_dict(self) -> dict:
        return {
            "feasible": self.feasible,
            "reason": self.reason,
            "travel_time_h": self.travel_time_h,
            "ground_speed_kmh": self.ground_speed_kmh,
            "energy_wh": self.energy_wh,
            "along_track_wind_kmh": self.along_track_wind_kmh,
            "cross_track_wind_kmh": self.cross_track_wind_kmh,
            "weather_state": self.weather_state,
            "airspace_state": self.airspace_state,
            "distance_km": self.distance_km,
            "departure_time_h": self.departure_time_h,
            "arrival_time_h": self.arrival_time_h,
            "airspeed_kmh": self.airspeed_kmh,
            "wind_vector_kmh": self.wind_vector_kmh,
            "payload_mass_kg": self.payload_mass_kg,
            "power_w": self.power_w,
            "packet_id": self.packet_id,
            "diagnostics": self.diagnostics,
        }


def seconds_to_wh(power_w: float, duration_s: float) -> float:
    """Convert watts multiplied by seconds to watt-hours explicitly."""
    power = float(power_w)
    duration = float(duration_s)
    if not np.isfinite(power) or not np.isfinite(duration):
        raise ValueError("power_w and duration_s must be finite")
    if power < 0.0 or duration < 0.0:
        raise ValueError("power_w and duration_s must be nonnegative")
    return power * duration / 3600.0


def edge_direction_xy(edge: Any) -> Tuple[float, float]:
    """Return the directed unit vector derived from edge geometry."""
    return tuple(float(value) for value in _edge_geometry(edge)[2])


def perpendicular_direction_xy(edge: Any) -> Tuple[float, float]:
    """Return the counter-clockwise unit normal of a directed edge."""
    direction = edge_direction_xy(edge)
    return -direction[1], direction[0]


def _uav_parameter(uav_parameters: Any, canonical: str, legacy: str) -> float:
    if isinstance(uav_parameters, Mapping):
        value = uav_parameters.get(canonical, uav_parameters.get(legacy))
    else:
        value = getattr(uav_parameters, canonical, getattr(uav_parameters, legacy, None))
    if value is None:
        raise ValueError(f"uav_parameters is missing {canonical}")
    value = float(value)
    if not np.isfinite(value):
        raise ValueError(f"uav_parameters.{canonical} must be finite")
    return value


def _edge_geometry(edge: Any) -> Tuple[np.ndarray, float, np.ndarray]:
    if isinstance(edge, Mapping):
        geometry = edge.get("geometry", edge.get("polyline"))
        declared_length = edge.get("length_km", edge.get("length"))
    else:
        geometry = getattr(edge, "geometry", getattr(edge, "polyline", None))
        declared_length = getattr(edge, "length_km", getattr(edge, "length", None))
    if geometry is None:
        raise ValueError("edge must provide a polyline geometry")
    points = np.asarray(geometry, dtype=float)
    if points.ndim != 2 or points.shape[1:] != (2,) or len(points) < 2:
        raise ValueError("edge geometry must have shape (n, 2)")
    if not np.all(np.isfinite(points)):
        raise ValueError("edge geometry must be finite")
    lengths = np.linalg.norm(np.diff(points, axis=0), axis=1)
    if np.any(lengths <= _EPS):
        raise ValueError("edge geometry cannot contain zero-length segments")
    length = float(np.sum(lengths))
    if declared_length is not None and not np.isclose(float(declared_length), length, atol=1e-9, rtol=1e-9):
        raise ValueError("edge length_km does not match its polyline geometry")
    direction = points[-1] - points[0]
    if float(np.linalg.norm(direction)) <= _EPS:
        direction = points[1] - points[0]
    direction = direction / float(np.linalg.norm(direction))
    return points, length, direction


def _wind_track_components(
    direction: Sequence[float],
    wind_vector_kmh: Sequence[float],
    nominal_airspeed: float,
) -> Tuple[float, float, float]:
    direction_array = np.asarray(direction, dtype=float)
    wind = np.asarray(wind_vector_kmh, dtype=float)
    normal = np.asarray((-direction_array[1], direction_array[0]), dtype=float)
    along = float(np.dot(wind, direction_array))
    cross = float(np.dot(wind, normal))
    if abs(cross) >= nominal_airspeed:
        raise ValueError("crosswind exceeds UAV airspeed: track is infeasible")
    speed = along + float(np.sqrt(nominal_airspeed ** 2 - cross ** 2))
    if speed <= 0.0:
        raise ValueError("headwind stalls ground progress: track is infeasible")
    return along, cross, speed


def _as_environmental_packet(packet: Any) -> EnvironmentalPacket:
    if isinstance(packet, EnvironmentalPacket):
        return packet
    if isinstance(packet, Mapping):
        payload = dict(packet)
        if "valid_until_h" not in payload and "horizon_h" in payload:
            payload["valid_until_h"] = float(payload["issued_at_h"]) + float(payload["horizon_h"])
        return EnvironmentalPacket.from_dict(payload)
    if hasattr(packet, "points") and hasattr(packet, "issued_at_h"):
        issued_at = float(packet.issued_at_h)
        points = tuple(packet.points)
        return EnvironmentalPacket(
            packet_id=f"legacy-packet-{issued_at:g}",
            issued_at_h=issued_at,
            valid_from_h=float(points[0].valid_time_h),
            valid_until_h=float(points[-1].valid_time_h),
            wind=points,
        )
    raise TypeError("environmental_packet must be an EnvironmentalPacket or mapping")


def _region_active_in_interval(region: Any, start_h: float, end_h: float) -> bool:
    region_start = float(region.valid_from_h)
    region_end = region.valid_until_h
    if end_h < region_start - _EPS:
        return False
    if region_end is not None and start_h > float(region_end) + _EPS:
        return False
    return True


def _intersects_region(line: LineString, region: Any) -> bool:
    geometry = Polygon(region.geometry)
    buffer_km = float(getattr(region, "safety_buffer_m", 0.0)) / 1000.0
    if buffer_km > 0.0:
        geometry = geometry.buffer(buffer_km)
    return bool(line.intersects(geometry))


def _leg_failure(
    reason: str | InfeasibilityReason,
    distance_km: float,
    *,
    weather_state: str = "CLEAR",
    airspace_state: str = "CLEAR",
    departure_time_h: float = 0.0,
    airspeed_kmh: Optional[float] = None,
    payload_mass_kg: float = 0.0,
    packet_id: Optional[str] = None,
    wind_vector_kmh: Optional[Tuple[float, float]] = None,
    diagnostics: Optional[dict] = None,
) -> LegEvaluation:
    diagnostic_values = dict(diagnostics or {})
    if packet_id is not None:
        diagnostic_values.setdefault("packet_id", packet_id)
    return LegEvaluation(
        feasible=False,
        reason=_reason_value(reason),
        travel_time_h=None,
        ground_speed_kmh=None,
        energy_wh=None,
        along_track_wind_kmh=None,
        cross_track_wind_kmh=None,
        weather_state=weather_state,
        airspace_state=airspace_state,
        distance_km=float(distance_km),
        departure_time_h=float(departure_time_h),
        arrival_time_h=None,
        airspeed_kmh=airspeed_kmh,
        wind_vector_kmh=wind_vector_kmh,
        payload_mass_kg=float(payload_mass_kg),
        power_w=None,
        packet_id=packet_id,
        diagnostics=diagnostic_values,
    )


@dataclass
class _IntegrationResult:
    feasible: bool
    reason: Optional[InfeasibilityReason]
    completed: bool
    time_h: float
    distance_km: float
    energy_wh: float
    along_track_wind_kmh: float
    cross_track_wind_kmh: float
    wind_vector_kmh: np.ndarray
    weather_state: str
    airspace_state: str
    segments: list[dict]


def _integration_failure(
    reason: InfeasibilityReason,
    *,
    time_h: float,
    distance_km: float,
    energy_wh: float,
    along_track_wind_kmh: float,
    cross_track_wind_kmh: float,
    wind_vector_kmh: np.ndarray,
    weather_state: str,
    airspace_state: str,
    segments: list[dict],
) -> _IntegrationResult:
    return _IntegrationResult(
        feasible=False,
        reason=reason,
        completed=False,
        time_h=float(time_h),
        distance_km=float(distance_km),
        energy_wh=float(energy_wh),
        along_track_wind_kmh=float(along_track_wind_kmh),
        cross_track_wind_kmh=float(cross_track_wind_kmh),
        wind_vector_kmh=np.asarray(wind_vector_kmh, dtype=float),
        weather_state=weather_state,
        airspace_state=airspace_state,
        segments=list(segments),
    )


def _integrate_edge(
    points: np.ndarray,
    distance_km: float,
    direction: np.ndarray,
    departure_time_h: float,
    payload_mass_kg: float,
    nominal_airspeed: float,
    power_w: float,
    packet: EnvironmentalPacket,
    *,
    stop_time_h: Optional[float] = None,
) -> _IntegrationResult:
    """Integrate one edge over packet-defined temporal cells.

    ``stop_time_h`` is used only to recover a physically accurate partial
    state at an event boundary.  A full evaluation still requires the packet
    to cover the complete edge traversal.
    """
    if stop_time_h is not None:
        stop_time_h = float(stop_time_h)
        if not np.isfinite(stop_time_h) or stop_time_h < departure_time_h - TIME_TOL_H:
            raise ValueError("stop_time_h must be finite and after departure")

    normal = np.asarray((-direction[1], direction[0]), dtype=float)
    boundaries = {float(packet.valid_from_h), float(packet.valid_until_h)}
    boundaries.update(float(point.valid_time_h) for point in packet.wind)
    for region in (*packet.weather, *packet.airspace):
        if packet.valid_from_h - TIME_TOL_H <= float(region.valid_from_h) <= packet.valid_until_h + TIME_TOL_H:
            boundaries.add(float(region.valid_from_h))
        if region.valid_until_h is not None and packet.valid_from_h - TIME_TOL_H <= float(region.valid_until_h) <= packet.valid_until_h + TIME_TOL_H:
            boundaries.add(float(region.valid_until_h))
    ordered_boundaries = sorted(boundaries)

    remaining_distance = float(distance_km)
    time_h = float(departure_time_h)
    total_energy = 0.0
    travelled_distance = 0.0
    weighted_along = 0.0
    weighted_cross = 0.0
    weighted_wind = np.zeros(2, dtype=float)
    weather_state = "CLEAR"
    airspace_state = "CLEAR"
    segments: list[dict] = []
    line = LineString(points)

    while remaining_distance > DISTANCE_TOL_KM:
        if stop_time_h is not None and time_h >= stop_time_h - TIME_TOL_H:
            break
        next_boundary = next(
            (value for value in ordered_boundaries if value > time_h + TIME_TOL_H),
            None,
        )
        if next_boundary is None:
            return _integration_failure(
                InfeasibilityReason.INVALID_ENVIRONMENTAL_COVERAGE,
                time_h=time_h,
                distance_km=travelled_distance,
                energy_wh=total_energy,
                along_track_wind_kmh=weighted_along,
                cross_track_wind_kmh=weighted_cross,
                wind_vector_kmh=weighted_wind,
                weather_state=weather_state,
                airspace_state=airspace_state,
                segments=segments,
            )
        segment_end = min(float(next_boundary), float(packet.valid_until_h))
        if stop_time_h is not None:
            segment_end = min(segment_end, stop_time_h)
        if segment_end <= time_h + TIME_TOL_H:
            time_h = segment_end
            continue
        midpoint = 0.5 * (time_h + segment_end)
        wind = packet.wind_at(midpoint)
        if wind is None:
            return _integration_failure(
                InfeasibilityReason.INVALID_ENVIRONMENTAL_COVERAGE,
                time_h=time_h,
                distance_km=travelled_distance,
                energy_wh=total_energy,
                along_track_wind_kmh=weighted_along,
                cross_track_wind_kmh=weighted_cross,
                wind_vector_kmh=weighted_wind,
                weather_state=weather_state,
                airspace_state=airspace_state,
                segments=segments,
            )
        wind_array = np.asarray(wind, dtype=float)
        along = float(np.dot(wind_array, direction))
        cross = float(np.dot(wind_array, normal))
        try:
            _, _, ground_speed = _wind_track_components(
                direction, wind_array, nominal_airspeed
            )
        except ValueError:
            reason = (
                InfeasibilityReason.CROSSWIND_EXCEEDS_AIRSPEED
                if abs(cross) >= nominal_airspeed
                else InfeasibilityReason.NONPOSITIVE_GROUND_PROGRESS
            )
            return _integration_failure(
                reason,
                time_h=time_h,
                distance_km=travelled_distance,
                energy_wh=total_energy,
                along_track_wind_kmh=along,
                cross_track_wind_kmh=cross,
                wind_vector_kmh=wind_array,
                weather_state=weather_state,
                airspace_state=airspace_state,
                segments=segments,
            )

        candidate_duration = remaining_distance / ground_speed
        duration = min(candidate_duration, segment_end - time_h)
        actual_end = time_h + duration
        active_weather = [
            region for region in packet.weather
            if _region_active_in_interval(region, time_h, actual_end)
            and _intersects_region(line, region)
        ]
        if any(region.is_hard for region in active_weather):
            return _integration_failure(
                InfeasibilityReason.HARD_WEATHER_BLOCK,
                time_h=time_h,
                distance_km=travelled_distance,
                energy_wh=total_energy,
                along_track_wind_kmh=along,
                cross_track_wind_kmh=cross,
                wind_vector_kmh=wind_array,
                weather_state="BLOCKED",
                airspace_state=airspace_state,
                segments=segments,
            )
        if active_weather:
            weather_state = "SOFT"
        active_airspace = [
            region for region in packet.airspace
            if _region_active_in_interval(region, time_h, actual_end)
            and _intersects_region(line, region)
        ]
        if active_airspace:
            return _integration_failure(
                InfeasibilityReason.AIRSPACE_BLOCK,
                time_h=time_h,
                distance_km=travelled_distance,
                energy_wh=total_energy,
                along_track_wind_kmh=along,
                cross_track_wind_kmh=cross,
                wind_vector_kmh=wind_array,
                weather_state=weather_state,
                airspace_state="BLOCKED",
                segments=segments,
            )

        travelled = min(remaining_distance, ground_speed * duration)
        start_distance = travelled_distance
        travelled_distance += travelled
        remaining_distance -= travelled
        total_energy += seconds_to_wh(power_w, duration * 3600.0)
        weighted_along += along * duration
        weighted_cross += cross * duration
        weighted_wind += wind_array * duration
        segments.append({
            "start_time_h": float(time_h),
            "end_time_h": float(actual_end),
            "start_distance_km": float(start_distance),
            "distance_km": float(travelled),
            "duration_h": float(duration),
            "wind_vector_kmh": tuple(float(value) for value in wind_array),
            "along_track_wind_kmh": float(along),
            "cross_track_wind_kmh": float(cross),
            "ground_speed_kmh": float(ground_speed),
            "power_w": float(power_w),
        })
        time_h = actual_end
        if candidate_duration <= segment_end - (time_h - duration) + TIME_TOL_H:
            break

    completed = remaining_distance <= DISTANCE_TOL_KM
    if not completed and stop_time_h is None:
        return _integration_failure(
            InfeasibilityReason.INVALID_ENVIRONMENTAL_COVERAGE,
            time_h=time_h,
            distance_km=travelled_distance,
            energy_wh=total_energy,
            along_track_wind_kmh=weighted_along,
            cross_track_wind_kmh=weighted_cross,
            wind_vector_kmh=weighted_wind,
            weather_state=weather_state,
            airspace_state=airspace_state,
            segments=segments,
        )
    duration = time_h - departure_time_h
    return _IntegrationResult(
        feasible=True,
        reason=None,
        completed=completed,
        time_h=float(time_h),
        distance_km=float(travelled_distance),
        energy_wh=float(total_energy),
        along_track_wind_kmh=(
            float(weighted_along / duration) if duration > TIME_TOL_H else 0.0
        ),
        cross_track_wind_kmh=(
            float(weighted_cross / duration) if duration > TIME_TOL_H else 0.0
        ),
        wind_vector_kmh=(
            weighted_wind / duration if duration > TIME_TOL_H else np.zeros(2)
        ),
        weather_state=weather_state,
        airspace_state=airspace_state,
        segments=segments,
    )


def evaluate_leg(
    edge: Any,
    departure_time_h: float,
    payload_mass_kg: float,
    uav_parameters: Any,
    environmental_packet: Any,
) -> LegEvaluation:
    """Evaluate one directed edge against one authoritative environment packet.

    Wind is a global, time-varying vector.  The edge is integrated over every
    packet/environment boundary crossed during the traversal, so a leg never
    silently reuses only its departure-time conditions.
    """
    try:
        points, distance_km, direction = _edge_geometry(edge)
    except (TypeError, ValueError) as error:
        try:
            departure_for_error = float(departure_time_h)
        except (TypeError, ValueError):
            departure_for_error = 0.0
        try:
            payload_for_error = float(payload_mass_kg)
        except (TypeError, ValueError):
            payload_for_error = 0.0
        return _leg_failure(
            InfeasibilityReason.INVALID_EDGE,
            0.0,
            departure_time_h=departure_for_error,
            payload_mass_kg=payload_for_error,
            diagnostics={"error": str(error)},
        )
    departure = float(departure_time_h)
    payload = float(payload_mass_kg)
    if not np.isfinite(departure) or departure < 0.0:
        raise ValueError("departure_time_h must be finite and nonnegative")
    if not np.isfinite(payload) or payload < 0.0:
        raise ValueError("payload_mass_kg must be finite and nonnegative")
    nominal_airspeed = _uav_parameter(uav_parameters, "nominal_airspeed_kmh", "v_uav")
    empty_mass = _uav_parameter(uav_parameters, "empty_mass_kg", "m0")
    max_payload = _uav_parameter(uav_parameters, "max_payload_kg", "W_max")
    energy_coefficient = _uav_parameter(
        uav_parameters,
        "energy_coefficient_wh_per_km_kg",
        "e_c",
    )
    if nominal_airspeed <= 0.0 or empty_mass <= 0.0 or max_payload <= 0.0 or energy_coefficient <= 0.0:
        raise ValueError("UAV physical parameters must be positive")
    if payload > max_payload + _EPS:
        return _leg_failure(
            InfeasibilityReason.PAYLOAD_CAPACITY_EXCEEDED,
            distance_km,
            departure_time_h=departure,
            airspeed_kmh=nominal_airspeed,
            payload_mass_kg=payload,
        )

    packet = _as_environmental_packet(environmental_packet)
    if departure < packet.valid_from_h - _EPS or departure >= packet.valid_until_h - _EPS:
        return _leg_failure(
            InfeasibilityReason.INVALID_ENVIRONMENTAL_COVERAGE,
            distance_km,
            departure_time_h=departure,
            airspeed_kmh=nominal_airspeed,
            payload_mass_kg=payload,
            packet_id=packet.packet_id,
            diagnostics={"direction_xy": tuple(float(value) for value in direction)},
        )

    power = nominal_power(payload, uav_parameters)
    integrated = _integrate_edge(
        points,
        distance_km,
        direction,
        departure,
        payload,
        nominal_airspeed,
        power,
        packet,
    )
    diagnostics = {
        "packet_id": packet.packet_id,
        "direction_xy": tuple(float(value) for value in direction),
        "perpendicular_direction_xy": tuple(
            float(value) for value in (-direction[1], direction[0])
        ),
        "segments": integrated.segments,
    }
    if not integrated.feasible:
        return _leg_failure(
            integrated.reason or InfeasibilityReason.INVALID_ENVIRONMENTAL_COVERAGE,
            distance_km,
            weather_state=integrated.weather_state,
            airspace_state=integrated.airspace_state,
            departure_time_h=departure,
            airspeed_kmh=nominal_airspeed,
            payload_mass_kg=payload,
            packet_id=packet.packet_id,
            diagnostics=diagnostics,
        )
    total_duration = integrated.time_h - departure
    return LegEvaluation(
        feasible=True,
        reason=None,
        travel_time_h=float(total_duration),
        ground_speed_kmh=float(distance_km / total_duration),
        energy_wh=float(integrated.energy_wh),
        along_track_wind_kmh=float(integrated.along_track_wind_kmh),
        cross_track_wind_kmh=float(integrated.cross_track_wind_kmh),
        weather_state=integrated.weather_state,
        airspace_state=integrated.airspace_state,
        distance_km=float(distance_km),
        departure_time_h=float(departure),
        arrival_time_h=float(integrated.time_h),
        airspeed_kmh=float(nominal_airspeed),
        wind_vector_kmh=tuple(
            float(value) for value in integrated.wind_vector_kmh
        ),
        payload_mass_kg=float(payload),
        power_w=float(power),
        packet_id=packet.packet_id,
        diagnostics=diagnostics,
    )


@dataclass(frozen=True)
class SafeReturnEvaluation:
    """Hard reserve check for a return from the current mission endpoint."""

    feasible: bool
    reason: Optional[str]
    predicted_return_energy_wh: Optional[float]
    reserve_margin_wh: Optional[float]
    leg_evaluation: LegEvaluation
    service_energy_wh: float = 0.0

    @property
    def reason_code(self) -> Optional[InfeasibilityReason]:
        if self.reason is None:
            return None
        try:
            return InfeasibilityReason(str(self.reason))
        except ValueError:
            return None

    def to_dict(self) -> dict:
        return {
            "feasible": self.feasible,
            "reason": self.reason,
            "predicted_return_energy_wh": self.predicted_return_energy_wh,
            "reserve_margin_wh": self.reserve_margin_wh,
            "service_energy_wh": self.service_energy_wh,
            "leg": self.leg_evaluation.to_dict(),
        }


def safe_return_margin_wh(
    remaining_battery_wh: float,
    predicted_return_energy_wh: float,
    reserve_requirement_wh: float,
) -> float:
    """Return remaining battery after return energy and fixed-Wh reserve."""
    remaining = float(remaining_battery_wh)
    predicted = float(predicted_return_energy_wh)
    reserve = float(reserve_requirement_wh)
    if not all(np.isfinite(value) for value in (remaining, predicted, reserve)):
        raise ValueError("battery, predicted return energy, and reserve must be finite")
    if remaining < 0.0:
        raise ValueError("remaining battery must be nonnegative")
    if predicted < 0.0 or reserve < 0.0:
        raise ValueError("predicted return energy and reserve must be nonnegative")
    return remaining - predicted - reserve


def evaluate_safe_return(
    current_xy: Sequence[float],
    safe_endpoint_xy: Sequence[float],
    departure_time_h: float,
    payload_mass_kg: float,
    remaining_battery_wh: float,
    uav_parameters: Any,
    environmental_packet: Any,
    *,
    service_energy_wh: float = 0.0,
) -> SafeReturnEvaluation:
    """Evaluate a return leg and its fixed-Wh reserve margin."""
    service = float(service_energy_wh)
    if not np.isfinite(service) or service < 0.0:
        raise ValueError("service_energy_wh must be finite and nonnegative")
    remaining = float(remaining_battery_wh)
    if not np.isfinite(remaining) or remaining < 0.0:
        raise ValueError("remaining_battery_wh must be finite and nonnegative")
    leg = evaluate_leg(
        {"geometry": (tuple(current_xy), tuple(safe_endpoint_xy))},
        departure_time_h,
        payload_mass_kg,
        uav_parameters,
        environmental_packet,
    )
    if not leg.feasible:
        return SafeReturnEvaluation(
            feasible=False,
            reason=leg.reason,
            predicted_return_energy_wh=None,
            reserve_margin_wh=None,
            leg_evaluation=leg,
            service_energy_wh=service,
        )
    assert leg.energy_wh is not None
    reserve = _uav_parameter(
        uav_parameters, "reserve_requirement_wh", "beta_safe"
    )
    predicted = float(leg.energy_wh + service)
    margin = safe_return_margin_wh(remaining, predicted, reserve)
    if margin < -ENERGY_TOL_WH:
        return SafeReturnEvaluation(
            feasible=False,
            reason=_reason_value(InfeasibilityReason.SAFE_RETURN_RESERVE_VIOLATION),
            predicted_return_energy_wh=predicted,
            reserve_margin_wh=margin,
            leg_evaluation=leg,
            service_energy_wh=service,
        )
    return SafeReturnEvaluation(
        feasible=True,
        reason=None,
        predicted_return_energy_wh=predicted,
        reserve_margin_wh=margin,
        leg_evaluation=leg,
        service_energy_wh=service,
    )


def route_state_at(
    points_xy: Sequence[Sequence[float]],
    departure_time_h: float,
    at_time_h: float,
    payload_mass_kg: float,
    uav_parameters: Any,
    environmental_packet: Any,
) -> Tuple[np.ndarray, float, float, float]:
    """Return the physically integrated state at ``at_time_h``.

    The requested time may fall inside a temporal wind cell.  In that case
    the same integrator used by :func:`evaluate_leg` advances only to the
    requested boundary, rather than interpolating a completed-leg result.
    """
    points = np.asarray(points_xy, dtype=float)
    if points.ndim != 2 or points.shape[1:] != (2,) or len(points) < 2:
        raise ValueError("route points must have shape (n, 2) with at least two points")
    departure = float(departure_time_h)
    at_time = float(at_time_h)
    if not np.isfinite(departure) or not np.isfinite(at_time) or at_time < departure - _EPS:
        raise ValueError("route times must be finite and ordered")
    packet = _as_environmental_packet(environmental_packet)
    position = points[0].copy()
    distance_total = 0.0
    energy_total = 0.0
    current_time = departure
    for origin, destination in zip(points[:-1], points[1:]):
        leg_points, leg_distance, leg_direction = _edge_geometry(
            {"geometry": (tuple(origin), tuple(destination))}
        )
        nominal_airspeed = _uav_parameter(
            uav_parameters, "nominal_airspeed_kmh", "v_uav"
        )
        power = nominal_power(payload_mass_kg, uav_parameters)
        integrated = _integrate_edge(
            leg_points,
            leg_distance,
            leg_direction,
            current_time,
            float(payload_mass_kg),
            nominal_airspeed,
            power,
            packet,
            stop_time_h=at_time,
        )
        if not integrated.feasible:
            raise ValueError(integrated.reason or "route leg is infeasible")
        if integrated.completed:
            position = destination.copy()
            distance_total += leg_distance
            energy_total += integrated.energy_wh
            current_time = integrated.time_h
            continue
        position = origin + leg_direction * integrated.distance_km
        distance_total += integrated.distance_km
        energy_total += integrated.energy_wh
        current_time = integrated.time_h
        return position, distance_total, energy_total, current_time
    return position, distance_total, energy_total, current_time


def flight_energy(L: float, payload_mass: float, p: Any) -> float:
    """E^fly_{ij,u} = L_ij * e_c * (m0 + w_pay)   (eq:flight_energy)."""
    return float(L) * nominal_power(payload_mass, p) / _uav_parameter(
        p, "nominal_airspeed_kmh", "v_uav"
    )


def nominal_power(payload_mass: float, p: Any) -> float:
    """P_nominal = e_c * (m_u + m_payload) * v_uav.

    Constant-airspeed cruise power at nominal airspeed ``v_uav``.  The
    payload enters through the total carried mass ``m0 + m_payload`` and is
    never cancelled out of the energy accounting: every directional and
    realized energy value is ``P_nominal`` times the time aloft (``L / s``),
    so heavier loads strictly cost more energy and energy is strictly
    increasing in payload mass.
    """
    return (
        _uav_parameter(p, "energy_coefficient_wh_per_km_kg", "e_c")
        * (
            _uav_parameter(p, "empty_mass_kg", "m0")
            + float(payload_mass)
        )
        * _uav_parameter(p, "nominal_airspeed_kmh", "v_uav")
    )


def _constant_wind_packet(wind_vector_kmh: Sequence[float]) -> EnvironmentalPacket:
    wind = np.asarray(wind_vector_kmh, dtype=float)
    if wind.shape != (2,) or not np.all(np.isfinite(wind)):
        raise ValueError("wind_vector_kmh must contain two finite values")
    return EnvironmentalPacket(
        packet_id="constant-wind-adapter",
        issued_at_h=0.0,
        valid_from_h=0.0,
        valid_until_h=1_000_000.0,
        wind=(
            WindForecastPoint(0.0, float(wind[0]), float(wind[1])),
            WindForecastPoint(1_000_000.0, float(wind[0]), float(wind[1])),
        ),
    )


def _directional_evaluation(
    start_xy: Sequence[float],
    end_xy: Sequence[float],
    payload_mass: float,
    wind_vector_kmh: Sequence[float],
    p: Any,
) -> LegEvaluation:
    evaluation = evaluate_leg(
        {"geometry": (tuple(start_xy), tuple(end_xy))},
        0.0,
        payload_mass,
        p,
        _constant_wind_packet(wind_vector_kmh),
    )
    if not evaluation.feasible:
        if evaluation.reason == "CROSSWIND_EXCEEDS_AIRSPEED":
            raise ValueError("crosswind exceeds UAV airspeed: track is infeasible")
        if evaluation.reason == "NONPOSITIVE_GROUND_SPEED":
            raise ValueError("headwind stalls ground progress: track is infeasible")
        raise ValueError(evaluation.reason or "directed leg is infeasible")
    return evaluation


def _validated_segment(
    start_xy: Sequence[float],
    end_xy: Sequence[float],
    wind_vector_kmh: Sequence[float],
) -> Tuple[np.ndarray, float]:
    start = np.asarray(start_xy, dtype=float)
    end = np.asarray(end_xy, dtype=float)
    wind = np.asarray(wind_vector_kmh, dtype=float)
    if start.shape != (2,) or end.shape != (2,) or wind.shape != (2,):
        raise ValueError("positions and wind_vector_kmh must be two-dimensional")
    if not np.all(np.isfinite(start)) or not np.all(np.isfinite(end)) \
            or not np.all(np.isfinite(wind)):
        raise ValueError("positions and wind_vector_kmh must be finite")
    displacement = end - start
    length = float(np.linalg.norm(displacement))
    if length <= _EPS:
        return np.array([1.0, 0.0]), 0.0
    return displacement / length, length


def ground_speed_along_track(
    start_xy: Sequence[float],
    end_xy: Sequence[float],
    wind_vector_kmh: Sequence[float],
    p: PhysicsParams,
) -> float:
    """Ground speed holding the directed track at constant airspeed ``v_uav``.

    With wind vector ``w`` decomposed into along-track and cross-track parts,

        s = w_along + sqrt(v_uav^2 - w_perp^2).

    The track is infeasible when the crosswind alone saturates the airspeed
    or when the resulting ground speed stalls; both raise ``ValueError``.
    Wind is an east/north vector in km/h pointing with the air movement.
    """
    unit, length = _validated_segment(start_xy, end_xy, wind_vector_kmh)
    if length <= _EPS:
        return float(p.v_uav)
    _, _, speed = _wind_track_components(
        unit,
        wind_vector_kmh,
        _uav_parameter(p, "nominal_airspeed_kmh", "v_uav"),
    )
    return speed


def directional_flight_energy(
    start_xy: Sequence[float],
    end_xy: Sequence[float],
    payload_mass: float,
    wind_vector_kmh: Sequence[float],
    p: PhysicsParams,
) -> float:
    """Flight energy under a global 2D wind at constant airspeed.

    E = P_nominal * (L / s), with P_nominal = e_c * (m0 + w_pay) * v_uav.
    Reduces to eq:flight_energy at calm wind (s = v_uav).
    """
    evaluation = _directional_evaluation(
        start_xy, end_xy, payload_mass, wind_vector_kmh, p
    )
    assert evaluation.energy_wh is not None
    return evaluation.energy_wh


def directional_segment_duration(
    start_xy: Sequence[float],
    end_xy: Sequence[float],
    wind_vector_kmh: Sequence[float],
    p: PhysicsParams,
) -> float:
    """Travel time L / s under the constant-airspeed wind model."""
    evaluation = _directional_evaluation(
        start_xy, end_xy, 0.0, wind_vector_kmh, p
    )
    assert evaluation.travel_time_h is not None
    return evaluation.travel_time_h


def service_energy(p: Any) -> float:
    """E^serv = e_v   (eq:service_energy)."""
    return _uav_parameter(p, "service_energy_wh", "e_v")


def sortie_energy(leg_lengths: Sequence[float],
                  leg_payload_masses: Sequence[float],
                  p: PhysicsParams) -> float:
    """
    Total sortie energy (eq:sortie_energy).

    ``leg_lengths`` are the lengths of all flight legs including the final
    return leg to the depot; ``leg_payload_masses[i]`` is the onboard payload
    mass *before* flying leg i (payload-dependent energy evaluated with the
    load carried on that leg). A service maneuver (E^serv) is charged after
    every leg except the final return leg.
    """
    if len(leg_lengths) != len(leg_payload_masses):
        raise ValueError("leg_lengths and leg_payload_masses must have equal length")
    e = 0.0
    n = len(leg_lengths)
    for i, (L, w) in enumerate(zip(leg_lengths, leg_payload_masses)):
        e += flight_energy(L, w, p)
        if i < n - 1:                       # service at every intermediate stop
            e += service_energy(p)
    return e


def safe_return_energy(L_to_i: float, L_i_to_depot: float,
                       payload_mass: float, payload_mass_after: float,
                       p: PhysicsParams) -> float:
    """
    Energy required by C5's right-hand side, excluding beta_safe:
    E^fly(q_u -> i, current payload) + E^serv + E^fly(i -> v0, post-delivery payload).
    The return leg is evaluated at t_i^+ i.e. with the payload remaining after
    the delivery at i (eq:safe_return_constraint).
    """
    return (flight_energy(L_to_i, payload_mass, p)
            + service_energy(p)
            + flight_energy(L_i_to_depot, payload_mass_after, p))


def directional_safe_return_energy(
    current_xy: Sequence[float],
    node_xy: Sequence[float],
    depot_xy: Sequence[float],
    payload_mass: float,
    payload_mass_after: float,
    outbound_wind_kmh: Sequence[float],
    return_wind_kmh: Sequence[float],
    p: PhysicsParams,
) -> float:
    """Directional counterpart of ``safe_return_energy``, excluding reserve."""
    return (
        directional_flight_energy(
            current_xy, node_xy, payload_mass, outbound_wind_kmh, p
        )
        + service_energy(p)
        + directional_flight_energy(
            node_xy, depot_xy, payload_mass_after, return_wind_kmh, p
        )
    )


def forecast_route_kinematics(
    points_xy: Sequence[Sequence[float]],
    departure_time_h: float,
    payload_masses: Sequence[float],
    forecast,
    p: PhysicsParams,
) -> Optional[Tuple[float, float]]:
    """Forecast ``(energy_wh, duration_h)`` for a route, or ``None``.

    Segments are chained: each segment's start time follows the previous
    segment's wind-dependent duration.  The forecast wind is sampled at the
    nominal-time segment midpoint (calm-speed ETA); a headwind segment may
    then finish later than its nominal ETA, so coverage is re-checked against
    the actual window.  ``None`` is returned when any segment lacks forecast
    coverage or is infeasible under the forecast wind.
    """
    if forecast is None or forecast.latest_packet is None:
        return None
    points = [np.asarray(point, dtype=float) for point in points_xy]
    segment_count = max(len(points) - 1, 0)
    if segment_count != len(payload_masses):
        raise ValueError("payload masses must match route segments")
    time_h = float(departure_time_h)
    if not np.isfinite(time_h) or time_h < 0.0:
        raise ValueError("departure_time_h must be finite and nonnegative")
    latest = forecast.latest_packet
    packet = EnvironmentalPacket(
        packet_id=f"forecast-adapter-{latest.issued_at_h:g}",
        issued_at_h=latest.issued_at_h,
        valid_from_h=latest.valid_from_h,
        valid_until_h=latest.valid_until_h,
        wind=tuple(latest.points),
    )
    energy = 0.0
    start_time = time_h
    for start, end, payload in zip(points[:-1], points[1:], payload_masses):
        evaluation = evaluate_leg(
            {"geometry": (tuple(start), tuple(end))},
            time_h,
            payload,
            p,
            packet,
        )
        if not evaluation.feasible:
            return None
        assert evaluation.travel_time_h is not None and evaluation.energy_wh is not None
        time_h += evaluation.travel_time_h
        energy += evaluation.energy_wh
    return energy, time_h - start_time


def _walk_route(
    points: List[np.ndarray],
    departure_time_h: float,
    time_limit_h: Optional[float],
    payload_mass: float,
    wind_spec,
    p: PhysicsParams,
) -> Tuple[np.ndarray, float, float, float]:
    """Integrate the realized motion along a route under the truth wind.

    Returns ``(position, distance_km, energy_wh, end_time_h)``.  Truth wind is
    sampled per cell (route leg x truth-keyframe interval) at the cell's
    nominal-time midpoint, matching the oracle midpoint convention.  The walk
    stops at ``time_limit_h`` when given, otherwise at the route end.
    """
    power = nominal_power(payload_mass, p)
    boundaries = [
        value for value in truth_keyframe_times(wind_spec)
        if value > departure_time_h + _EPS
    ]
    position = points[0].astype(float).copy()
    distance_total = 0.0
    energy = 0.0
    time_h = float(departure_time_h)
    for leg_start, leg_end in zip(points[:-1], points[1:]):
        leg = np.asarray(leg_end, dtype=float) - np.asarray(leg_start, dtype=float)
        remaining = float(np.linalg.norm(leg))
        if remaining <= _EPS:
            continue
        unit = leg / remaining
        while remaining > _EPS:
            if time_limit_h is not None and time_h >= time_limit_h - _EPS:
                return position, distance_total, energy, time_h
            next_boundary = next(
                (value for value in boundaries if value > time_h + _EPS),
                None,
            )
            time_to_boundary = (
                math.inf if next_boundary is None else next_boundary - time_h
            )
            sample_h = 0.5 * min(remaining / float(p.v_uav), time_to_boundary)
            wind = truth_wind_vector(wind_spec, time_h + sample_h)
            speed = ground_speed_along_track(
                position, position + unit, wind, p
            )
            step_h = min(remaining / speed, time_to_boundary)
            if time_limit_h is not None:
                step_h = min(step_h, max(time_limit_h - time_h, 0.0))
            step_km = min(speed * step_h, remaining)
            position = position + unit * step_km
            remaining -= step_km
            distance_total += step_km
            energy += power * step_h
            time_h += step_h
            if step_h <= _EPS:
                break
    return position, distance_total, energy, time_h


def realized_route_arrival(
    points_xy: Sequence[Sequence[float]],
    departure_time_h: float,
    payload_mass: float,
    wind_spec,
    p: PhysicsParams,
) -> Tuple[float, float]:
    """Realized ``(arrival_time_h, energy_wh)`` under the truth wind."""
    points = [np.asarray(point, dtype=float) for point in points_xy]
    _, _, energy, arrival_h = _walk_route(
        points, departure_time_h, None, payload_mass, wind_spec, p
    )
    return arrival_h, energy


def realized_route_state(
    points_xy: Sequence[Sequence[float]],
    departure_time_h: float,
    at_time_h: float,
    payload_mass: float,
    wind_spec,
    p: PhysicsParams,
) -> Tuple[np.ndarray, float, float]:
    """Realized ``(position, distance_km, energy_wh)`` at ``at_time_h``."""
    points = [np.asarray(point, dtype=float) for point in points_xy]
    position, distance_km, energy, _ = _walk_route(
        points, departure_time_h, at_time_h, payload_mass, wind_spec, p
    )
    return position, distance_km, energy


def is_safe_return_feasible(b: float, L_to_i: float, L_i_to_depot: float,
                            payload_mass: float, payload_mass_after: float,
                            p: PhysicsParams) -> bool:
    """C5: b_u >= E^fly(q,i) + E^serv + E^fly(i,0) + beta_safe   (eq:safe_return_constraint)."""
    return b >= safe_return_energy(L_to_i, L_i_to_depot,
                                   payload_mass, payload_mass_after, p) + p.beta_safe


def max_service_radius(p: PhysicsParams, conservative: bool = True) -> float:
    """
    Maximum depot-to-node distance r such that a fully loaded single-stop
    out-and-back sortie satisfies C5 at full charge:

        B_max - beta_safe >= r*e_c*(m0+W_max) + e_v + r*e_c*(m0 + w_ret)

    conservative=True assumes the worst-case return still fully loaded
    (w_ret = W_max, e.g. demand vanished before arrival); otherwise an
    empty return (w_ret = 0). The scenario generator places all nodes
    within feasible_frac * (conservative radius), guaranteeing every node
    is C5-serviceable at full payload.
    """
    budget = p.B_max - p.beta_safe - p.e_v
    w_ret = p.W_max if conservative else 0.0
    denom = p.e_c * (2.0 * p.m0 + p.W_max + w_ret)
    return budget / denom
