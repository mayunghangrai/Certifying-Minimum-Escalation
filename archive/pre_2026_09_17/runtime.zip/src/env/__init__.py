"""Known-task routing scenarios with online environmental information.

The package generates replayable weather, airspace, and wind updates; evaluates
caller-supplied polylines; and executes explicit fleet commands.  It contains
no allocation, sequencing, routing, replanning, or learning algorithm.
"""

from .objective import ObjectiveParams, evaluate_episode
from .params import EnvParams
from .energy import (
    InfeasibilityReason,
    LegEvaluation,
    SafeReturnEvaluation,
    evaluate_leg,
    evaluate_safe_return,
    safe_return_margin_wh,
    seconds_to_wh,
)
from .environment import (
    AirspaceRestriction,
    EnvironmentalPacket,
    EnvironmentalTransition,
    WeatherRegion,
    compare_environmental_packets,
)
from .network import Network, NetworkEdge, NetworkNode
from .route_evaluator import RouteEvaluation, evaluate_route
from .scenario import Scenario, ScenarioNode
from .simulator import EnvironmentSnapshot, RoutingSimulator
from .fixed_plan import FixedPlanResult, execute_fixed_plan
from .diagnostics import (
    DependencyEdge,
    DependencyVertex,
    DisturbanceDependencyGraph,
    DisturbanceImpactClosure,
    LegImpact,
    LegProjection,
    ProjectionStatus,
    diagnose_environmental_packet_update,
    diagnose_packet_update,
)
from .intervention_scope import (
    InterventionScope,
    MissionPlan,
    ScopeAssessment,
    ScopeEvaluation,
    ScopeViolation,
    TaskDecision,
    scope_permissions,
    scope_violations,
    smallest_feasible_scope,
    validate_scope_change,
    validate_scope_hierarchy,
)

__all__ = [
    "EnvironmentSnapshot",
    "DependencyEdge",
    "DependencyVertex",
    "DisturbanceDependencyGraph",
    "DisturbanceImpactClosure",
    "EnvParams",
    "EnvironmentalPacket",
    "EnvironmentalTransition",
    "AirspaceRestriction",
    "WeatherRegion",
    "Network",
    "NetworkEdge",
    "NetworkNode",
    "LegEvaluation",
    "LegImpact",
    "LegProjection",
    "ProjectionStatus",
    "InfeasibilityReason",
    "SafeReturnEvaluation",
    "FixedPlanResult",
    "InterventionScope",
    "MissionPlan",
    "ObjectiveParams",
    "RouteEvaluation",
    "RoutingSimulator",
    "ScopeAssessment",
    "ScopeEvaluation",
    "ScopeViolation",
    "Scenario",
    "ScenarioNode",
    "TaskDecision",
    "evaluate_episode",
    "evaluate_leg",
    "evaluate_safe_return",
    "evaluate_route",
    "execute_fixed_plan",
    "scope_permissions",
    "scope_violations",
    "smallest_feasible_scope",
    "safe_return_margin_wh",
    "seconds_to_wh",
    "compare_environmental_packets",
    "diagnose_environmental_packet_update",
    "diagnose_packet_update",
    "validate_scope_change",
    "validate_scope_hierarchy",
]
