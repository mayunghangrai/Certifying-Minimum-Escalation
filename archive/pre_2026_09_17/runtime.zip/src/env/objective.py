"""Humanitarian routing objective for known-demand relief missions.

Primary objective: priority-weighted, quantity-weighted relief delivery
time.  Each delivered unit is charged its delivery time; demand that is
never delivered is charged the mission horizon:

    J_time = sum_i p_i * [ sum_{deliveries to i} q * t_q  +  undelivered_i * T ]

Quantity weighting matches the split-delivery logistics model (partial
deliveries of individual commodities are allowed), and the expression
reduces to the classical sum of priority-weighted completion times when
every node receives one complete delivery.  It equals the deprivation
integral of ``env.deprivation`` evaluated with a flat waiting profile
(lambda = alpha = 0) and unit commodity weights; deprivation itself remains
available as an outcome metric and is not the optimization objective.

Fairness: maximin fulfilment across relief locations, a standard equity
criterion in humanitarian logistics.  With per-node fill ratios
r_i = delivered_i / required_i, the unfairness term is 1 - min_i r_i.

Composite (normalized weighted sum):

    J = J_time / J_time^ref + lambda_fair * (1 - min_i r_i),

where J_time^ref = T * sum_i p_i * sum_k d_ik is the objective value of
delivering nothing before the horizon.  Both terms are dimensionless and
bounded, so no further scale alignment is needed.  Energy and plan
disruption are deliberately absent: energy enters as a hard feasibility
constraint (safe return), and plan disruption is a diagnostic, not an
objective term.

This module is the single scoring entry point.  Episode reporting uses it,
and any future initial construction, local repair, cross-UAV reassignment,
or global reoptimization must score candidates through these same functions
so that every decision layer shares identical objective semantics.
"""

from __future__ import annotations

import dataclasses
import math
from dataclasses import dataclass
from typing import Dict, Optional, Sequence, Tuple

import numpy as np


DeliveryLogEntry = Tuple[int, np.ndarray, float]
"""(node_idx, delivered quantities per commodity, delivery time in hours)."""


@dataclass(frozen=True)
class ObjectiveParams:
    """Configurable weights of the normalized humanitarian composite.

    ``lambda_fair`` weights the maximin fill-ratio shortfall against the
    normalized priority-weighted delivery time.  The default 0.25 is an a
    priori structural choice (timeliness primary, fairness secondary); it
    must not be tuned on final benchmark performance.
    """

    lambda_fair: float = 0.25

    def __post_init__(self) -> None:
        value = float(self.lambda_fair)
        if not math.isfinite(value) or value < 0.0:
            raise ValueError("objective.lambda_fair must be finite and nonnegative")
        object.__setattr__(self, "lambda_fair", value)

    @classmethod
    def from_dict(cls, payload) -> "ObjectiveParams":
        payload = dict(payload or {})
        valid = {field.name for field in dataclasses.fields(cls)}
        unknown = sorted(set(payload) - valid)
        if unknown:
            raise ValueError(f"unknown objective keys: {unknown}")
        return cls(**payload)

    def to_dict(self) -> Dict[str, float]:
        return {"lambda_fair": self.lambda_fair}


def _validated_demands(priorities, initial_demand) -> Tuple[np.ndarray, np.ndarray]:
    priorities = np.asarray(priorities, dtype=float)
    demand = np.asarray(initial_demand, dtype=float)
    if priorities.ndim != 1 or demand.ndim != 2:
        raise ValueError("priorities must be a vector and initial_demand a matrix")
    if demand.shape[0] != priorities.shape[0]:
        raise ValueError("priorities and initial_demand must share the node count")
    if not np.all(np.isfinite(priorities)) or not np.all(np.isfinite(demand)):
        raise ValueError("priorities and initial_demand must be finite")
    if np.any(priorities <= 0.0):
        raise ValueError("priorities must be positive")
    if np.any(demand < 0.0):
        raise ValueError("initial_demand must be nonnegative")
    return priorities, demand


def delivered_per_node(node_count: int, delivery_log: Sequence[DeliveryLogEntry],
                       n_commodities: int) -> np.ndarray:
    """Accumulate per-node delivered quantities from a delivery log."""
    delivered = np.zeros((node_count, n_commodities), dtype=float)
    for node_idx, quantities, _ in delivery_log:
        delivered[int(node_idx)] += np.asarray(quantities, dtype=float)
    return delivered


def quantity_weighted_delivery_time(
    priorities,
    initial_demand,
    delivery_log: Sequence[DeliveryLogEntry],
    horizon_h: float,
) -> float:
    """J_time: priority-weighted, quantity-weighted delivery time."""
    priorities, demand = _validated_demands(priorities, initial_demand)
    horizon = float(horizon_h)
    if not math.isfinite(horizon) or horizon <= 0.0:
        raise ValueError("horizon_h must be positive and finite")
    weighted_times = np.zeros(priorities.shape[0], dtype=float)
    delivered = np.zeros_like(demand)
    for node_idx, quantities, time_h in delivery_log:
        amounts = np.asarray(quantities, dtype=float)
        delivered[int(node_idx)] += amounts
        weighted_times[int(node_idx)] += float(np.sum(amounts)) * float(time_h)
    undelivered = np.maximum(
        demand.sum(axis=1) - delivered.sum(axis=1), 0.0
    )
    per_node = weighted_times + undelivered * horizon
    return float(np.dot(priorities, per_node))


def reference_delivery_time(priorities, initial_demand, horizon_h: float) -> float:
    """J_time^ref = T * sum_i p_i * sum_k d_ik (nothing delivered)."""
    priorities, demand = _validated_demands(priorities, initial_demand)
    return float(horizon_h) * float(
        np.dot(priorities, demand.sum(axis=1))
    )


def fill_ratios(delivered, initial_demand) -> np.ndarray:
    """Per-node service ratios r_i = delivered_i / required_i in [0, 1]."""
    delivered = np.asarray(delivered, dtype=float)
    _, demand = _validated_demands(
        np.ones(delivered.shape[0], dtype=float), initial_demand
    )
    required = demand.sum(axis=1)
    ratios = np.ones(delivered.shape[0], dtype=float)
    positive = required > 0.0
    ratios[positive] = np.clip(
        delivered.sum(axis=1)[positive] / required[positive], 0.0, 1.0
    )
    return ratios


def min_fill_ratio(ratios) -> float:
    """Maximin fulfilment level min_i r_i (1.0 for an empty node set)."""
    ratios = np.asarray(ratios, dtype=float)
    if ratios.size == 0:
        return 1.0
    return float(np.min(ratios))


def composite_objective(
    j_time: float,
    j_time_ref: float,
    min_fill: float,
    lambda_fair: float,
) -> float:
    """Normalized composite J = J_time/J_ref + lambda_fair * (1 - min r)."""
    normalized_time = 0.0 if j_time_ref <= 0.0 else float(j_time) / float(j_time_ref)
    return normalized_time + float(lambda_fair) * (1.0 - float(min_fill))


def evaluate_episode(
    priorities,
    initial_demand,
    delivery_log: Sequence[DeliveryLogEntry],
    horizon_h: float,
    params: Optional[ObjectiveParams] = None,
) -> Dict:
    """Full humanitarian objective report for one episode."""
    objective = params or ObjectiveParams()
    priorities, demand = _validated_demands(priorities, initial_demand)
    delivered = delivered_per_node(
        priorities.shape[0], delivery_log, demand.shape[1]
    )
    j_time = quantity_weighted_delivery_time(
        priorities, demand, delivery_log, horizon_h
    )
    j_ref = reference_delivery_time(priorities, demand, horizon_h)
    ratios = fill_ratios(delivered, demand)
    min_fill = min_fill_ratio(ratios)
    return {
        "j_time": j_time,
        "j_time_ref": j_ref,
        "normalized_time": 0.0 if j_ref <= 0.0 else j_time / j_ref,
        "fill_ratios": ratios.tolist(),
        "min_fill_ratio": min_fill,
        "lambda_fair": objective.lambda_fair,
        "composite": composite_objective(
            j_time, j_ref, min_fill, objective.lambda_fair
        ),
    }
