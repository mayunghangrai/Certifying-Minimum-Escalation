"""Known-demand scenarios for information-aware route replanning.

The task instance is completely known at time zero.  Only exogenous route
conditions evolve: reported weather hazards and temporary airspace closures.
Future updates are pre-sampled for reproducibility but are revealed to the
controller only through the environment event queue.
"""

from __future__ import annotations

import dataclasses
import hashlib
import json
import math
import numbers
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import numpy as np
from shapely.geometry import LineString, Point, Polygon, box
from shapely.ops import unary_union

from .airspace import AirspaceMap, AirspaceUpdateEvent, HazardRegion, NoFlyZone
from .environment import AirspaceRestriction, EnvironmentalPacket, WeatherRegion
from .energy import max_service_radius
from .objective import ObjectiveParams
from .params import N_COMMODITIES, EnvParams
from .scenario import GENERATOR_VERSION, SCHEMA_VERSION, Scenario, ScenarioNode
from .wind import WindForecastPoint, interpolate_wind_vector


_VALID_MODES = {"static", "weather", "airspace", "mixed"}


@dataclass(frozen=True, init=False)
class WindForecastConfig:
    """Seeded global packet-wind settings.

    The constructor accepts the old v2 names only as migration aliases. They
    are never emitted by :meth:`to_dict` and are not used as forecast error.
    """

    enabled: bool = True
    update_interval_h: float = 0.5
    lookahead_h: float = 1.5
    time_step_h: float = 0.5
    min_speed_kmh: float = 6.0
    max_speed_kmh: float = 24.0
    max_turn_deg: float = 35.0
    revision_magnitude_kmh: float = 3.0

    def __init__(
        self,
        enabled: bool = True,
        update_interval_h: float = 0.5,
        lookahead_h: float = 1.5,
        time_step_h: float = 0.5,
        min_speed_kmh: float = 6.0,
        max_speed_kmh: float = 24.0,
        max_turn_deg: float = 35.0,
        revision_magnitude_kmh: float = 3.0,
        *,
        truth_step_h: float | None = None,
        forecast_update_interval_h: float | None = None,
        forecast_horizon_h: float | None = None,
        forecast_step_h: float | None = None,
        nowcast_error_kmh: float | None = None,
        horizon_error_kmh: float | None = None,
    ) -> None:
        if truth_step_h is not None:
            time_step_h = truth_step_h
        if forecast_update_interval_h is not None:
            update_interval_h = forecast_update_interval_h
        if forecast_horizon_h is not None:
            lookahead_h = forecast_horizon_h
        if forecast_step_h is not None:
            time_step_h = forecast_step_h
        if horizon_error_kmh is not None:
            revision_magnitude_kmh = horizon_error_kmh
        elif nowcast_error_kmh is not None:
            revision_magnitude_kmh = nowcast_error_kmh
        object.__setattr__(self, "enabled", enabled)
        object.__setattr__(self, "update_interval_h", update_interval_h)
        object.__setattr__(self, "lookahead_h", lookahead_h)
        object.__setattr__(self, "time_step_h", time_step_h)
        object.__setattr__(self, "min_speed_kmh", min_speed_kmh)
        object.__setattr__(self, "max_speed_kmh", max_speed_kmh)
        object.__setattr__(self, "max_turn_deg", max_turn_deg)
        object.__setattr__(self, "revision_magnitude_kmh", revision_magnitude_kmh)
        self.__post_init__()

    def __post_init__(self) -> None:
        if not isinstance(self.enabled, bool):
            raise ValueError("wind.enabled must be a boolean")
        positive = (
            "update_interval_h",
            "lookahead_h",
            "time_step_h",
        )
        nonnegative = (
            "min_speed_kmh",
            "max_speed_kmh",
            "max_turn_deg",
            "revision_magnitude_kmh",
        )
        for name in (*positive, *nonnegative):
            try:
                value = float(getattr(self, name))
            except (TypeError, ValueError) as error:
                raise ValueError(f"wind.{name} must be numeric") from error
            if not math.isfinite(value):
                raise ValueError(f"wind.{name} must be finite")
            if name in positive and value <= 0.0:
                raise ValueError(f"wind.{name} must be positive")
            if name in nonnegative and value < 0.0:
                raise ValueError(f"wind.{name} must be nonnegative")
            object.__setattr__(self, name, value)
        if self.lookahead_h < self.time_step_h:
            raise ValueError("wind forecast horizon must cover at least one step")
        if self.min_speed_kmh >= self.max_speed_kmh:
            raise ValueError("wind speed range must satisfy min < max")
        if not 0.0 < self.max_turn_deg <= 180.0:
            raise ValueError("wind.max_turn_deg must satisfy 0 < value <= 180")

    @property
    def truth_step_h(self) -> float:
        return self.time_step_h

    @property
    def forecast_update_interval_h(self) -> float:
        return self.update_interval_h

    @property
    def forecast_horizon_h(self) -> float:
        return self.lookahead_h

    @property
    def forecast_step_h(self) -> float:
        return self.time_step_h

    @property
    def nowcast_error_kmh(self) -> float:
        return 0.0

    @property
    def horizon_error_kmh(self) -> float:
        return self.revision_magnitude_kmh

    def to_dict(self) -> dict:
        return {
            "enabled": self.enabled,
            "update_interval_h": self.update_interval_h,
            "lookahead_h": self.lookahead_h,
            "time_step_h": self.time_step_h,
            "min_speed_kmh": self.min_speed_kmh,
            "max_speed_kmh": self.max_speed_kmh,
            "max_turn_deg": self.max_turn_deg,
            "revision_magnitude_kmh": self.revision_magnitude_kmh,
        }

    @classmethod
    def from_dict(cls, payload: Dict | None) -> "WindForecastConfig":
        payload = dict(payload or {})
        aliases = {
            "truth_step_h": "time_step_h",
            "forecast_update_interval_h": "update_interval_h",
            "forecast_horizon_h": "lookahead_h",
            "forecast_step_h": "time_step_h",
            "horizon_error_kmh": "revision_magnitude_kmh",
            "nowcast_error_kmh": "revision_magnitude_kmh",
        }
        canonical = {}
        for key, value in payload.items():
            canonical[aliases.get(key, key)] = value
        valid = {item.name for item in dataclasses.fields(cls)}
        unknown = sorted(set(canonical) - valid)
        if unknown:
            raise ValueError(f"unknown wind keys: {unknown}")
        return cls(**canonical)


@dataclass(frozen=True)
class RouteDisruptionConfig:
    """Controls the exogenous route-information process."""

    mode: str = "mixed"
    weather_episodes: int = 2
    airspace_episodes: int = 2
    onset_window_frac: Tuple[float, float] = (0.15, 0.70)
    duration_h: Tuple[float, float] = (0.75, 1.50)
    wind: WindForecastConfig = field(default_factory=WindForecastConfig)

    def __post_init__(self) -> None:
        object.__setattr__(self, "mode", str(self.mode).lower())
        if self.mode not in _VALID_MODES:
            raise ValueError(f"mode must be one of {sorted(_VALID_MODES)}")
        for name in ("weather_episodes", "airspace_episodes"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, numbers.Integral):
                raise ValueError(f"{name} must be an integer")
            if value < 0:
                raise ValueError("episode counts must be nonnegative")
            object.__setattr__(self, name, int(value))
        try:
            onset_window = tuple(float(value) for value in self.onset_window_frac)
            duration = tuple(float(value) for value in self.duration_h)
        except (TypeError, ValueError) as error:
            raise ValueError("timing ranges must contain numeric values") from error
        object.__setattr__(self, "onset_window_frac", onset_window)
        object.__setattr__(self, "duration_h", duration)
        if isinstance(self.wind, dict):
            object.__setattr__(self, "wind", WindForecastConfig.from_dict(self.wind))
        elif not isinstance(self.wind, WindForecastConfig):
            raise ValueError("wind must be a WindForecastConfig or mapping")
        if len(onset_window) != 2 or not all(map(math.isfinite, onset_window)) or not (
            0.0 < onset_window[0] < onset_window[1] < 1.0
        ):
            raise ValueError("onset_window_frac must satisfy 0 < low < high < 1")
        if len(duration) != 2 or not all(map(math.isfinite, duration)) or not (
            0.0 < duration[0] <= duration[1]
        ):
            raise ValueError("duration_h must satisfy 0 < low <= high")

    @classmethod
    def from_dict(cls, payload: Dict | None) -> "RouteDisruptionConfig":
        payload = dict(payload or {})
        valid = {field.name for field in dataclasses.fields(cls)}
        unknown = sorted(set(payload) - valid)
        if unknown:
            raise ValueError(f"unknown route_information keys: {unknown}")
        payload["wind"] = WindForecastConfig.from_dict(payload.get("wind"))
        return cls(**payload)

    def to_dict(self) -> dict:
        return {
            "mode": self.mode,
            "weather_episodes": self.weather_episodes,
            "airspace_episodes": self.airspace_episodes,
            "onset_window_frac": list(self.onset_window_frac),
            "duration_h": list(self.duration_h),
            "wind": self.wind.to_dict(),
        }


def load_information_aware_config(
    path: str | Path,
) -> Tuple[EnvParams, RouteDisruptionConfig, ObjectiveParams]:
    """Load environment, route-information, and objective settings from YAML."""
    import yaml

    with open(path, "r", encoding="utf-8") as handle:
        payload = yaml.safe_load(handle) or {}
    unknown = sorted(
        set(payload) - {"environment", "route_information", "objective"}
    )
    if unknown:
        raise ValueError(f"unknown top-level scenario config keys: {unknown}")
    return (
        EnvParams.from_dict(payload.get("environment") or {}),
        RouteDisruptionConfig.from_dict(payload.get("route_information")),
        ObjectiveParams.from_dict(payload.get("objective")),
    )


def _neutral_environment_packets(
    horizon: float,
    update_interval_h: float,
    lookahead_h: float,
    time_step_h: float,
) -> list[EnvironmentalPacket]:
    packets = []
    for index, issued_at_h in enumerate(
        _time_grid(0.0, horizon, update_interval_h)
    ):
        if issued_at_h >= horizon - 1e-9:
            continue
        valid_until_h = min(horizon, issued_at_h + lookahead_h)
        points = tuple(
            WindForecastPoint(valid_time_h=time_h, u_kmh=0.0, v_kmh=0.0)
            for time_h in _time_grid(issued_at_h, valid_until_h, time_step_h)
        )
        packets.append(EnvironmentalPacket(
            packet_id=f"ENV-{index:03d}",
            issued_at_h=issued_at_h,
            valid_from_h=issued_at_h,
            valid_until_h=valid_until_h,
            wind=points,
        ))
    return packets


def _place_nodes(
    rng: np.random.Generator,
    params: EnvParams,
    depot: np.ndarray,
    placement_radius: float,
) -> np.ndarray:
    """Place separated tasks in visible disaster clusters inside the map."""
    map_params = params.map
    cluster_count = map_params.n_clusters
    base_angle = float(rng.uniform(0.0, 2.0 * math.pi))
    centers = None
    for _ in range(300):
        angles = (
            base_angle
            + np.arange(cluster_count) * (2.0 * math.pi / cluster_count)
            + rng.uniform(-0.35, 0.35, cluster_count)
        )
        radii = rng.uniform(0.35 * placement_radius, 0.80 * placement_radius,
                            cluster_count)
        candidate = depot + np.stack(
            [radii * np.cos(angles), radii * np.sin(angles)], axis=1
        )
        if cluster_count == 1:
            centers = candidate
            break
        distances = np.linalg.norm(candidate[:, None] - candidate[None, :], axis=-1)
        if distances[np.triu_indices(cluster_count, 1)].min() >= 0.70 * placement_radius:
            centers = candidate
            break
    if centers is None:
        angles = base_angle + np.arange(cluster_count) * (
            2.0 * math.pi / cluster_count
        )
        centers = depot + 0.60 * placement_radius * np.stack(
            [np.cos(angles), np.sin(angles)], axis=1
        )

    guaranteed = map_params.n_nodes // (2 * cluster_count)
    assignments = np.repeat(np.arange(cluster_count), guaranteed)
    weights = rng.dirichlet(np.full(cluster_count, 3.0))
    remainder = rng.choice(
        cluster_count,
        size=map_params.n_nodes - len(assignments),
        p=weights,
    )
    assignments = np.concatenate([assignments, remainder])
    rng.shuffle(assignments)

    positions: List[np.ndarray] = []
    separation = map_params.min_node_sep_km
    for cluster_index in assignments:
        for _ in range(600):
            position = centers[cluster_index] + rng.normal(
                0.0, map_params.cluster_std_km, 2
            )
            depot_distance = float(np.linalg.norm(position - depot))
            if not separation <= depot_distance <= placement_radius:
                continue
            if np.any(position <= 0.0) or np.any(position >= map_params.region_km):
                continue
            if positions and min(
                float(np.linalg.norm(position - other)) for other in positions
            ) < separation:
                continue
            positions.append(position)
            break
        else:
            raise RuntimeError("could not place all separated scenario tasks")
    return np.asarray(positions, dtype=float)


def _known_task_scenario(
    seed: int,
    params: EnvParams,
    rng: np.random.Generator,
    priority_rng: np.random.Generator,
) -> Scenario:
    depot = np.array([params.map.region_km / 2.0] * 2, dtype=float)
    service_radius = max_service_radius(params.physics, conservative=True)
    placement_radius = min(
        params.map.feasible_frac * service_radius,
        0.48 * params.map.region_km,
    )
    positions = _place_nodes(rng, params, depot, placement_radius)
    demand_mean = np.asarray(params.map.demand_mean_k, dtype=float)
    nodes: List[ScenarioNode] = []
    for index, position in enumerate(positions):
        severity = float(rng.uniform(0.6, 1.6))
        demand = rng.poisson(demand_mean * severity).astype(float)
        if demand.sum() <= 0.0:
            demand[int(rng.integers(N_COMMODITIES))] = 1.0
        nodes.append(ScenarioNode(
            idx=index,
            x=float(position[0]),
            y=float(position[1]),
            vulnerability=float(rng.uniform(*params.map.nu_range)),
            demand=[float(value) for value in demand],
            priority=float(priority_rng.uniform(*params.map.priority_range)),
        ))
    inventory = np.sum([node.demand for node in nodes], axis=0)
    return Scenario(
        seed=int(seed),
        params=params.to_dict(),
        depot=[float(value) for value in depot],
        nodes=nodes,
        initial_inventory=[float(value) for value in inventory],
        no_fly_zones=[],
        hazard_regions=[],
        airspace_updates=[],
        environment_packets=_neutral_environment_packets(
            float(params.mission.T),
            float(params.mission.environment_update_interval_h),
            float(params.mission.forecast_horizon_h),
            float(params.mission.environment_update_interval_h),
        ),
        generation_metadata={},
    )


def _oriented_rectangle(
    center: np.ndarray,
    direction: np.ndarray,
    half_length: float,
    half_width: float,
) -> List[Tuple[float, float]]:
    norm = float(np.linalg.norm(direction))
    axis = direction / norm if norm > 1e-12 else np.array([1.0, 0.0])
    normal = np.array([-axis[1], axis[0]])
    corners = [
        center - half_length * axis - half_width * normal,
        center + half_length * axis - half_width * normal,
        center + half_length * axis + half_width * normal,
        center - half_length * axis + half_width * normal,
    ]
    return [(float(point[0]), float(point[1])) for point in corners]


def _geometry_is_valid(
    polygons: Sequence[Sequence[Tuple[float, float]]],
    protected_positions: Sequence[np.ndarray],
    region_km: float,
    required_clearance_km: float,
) -> bool:
    for points in polygons:
        geometry = Polygon(points).buffer(required_clearance_km)
        min_x, min_y, max_x, max_y = geometry.bounds
        if not (0.0 < min_x < max_x < region_km):
            return False
        if not (0.0 < min_y < max_y < region_km):
            return False
        if any(geometry.covers(Point(position)) for position in protected_positions):
            return False
    return True


def _corridor_polygons(
    rng: np.random.Generator,
    depot: np.ndarray,
    node_positions: np.ndarray,
    target_index: int,
    region_km: float,
    required_clearance_km: float,
    moving: bool,
) -> Tuple[List[Tuple[float, float]], List[Tuple[float, float]]]:
    protected = [depot, *node_positions]
    distances = np.linalg.norm(node_positions - depot, axis=1)
    alternatives = [
        int(index) for index in np.argsort(distances)[::-1]
        if int(index) != target_index
    ]
    for candidate_index in [target_index, *alternatives]:
        target = node_positions[candidate_index]
        direction = target - depot
        distance = float(np.linalg.norm(direction))
        if distance <= 1e-9:
            continue
        axis = direction / distance
        normal = np.array([-axis[1], axis[0]])
        corridor = LineString([depot, target])

        for _ in range(300):
            fraction = float(rng.uniform(0.36, 0.64))
            half_length = min(float(rng.uniform(0.18, 0.34)), 0.13 * distance)
            half_width = min(float(rng.uniform(0.28, 0.48)), 0.18 * distance)
            half_length = max(half_length, 0.06)
            half_width = max(half_width, 0.12)
            center = depot + fraction * direction
            initial = _oriented_rectangle(center, direction, half_length, half_width)
            shift = 0.0
            if moving:
                shift = float(rng.choice((-1.0, 1.0))) * 0.55 * half_width
            moved = _oriented_rectangle(
                center + shift * normal,
                direction,
                half_length,
                half_width,
            )
            if not _geometry_is_valid(
                [initial, moved], protected, region_km, required_clearance_km
            ):
                continue
            if corridor.intersects(Polygon(initial)) and corridor.intersects(Polygon(moved)):
                return initial, moved
    raise RuntimeError("could not place a route-relevant region without covering a task")


def _hard_states_leave_routes_reachable(scenario: Scenario) -> bool:
    """Check continuous free-space connectivity without using a tested planner."""
    airspace = AirspaceMap(scenario.no_fly_zones, scenario.hazard_regions)
    clearance_km = (
        scenario.env_params().route_validation.safe_corridor_margin_m / 1000.0
    )
    boundary = box(
        0.0,
        0.0,
        scenario.env_params().map.region_km,
        scenario.env_params().map.region_km,
    )
    positions = [scenario.depot, *scenario.node_positions()]
    for update in scenario.airspace_timeline():
        airspace.apply_update(update)
        if any(not airspace.segment_is_safe(
            position,
            position,
            update.time_h,
            extra_margin_km=clearance_km,
        ) for position in positions):
            return False
        blocked = [
            geometry.buffer(clearance_km)
            for geometry in airspace.hard_geometries(update.time_h)
        ]
        free_space = boundary if not blocked else boundary.difference(
            unary_union(blocked)
        )
        components = list(getattr(free_space, "geoms", [free_space]))
        depot_point = Point(scenario.depot)
        depot_component = next(
            (component for component in components if component.contains(depot_point)),
            None,
        )
        if depot_component is None or any(
            not depot_component.contains(Point(position)) for position in positions
        ):
            return False
    return True


def _target_indices(
    rng: np.random.Generator,
    depot: np.ndarray,
    node_positions: np.ndarray,
    count: int,
) -> List[int]:
    if count == 0:
        return []
    distances = np.linalg.norm(node_positions - depot, axis=1)
    candidate_count = max(count, int(math.ceil(len(node_positions) / 2.0)))
    candidates = np.argsort(distances)[-min(candidate_count, len(node_positions)):]
    shuffled = list(rng.permutation(candidates).astype(int))
    return [shuffled[index % len(shuffled)] for index in range(count)]


def _episode_windows(
    rng: np.random.Generator,
    count: int,
    horizon: float,
    config: RouteDisruptionConfig,
) -> List[Tuple[float, float]]:
    if count == 0:
        return []
    start = config.onset_window_frac[0] * horizon
    latest = min(
        config.onset_window_frac[1] * horizon,
        horizon - config.duration_h[0],
    )
    if latest <= start:
        raise ValueError("mission horizon is too short for the disruption timing profile")
    strata = np.linspace(start, latest, count + 1)
    windows: List[Tuple[float, float]] = []
    for index in range(count):
        onset = float(rng.uniform(strata[index], strata[index + 1]))
        maximum_duration = min(
            config.duration_h[1],
            horizon - onset,
        )
        minimum_duration = min(config.duration_h[0], maximum_duration)
        duration = float(rng.uniform(minimum_duration, maximum_duration)) \
            if maximum_duration > minimum_duration else float(maximum_duration)
        windows.append((onset, onset + duration))
    return windows


def _weather_disruptions(
    rng: np.random.Generator,
    scenario: Scenario,
    config: RouteDisruptionConfig,
) -> Tuple[List[HazardRegion], List[AirspaceUpdateEvent]]:
    depot = np.asarray(scenario.depot, dtype=float)
    positions = scenario.node_positions()
    planner_clearance_km = (
        scenario.env_params().route_validation.safe_corridor_margin_m / 1000.0
    )
    targets = _target_indices(rng, depot, positions, config.weather_episodes)
    windows = _episode_windows(
        rng, config.weather_episodes, scenario.env_params().mission.T, config
    )
    regions: List[HazardRegion] = []
    updates: List[AirspaceUpdateEvent] = []

    for index, (target, (onset, end)) in enumerate(zip(targets, windows), start=1):
        initial_polygon, moved_polygon = _corridor_polygons(
            rng,
            depot,
            positions,
            target,
            scenario.env_params().map.region_km,
            required_clearance_km=0.01 + planner_clearance_km,
            moving=True,
        )
        severe = index % 2 == 0
        hazard_type = "convective_weather" if severe else "high_wind"
        initial_severity = 0.55 if severe else 0.35
        peak_severity = 0.90 if severe else 0.65
        region_id = f"WEATHER-{index:02d}"
        regions.append(HazardRegion(
            id=region_id,
            polygon=initial_polygon,
            severity=initial_severity,
            hazard_type=hazard_type,
            active_from=onset,
            active_until=None,
            version=1,
            safety_buffer_m=10.0,
            hard_threshold=0.80,
        ))
        duration = end - onset
        move_time = onset + 0.30 * duration
        peak_time = onset + 0.55 * duration
        weaken_time = onset + 0.78 * duration
        updates.extend([
            AirspaceUpdateEvent(
                time_h=move_time,
                region_id=region_id,
                region_type="hazard",
                update_type="MOVE",
                new_polygon=moved_polygon,
                version=2,
            ),
            AirspaceUpdateEvent(
                time_h=peak_time,
                region_id=region_id,
                region_type="hazard",
                update_type="SEVERITY_CHANGE",
                new_severity=peak_severity,
                version=3,
            ),
            AirspaceUpdateEvent(
                time_h=weaken_time,
                region_id=region_id,
                region_type="hazard",
                update_type="SEVERITY_CHANGE",
                new_severity=0.25,
                version=4,
            ),
            AirspaceUpdateEvent(
                time_h=end,
                region_id=region_id,
                region_type="hazard",
                update_type="DEACTIVATE",
                version=5,
            ),
        ])
    return regions, updates


def _airspace_disruptions(
    rng: np.random.Generator,
    scenario: Scenario,
    config: RouteDisruptionConfig,
) -> Tuple[List[NoFlyZone], List[AirspaceUpdateEvent]]:
    depot = np.asarray(scenario.depot, dtype=float)
    positions = scenario.node_positions()
    planner_clearance_km = (
        scenario.env_params().route_validation.safe_corridor_margin_m / 1000.0
    )
    targets = _target_indices(rng, depot, positions, config.airspace_episodes)
    windows = _episode_windows(
        rng, config.airspace_episodes, scenario.env_params().mission.T, config
    )
    regions: List[NoFlyZone] = []
    updates: List[AirspaceUpdateEvent] = []

    for index, (target, (onset, end)) in enumerate(zip(targets, windows), start=1):
        polygon, _ = _corridor_polygons(
            rng,
            depot,
            positions,
            target,
            scenario.env_params().map.region_km,
            required_clearance_km=0.02 + planner_clearance_km,
            moving=False,
        )
        region_id = f"AIRSPACE-{index:02d}"
        regions.append(NoFlyZone(
            id=region_id,
            polygon=polygon,
            active_from=onset,
            active_until=None,
            version=1,
            safety_buffer_m=20.0,
        ))
        updates.append(AirspaceUpdateEvent(
            time_h=end,
            region_id=region_id,
            region_type="no_fly",
            update_type="DEACTIVATE",
            version=2,
        ))
    return regions, updates


def _time_grid(start: float, end: float, step: float) -> List[float]:
    values = [float(start)]
    while values[-1] + step < end - 1e-9:
        values.append(values[-1] + step)
    if end > values[-1] + 1e-9:
        values.append(float(end))
    return [round(value, 9) for value in values]


def _wind_path(
    rng: np.random.Generator,
    horizon: float,
    config: WindForecastConfig,
) -> List[List[float]]:
    """Create a smooth internal path used to seed packet information.

    The path is a generator intermediate only. It is deliberately not
    serialized as latent truth; packets are the scenario's environmental
    source of truth.
    """
    times = _time_grid(0.0, horizon, config.time_step_h)
    direction = float(rng.uniform(-math.pi, math.pi))
    speed = float(rng.uniform(config.min_speed_kmh, config.max_speed_kmh))
    midpoint = 0.5 * (config.min_speed_kmh + config.max_speed_kmh)
    speed_span = config.max_speed_kmh - config.min_speed_kmh
    maximum_turn = math.radians(config.max_turn_deg)
    path: List[List[float]] = []
    for index, time_h in enumerate(times):
        if index:
            direction += float(np.clip(
                rng.normal(0.0, maximum_turn / 3.0),
                -maximum_turn,
                maximum_turn,
            ))
            speed = float(np.clip(
                speed + 0.30 * (midpoint - speed)
                + rng.normal(0.0, 0.08 * speed_span),
                config.min_speed_kmh,
                config.max_speed_kmh,
            ))
        path.append([
            float(time_h),
            round(speed * math.cos(direction), 8),
            round(speed * math.sin(direction), 8),
        ])
    return path


def _packet_wind_points(
    base_path: Sequence[Sequence[float]],
    revision_bias: np.ndarray,
    issued_at_h: float,
    valid_until_h: float,
    time_step_h: float,
) -> Tuple[WindForecastPoint, ...]:
    points = []
    for valid_time_h in _time_grid(issued_at_h, valid_until_h, time_step_h):
        base = interpolate_wind_vector(base_path, valid_time_h)
        points.append(WindForecastPoint(
            valid_time_h=valid_time_h,
            u_kmh=round(float(base[0] + revision_bias[0]), 8),
            v_kmh=round(float(base[1] + revision_bias[1]), 8),
        ))
    return tuple(points)


def _packet_region_state(
    region: Any,
    updates: Sequence[AirspaceUpdateEvent],
    issue_time_h: float,
) -> tuple[bool, List[Tuple[float, float]], float | None]:
    polygon = [tuple(point) for point in region.polygon]
    severity = float(region.severity) if isinstance(region, HazardRegion) else None
    active = issue_time_h >= float(region.active_from) - 1e-9
    for update in updates:
        if update.region_id != region.id or update.time_h > issue_time_h + 1e-9:
            continue
        if update.update_type == "DEACTIVATE":
            active = False
        elif update.update_type == "ACTIVATE":
            active = True
            if update.new_polygon is not None:
                polygon = [tuple(point) for point in update.new_polygon]
        elif update.update_type in {"MOVE", "EXPAND", "SHRINK"}:
            if update.new_polygon is not None:
                polygon = [tuple(point) for point in update.new_polygon]
        elif update.update_type == "SEVERITY_CHANGE" and update.new_severity is not None:
            severity = float(update.new_severity)
    return active, polygon, severity


def _packet_regions(
    issue_time_h: float,
    valid_until_h: float,
    hazards: Sequence[HazardRegion],
    zones: Sequence[NoFlyZone],
    updates: Sequence[AirspaceUpdateEvent],
) -> tuple[tuple[WeatherRegion, ...], tuple[AirspaceRestriction, ...]]:
    weather: list[WeatherRegion] = []
    airspace: list[AirspaceRestriction] = []
    for region in hazards:
        end = next(
            (
                event.time_h for event in updates
                if event.region_id == region.id and event.update_type == "DEACTIVATE"
            ),
            valid_until_h,
        )
        if max(float(region.active_from), issue_time_h) >= min(float(end), valid_until_h) - 1e-9:
            continue
        active, polygon, severity = _packet_region_state(region, updates, issue_time_h)
        if not active and issue_time_h >= end - 1e-9:
            continue
        weather.append(WeatherRegion(
            id=region.id,
            geometry=polygon,
            severity="HARD" if float(severity) >= region.hard_threshold else "SOFT",
            valid_from_h=max(float(region.active_from), issue_time_h),
            valid_until_h=min(float(end), valid_until_h),
            safety_buffer_m=region.safety_buffer_m,
        ))
    for region in zones:
        end = next(
            (
                event.time_h for event in updates
                if event.region_id == region.id and event.update_type == "DEACTIVATE"
            ),
            valid_until_h,
        )
        if max(float(region.active_from), issue_time_h) >= min(float(end), valid_until_h) - 1e-9:
            continue
        active, polygon, _ = _packet_region_state(region, updates, issue_time_h)
        if not active and issue_time_h >= end - 1e-9:
            continue
        airspace.append(AirspaceRestriction(
            id=region.id,
            geometry=polygon,
            valid_from_h=max(float(region.active_from), issue_time_h),
            valid_until_h=min(float(end), valid_until_h),
            safety_buffer_m=region.safety_buffer_m,
        ))
    return tuple(weather), tuple(airspace)


def _authoritative_environment_packets(
    packet_rng: np.random.Generator,
    scenario: Scenario,
    config: WindForecastConfig,
    hazards: Sequence[HazardRegion],
    zones: Sequence[NoFlyZone],
    updates: Sequence[AirspaceUpdateEvent],
) -> list[EnvironmentalPacket]:
    horizon = float(scenario.env_params().mission.T)
    nominal_speed = float(scenario.env_params().physics.v_uav)
    if config.max_speed_kmh >= nominal_speed:
        raise ValueError("wind.max_speed_kmh must be below the UAV nominal speed")
    base_path = _wind_path(packet_rng, horizon, config)
    packets: list[EnvironmentalPacket] = []
    revision_bias = np.zeros(2, dtype=float)
    for index, issued_at_h in enumerate(
        _time_grid(0.0, horizon, config.update_interval_h)
    ):
        if issued_at_h >= horizon - 1e-9:
            continue
        valid_until_h = min(horizon, issued_at_h + config.lookahead_h)
        if index:
            revision_bias = (
                0.65 * revision_bias
                + packet_rng.normal(0.0, config.revision_magnitude_kmh * 0.35, 2)
            )
        points = _packet_wind_points(
            base_path,
            revision_bias,
            issued_at_h,
            valid_until_h,
            config.time_step_h,
        )
        weather, airspace = _packet_regions(
            issued_at_h,
            valid_until_h,
            hazards,
            zones,
            updates,
        )
        packets.append(EnvironmentalPacket(
            packet_id=f"ENV-{index:03d}",
            issued_at_h=issued_at_h,
            valid_from_h=issued_at_h,
            valid_until_h=valid_until_h,
            wind=points,
            weather=weather,
            airspace=airspace,
        ))
    return packets


def generate_information_aware_scenario(
    seed: int,
    params: EnvParams | None = None,
    route_information: RouteDisruptionConfig | None = None,
) -> Scenario:
    """Generate a replayable scenario with known tasks and evolving routes."""
    config = route_information or RouteDisruptionConfig()
    active_params = EnvParams.from_dict((params or EnvParams()).to_dict())
    active_params.mission.environment_update_interval_h = config.wind.update_interval_h
    active_params.mission.forecast_horizon_h = config.wind.lookahead_h
    root_sequence = np.random.SeedSequence([int(seed), 49157])
    (
        task_sequence,
        weather_sequence,
        airspace_sequence,
        packet_sequence,
        priority_sequence,
    ) = root_sequence.spawn(5)
    scenario = _known_task_scenario(
        int(seed),
        active_params,
        np.random.default_rng(task_sequence),
        np.random.default_rng(priority_sequence),
    )

    if config.mode in {"weather", "mixed"}:
        regions, updates = _weather_disruptions(
            np.random.default_rng(weather_sequence), scenario, config
        )
        scenario.hazard_regions = regions
        scenario.airspace_updates.extend(updates)
    if config.mode in {"airspace", "mixed"}:
        zones, updates = _airspace_disruptions(
            np.random.default_rng(airspace_sequence), scenario, config
        )
        scenario.no_fly_zones = zones
        scenario.airspace_updates.extend(updates)
    scenario.airspace_updates.sort(
        key=lambda event: (
            event.time_h,
            event.region_id,
            event.version,
        )
    )
    if not _hard_states_leave_routes_reachable(scenario):
        raise RuntimeError(
            "generated route disruptions disconnect a protected task from the depot"
        )
    if config.wind.enabled:
        scenario.environment_packets = _authoritative_environment_packets(
            np.random.default_rng(packet_sequence),
            scenario,
            config.wind,
            scenario.hazard_regions,
            scenario.no_fly_zones,
            scenario.airspace_updates,
        )
    else:
        scenario.environment_packets = _neutral_environment_packets(
            float(scenario.env_params().mission.T),
            float(config.wind.update_interval_h),
            float(config.wind.lookahead_h),
            float(config.wind.time_step_h),
        )
    scenario.wind_spec = {
        "model": "global_2d_v1",
        "vector_convention": "towards",
        "units": {"time": "h", "speed": "km/h"},
        "forecast_packets": [
            {
                "issued_at_h": packet.issued_at_h,
                "horizon_h": packet.valid_until_h - packet.issued_at_h,
                "points": [point.to_dict() for point in packet.wind],
            }
            for packet in scenario.environment_packets
        ],
    }
    config_hash = hashlib.sha256(json.dumps({
        "environment": active_params.to_dict(),
        "route_information": config.to_dict(),
    }, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
    scenario.metadata = {
        "seed": int(seed),
        "generator_version": GENERATOR_VERSION,
        "config_hash": config_hash,
    }
    scenario.generation_metadata = {
        "schema": SCHEMA_VERSION,
        "generator_version": GENERATOR_VERSION,
        "scenario_type": "known_tasks_dynamic_routes",
        "generator": (
            "env.robust_scenario_generator.generate_information_aware_scenario"
        ),
        "information_timing": {
            "tasks": "complete_at_time_zero",
            "airspace": "revealed_at_effective_time",
            "wind": "authoritative_packets_revealed_at_issue_time",
        },
        "independent_random_streams": [
            "tasks",
            "weather_polygons",
            "airspace_polygons",
            "wind_packets",
            "node_priorities",
        ],
        "route_information": {
            "mode": config.mode,
            "weather_episodes": config.weather_episodes,
            "airspace_episodes": config.airspace_episodes,
            "environment_update_interval_h": (
                config.wind.update_interval_h
            ),
            "lookahead_h": config.wind.lookahead_h,
            "time_step_h": config.wind.time_step_h,
            "revision_magnitude_kmh": config.wind.revision_magnitude_kmh,
        },
    }
    scenario.scenario_descriptors = scenario._build_descriptors()
    return scenario
