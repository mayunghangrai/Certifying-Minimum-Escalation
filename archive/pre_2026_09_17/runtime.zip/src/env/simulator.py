"""Method-neutral execution of externally supplied routing commands.

The simulator owns event time and physical accounting.  It never selects a
task, orders tasks, constructs a route, repairs a route, or replans a flight.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Optional, Sequence, Tuple

import numpy as np
from shapely.geometry import LineString, Polygon

from .airspace import AirspaceMap, HazardRegion, NoFlyZone
from .deprivation import deprivation_integral
from .energy import (
    InfeasibilityReason,
    evaluate_safe_return,
    nominal_power,
    realized_route_arrival,
    realized_route_state,
    route_state_at,
)
from .environment import AirspaceRestriction, EnvironmentalPacket, WeatherRegion
from .entities import DemandNodeState, DepotInventory, Mode, UAVState
from .events import Event, EventQueue, EventType
from .metrics import EpisodeMetrics
from .objective import ObjectiveParams
from .params import ENERGY_TOL_WH, N_COMMODITIES, STATE_TOL, TIME_TOL_H, EnvParams
from .route_evaluator import evaluate_route
from .scenario import Scenario
from .wind import OnlineWindForecast, WindForecastPacket


_EPS = 1e-9


def _readonly(values) -> np.ndarray:
    array = np.asarray(values, dtype=float).copy()
    array.setflags(write=False)
    return array


@dataclass(frozen=True)
class DemandNodeSnapshot:
    idx: int
    position: np.ndarray
    vulnerability: float
    priority: float
    remaining_demand: np.ndarray


@dataclass(frozen=True)
class UAVSnapshot:
    idx: int
    position: np.ndarray
    battery: float
    payload: np.ndarray
    mode: Mode
    current_node: Optional[int]
    destination: Optional[int]
    active_route: Optional[np.ndarray]
    committed_route: Optional[np.ndarray] = None
    committed_destination: Optional[int] = None


@dataclass(frozen=True)
class AirspaceRegionSnapshot:
    id: str
    region_type: str
    polygon: Tuple[Tuple[float, float], ...]
    severity: Optional[float]
    hard: bool


@dataclass(frozen=True)
class EnvironmentSnapshot:
    time_h: float
    nodes: Tuple[DemandNodeSnapshot, ...]
    uavs: Tuple[UAVSnapshot, ...]
    inventory: np.ndarray
    airspace_version: int
    airspace_regions: Tuple[AirspaceRegionSnapshot, ...]
    wind_forecast: Optional[WindForecastPacket]
    environment_packet: Optional[EnvironmentalPacket]
    event_type: Optional[EventType]
    terminated: bool


@dataclass(frozen=True)
class DecisionEpoch(EnvironmentSnapshot):
    """Snapshot returned after exactly one queued event is applied."""


class RoutingSimulator:
    """Execute validated commands without embedding a routing method."""

    def __init__(self) -> None:
        self.scenario: Optional[Scenario] = None
        self.params: Optional[EnvParams] = None
        self.time_h = 0.0
        self.nodes: list[DemandNodeState] = []
        self.uavs: list[UAVState] = []
        self.inventory: Optional[DepotInventory] = None
        self.airspace = AirspaceMap()
        self.wind_forecast = OnlineWindForecast()
        self.environment_packet: Optional[EnvironmentalPacket] = None
        self._uses_authoritative_packets = False
        self.queue = EventQueue()
        self.metrics = EpisodeMetrics()
        self.terminated = False
        self._reserved_delivery = np.zeros((0, N_COMMODITIES), dtype=float)
        self._last_event_type: Optional[EventType] = None
        self._diagnostic_epoch_open = False
        self._initial_inventory = np.zeros(N_COMMODITIES, dtype=float)
        self._initial_batteries = np.zeros(0, dtype=float)
        self._encountered_packet_ids: list[str] = []
        self._previous_environment_packet: Optional[EnvironmentalPacket] = None

    @property
    def t(self) -> float:
        return self.time_h

    @staticmethod
    def _scenario_uses_authoritative_packets(scenario: Scenario) -> bool:
        generation_schema = str(scenario.generation_metadata.get("schema", ""))
        return (
            "truth_keyframes" not in scenario.wind_spec
            and generation_schema != "information-aware-routing-v2"
        )

    @staticmethod
    def _wind_packet(packet: EnvironmentalPacket) -> WindForecastPacket:
        return WindForecastPacket(
            issued_at_h=packet.issued_at_h,
            horizon_h=packet.valid_until_h - packet.issued_at_h,
            points=tuple(packet.wind),
        )

    def reset(
        self,
        scenario: Scenario,
        objective_params: Optional[ObjectiveParams] = None,
    ) -> EnvironmentSnapshot:
        """Reset to a replayable scenario and reveal only time-zero information."""
        self.scenario = scenario
        self.params = scenario.env_params()
        self.time_h = 0.0
        self.nodes = [DemandNodeState(
            idx=node.idx,
            position=np.array([node.x, node.y], dtype=float),
            vulnerability=node.vulnerability,
            initial_demand=np.asarray(node.demand, dtype=float),
            remaining_demand=np.asarray(node.demand, dtype=float),
            priority=node.priority,
        ) for node in scenario.nodes]
        self.uavs = [UAVState(
            idx=index,
            position=np.asarray(scenario.depot, dtype=float),
            battery=float(scenario.fleet[index].battery_capacity_wh),
            battery_capacity_wh=float(scenario.fleet[index].battery_capacity_wh),
        ) for index in range(len(scenario.fleet))]
        self.inventory = DepotInventory(
            quantities=np.asarray(scenario.initial_inventory, dtype=float),
            bay_available_h=np.zeros(self.params.mission.n_depot_bays, dtype=float),
        )
        self.airspace = AirspaceMap()
        self.wind_forecast = OnlineWindForecast()
        self.environment_packet = None
        self._uses_authoritative_packets = self._scenario_uses_authoritative_packets(
            scenario
        )
        self.queue = EventQueue()
        self.metrics = EpisodeMetrics(
            initial_demand_units=np.sum(
                [node.initial_demand for node in self.nodes], axis=0
            ),
            priorities=np.asarray(
                [node.priority for node in self.nodes], dtype=float
            ),
            initial_demand_per_node=np.asarray(
                [node.initial_demand for node in self.nodes], dtype=float
            ),
            horizon_h=float(self.params.mission.T),
            objective_params=objective_params or ObjectiveParams(),
        )
        self._initial_inventory = np.asarray(
            scenario.initial_inventory, dtype=float
        ).copy()
        self._initial_batteries = np.asarray(
            [uav.battery for uav in self.uavs], dtype=float
        )
        self.terminated = False
        self._reserved_delivery = np.zeros(
            (len(self.nodes), N_COMMODITIES), dtype=float
        )
        self._last_event_type = None
        self._diagnostic_epoch_open = False
        self._encountered_packet_ids = []
        self._previous_environment_packet = None

        if self._uses_authoritative_packets:
            for packet in scenario.environment_packet_timeline():
                self.queue.push(Event(
                    packet.issued_at_h,
                    EventType.ENVIRONMENT_PACKET_UPDATE,
                    {"packet": packet},
                ))
        else:
            for update in scenario.airspace_timeline():
                self.queue.push(Event(
                    update.time_h,
                    EventType.AIRSPACE_UPDATE,
                    {"update": update},
                ))
            for packet in scenario.wind_forecast_timeline():
                self.queue.push(Event(
                    packet.issued_at_h,
                    EventType.WIND_FORECAST_UPDATE,
                    {"packet": packet},
                ))
        self.queue.push(Event(self.params.mission.T, EventType.HORIZON))

        while self.queue.peek_time() is not None and self.queue.peek_time() <= _EPS:
            event = self.queue.pop()
            assert event is not None
            if event.event_type is EventType.ENVIRONMENT_PACKET_UPDATE:
                self._apply_event(event)
            elif event.event_type is EventType.AIRSPACE_UPDATE:
                self.airspace.apply_update(event.payload["update"])
            elif event.event_type is EventType.WIND_FORECAST_UPDATE:
                self.wind_forecast.receive(event.payload["packet"], now_h=0.0)
            elif event.event_type is EventType.HORIZON:
                self.terminated = True
                self.metrics.termination_reason = "horizon"
        return self.snapshot()

    @property
    def event_log(self):
        """Structured runtime events; never part of the scenario state."""
        return self.metrics.event_log

    @property
    def flight_log(self):
        return self.metrics.flight_log

    @property
    def encountered_packet_ids(self) -> tuple[str, ...]:
        return tuple(self._encountered_packet_ids)

    def diagnose_packet_update(
        self,
        incumbent_plan: Mapping[Any, Mapping[str, Any]],
        deadlines_h: Optional[Mapping[Any, float]] = None,
    ):
        """Diagnose the latest packet update without changing simulator state."""
        if self.scenario is None or self.params is None:
            raise RuntimeError("simulator must be reset before use")
        if (
            self._last_event_type is not EventType.ENVIRONMENT_PACKET_UPDATE
            or not self._diagnostic_epoch_open
        ):
            raise ValueError(
                "diagnostics require a decision epoch created by an environment packet update"
            )
        if self._previous_environment_packet is None or self.environment_packet is None:
            raise ValueError("the packet update has no preceding visible packet")
        from .diagnostics import diagnose_environmental_packet_update

        return diagnose_environmental_packet_update(
            self.scenario,
            incumbent_plan,
            self.snapshot(),
            self._previous_environment_packet,
            self.environment_packet,
            deadlines_h=deadlines_h,
        )

    def _invalidate_diagnostic_epoch(self) -> None:
        """Close the packet-update diagnostic window after a controller command."""
        self._diagnostic_epoch_open = False

    def _require_ready(self) -> None:
        if self.scenario is None or self.params is None or self.inventory is None:
            raise RuntimeError("simulator must be reset before use")
        if self.terminated or self.time_h >= self.params.mission.T - _EPS:
            raise ValueError("mission has terminated")

    def _uav(self, uav_id: int) -> UAVState:
        if isinstance(uav_id, bool) or not isinstance(uav_id, (int, np.integer)):
            raise ValueError("uav_id must be an integer")
        if not 0 <= int(uav_id) < len(self.uavs):
            raise ValueError("unknown uav_id")
        return self.uavs[int(uav_id)]

    def consume_battery(self, uav_id: int, energy_wh: float) -> None:
        """Atomically consume battery energy without permitting negative state."""
        self._invalidate_diagnostic_epoch()
        uav = self._uav(uav_id)
        amount = float(energy_wh)
        if not np.isfinite(amount) or amount < 0.0:
            raise ValueError("energy_wh must be finite and nonnegative")
        if amount > uav.battery:
            raise ValueError(
                f"{InfeasibilityReason.INSUFFICIENT_BATTERY.value}: "
                "requested energy exceeds current battery"
            )
        new_battery = uav.battery - amount
        if new_battery < 0.0:
            raise ValueError(
                f"{InfeasibilityReason.INSUFFICIENT_BATTERY.value}: "
                "battery would become negative"
            )
        if (
            uav.battery_capacity_wh is not None
            and new_battery > uav.battery_capacity_wh + ENERGY_TOL_WH
        ):
            raise ValueError("battery cannot exceed capacity")
        uav.battery = float(new_battery)

    @staticmethod
    def _quantities(values: Sequence[float]) -> np.ndarray:
        try:
            vector = np.asarray(values, dtype=float).copy()
        except (TypeError, ValueError) as error:
            raise ValueError(
                f"{InfeasibilityReason.INVALID_COMMODITY_LOAD.value}: "
                "quantities must be numeric"
            ) from error
        if vector.shape != (N_COMMODITIES,):
            raise ValueError(
                f"{InfeasibilityReason.INVALID_COMMODITY_LOAD.value}: "
                f"quantities must contain {N_COMMODITIES} values"
            )
        if not np.all(np.isfinite(vector)) or np.any(vector < 0.0):
            raise ValueError(
                f"{InfeasibilityReason.INVALID_COMMODITY_LOAD.value}: "
                "quantities must be finite and nonnegative"
            )
        return vector

    def prepare(self, uav_id: int, quantities: Sequence[float]) -> None:
        """Reserve inventory and queue loading plus full charging at a depot bay."""
        self._require_ready()
        self._invalidate_diagnostic_epoch()
        assert self.params is not None and self.inventory is not None
        assert self.scenario is not None
        uav = self._uav(uav_id)
        uav_parameters = self.scenario.fleet[uav.idx]
        requested = self._quantities(quantities)
        if uav.mode is not Mode.DEPOT:
            raise ValueError("UAV must be at the depot to prepare")
        unit_masses = np.asarray(self.params.commodities.w_k, dtype=float)
        resulting_mass = float(np.dot(unit_masses, uav.payload + requested))
        if resulting_mass > uav_parameters.max_payload_kg + _EPS:
            raise ValueError(
                f"{InfeasibilityReason.PAYLOAD_CAPACITY_EXCEEDED.value}: "
                "requested load exceeds payload capacity"
            )
        if not self.inventory.can_reserve(requested):
            raise ValueError(
                f"{InfeasibilityReason.INSUFFICIENT_DEPOT_INVENTORY.value}: "
                "requested quantities exceed available inventory"
            )

        charge_duration = self.params.mission.charge_time_h * max(
            uav_parameters.battery_capacity_wh - uav.battery, 0.0
        ) / uav_parameters.battery_capacity_wh
        duration = self.params.mission.load_time_h + charge_duration
        bay = int(np.argmin(self.inventory.bay_available_h))
        start = max(self.time_h, float(self.inventory.bay_available_h[bay]))
        finish = start + duration
        if finish > self.params.mission.T + TIME_TOL_H:
            raise ValueError(
                f"{InfeasibilityReason.MISSION_HORIZON_EXCEEDED.value}: "
                "load completion exceeds mission horizon"
            )
        event_id = self.queue.push(Event(
            finish, EventType.LOAD_COMPLETE, {"uav_id": uav.idx}
        ))
        del event_id
        self.inventory.reserve(requested)
        self.inventory.bay_available_h[bay] = finish
        uav.pending_load = requested
        uav.mode = Mode.PREPARING

    def dispatch(
        self,
        uav_id: int,
        destination: int,
        waypoints_xy: Sequence[Sequence[float]],
    ) -> None:
        """Dispatch exactly the supplied route if current information certifies it."""
        self._require_ready()
        self._invalidate_diagnostic_epoch()
        assert self.params is not None and self.scenario is not None
        uav = self._uav(uav_id)
        if uav.mode not in {Mode.READY, Mode.AT_NODE, Mode.AWAITING_ROUTE}:
            raise ValueError("UAV is not ready for dispatch")
        if isinstance(destination, bool) or not isinstance(
            destination, (int, np.integer)
        ):
            raise ValueError("destination must be an integer")
        destination = int(destination)
        if destination != -1 and not 0 <= destination < len(self.nodes):
            raise ValueError("destination is not a valid node or depot")
        points = np.asarray(waypoints_xy, dtype=float).copy()
        if points.ndim != 2 or points.shape[1:] != (2,) or len(points) < 2:
            raise ValueError("route must contain at least two two-dimensional points")
        if not np.allclose(points[0], uav.position, atol=1e-8, rtol=0.0):
            raise ValueError("route must start at the UAV current position")
        expected_end = (
            np.asarray(self.scenario.depot, dtype=float)
            if destination == -1
            else self.nodes[destination].position
        )
        if not np.allclose(points[-1], expected_end, atol=1e-8, rtol=0.0):
            raise ValueError("route must end at the declared destination")
        payload_mass = uav.payload_mass(
            np.asarray(self.params.commodities.w_k, dtype=float)
        )
        evaluation = evaluate_route(
            points,
            self.time_h,
            payload_mass,
            uav.battery,
            self.airspace,
            self.wind_forecast,
            self.params,
            environmental_packet=(
                self.environment_packet
                if self._uses_authoritative_packets
                else None
            ),
            uav_parameters=(
                self.scenario.fleet[uav.idx]
                if self._uses_authoritative_packets
                else None
            ),
        )
        if not evaluation.feasible:
            self._record_rejected_flight(uav, destination, points, evaluation)
        if evaluation.hard_blocked:
            raise ValueError(
                f"{InfeasibilityReason.AIRSPACE_BLOCK.value}: "
                "supplied route intersects hard airspace"
            )
        if not evaluation.forecast_covered:
            raise ValueError(
                f"{InfeasibilityReason.INVALID_ENVIRONMENTAL_COVERAGE.value}: "
                "supplied route lacks complete wind forecast coverage"
            )
        if evaluation.battery_feasible is not True:
            raise ValueError(
                f"{InfeasibilityReason.INSUFFICIENT_BATTERY.value}: "
                "supplied route is not battery feasible"
            )
        if not evaluation.feasible:
            reason = evaluation.failure_reason or "ROUTE_INFEASIBLE"
            raise ValueError(f"{reason}: supplied route is not feasible")
        if self._uses_authoritative_packets:
            assert evaluation.duration_h is not None
            arrival = self.time_h + evaluation.duration_h
        else:
            # Legacy scenarios retain their explicit truth adapter.
            arrival, _ = realized_route_arrival(
                points,
                self.time_h,
                payload_mass,
                self.scenario.wind_spec,
                self.params.physics,
            )
        if arrival > self.params.mission.T + TIME_TOL_H:
            raise ValueError(
                f"{InfeasibilityReason.MISSION_HORIZON_EXCEEDED.value}: "
                "supplied route arrival exceeds mission horizon"
            )
        event_id = self.queue.push(Event(
            arrival,
            EventType.WAYPOINT_REACHED,
            {"uav_id": uav.idx},
        ))
        uav.active_route = points
        uav.route_departure_h = self.time_h
        uav.route_arrival_h = arrival
        uav.waypoint_event_id = event_id
        uav.destination = destination
        uav.current_node = None
        uav.pending_route = None
        uav.pending_destination = None
        uav.pending_packet_id = None
        uav.mode = Mode.FLYING

    def resume_current_leg(self, uav_id: int) -> None:
        """Resume the exact committed remainder after a packet transition."""
        self._require_ready()
        self._invalidate_diagnostic_epoch()
        uav = self._uav(uav_id)
        if uav.mode is not Mode.AWAITING_ROUTE or uav.pending_route is None:
            raise ValueError(
                f"{InfeasibilityReason.INVALID_EDGE.value}: "
                "UAV has no committed route remainder to resume"
            )
        if uav.pending_destination is None or len(uav.pending_route) < 2:
            raise ValueError(
                f"{InfeasibilityReason.INVALID_EDGE.value}: "
                "committed route remainder is incomplete"
            )
        remainder = uav.pending_route.copy()
        destination = int(uav.pending_destination)
        # dispatch validates the remainder under the currently visible packet;
        # retain it if that validation fails so the caller can choose later.
        self.dispatch(uav_id, destination, remainder)
        uav.pending_route = None
        uav.pending_destination = None
        uav.pending_packet_id = None

    def execute_fixed_plan(self, plan):
        """Execute a fixed plan from this simulator's current reset state."""
        from .fixed_plan import execute_fixed_plan_on_simulator

        return execute_fixed_plan_on_simulator(self, plan)

    def _current_packet(self) -> Optional[EnvironmentalPacket]:
        """Return only the packet currently visible to the runtime."""
        if self._uses_authoritative_packets:
            return self.environment_packet
        latest = self.wind_forecast.latest_packet
        if latest is None:
            return None
        return EnvironmentalPacket(
            packet_id=f"legacy-runtime-{latest.issued_at_h:g}",
            issued_at_h=float(latest.issued_at_h),
            valid_from_h=float(latest.valid_from_h),
            valid_until_h=float(latest.valid_until_h),
            wind=tuple(latest.points),
            weather=tuple(
                WeatherRegion(
                    id=region.id,
                    geometry=tuple(tuple(float(value) for value in point)
                                   for point in region.polygon),
                    severity="HARD" if region.is_hard else "SOFT",
                    valid_from_h=max(
                        float(latest.valid_from_h), float(region.active_from)
                    ),
                    valid_until_h=(
                        float(latest.valid_until_h)
                        if region.active_until is None
                        else min(float(latest.valid_until_h), float(region.active_until))
                    ),
                    safety_buffer_m=float(region.safety_buffer_m),
                )
                for region in self.airspace.active_regions(latest.issued_at_h)
                if isinstance(region, HazardRegion)
                and max(float(latest.valid_from_h), float(region.active_from))
                < (
                    float(latest.valid_until_h)
                    if region.active_until is None
                    else min(float(latest.valid_until_h), float(region.active_until))
                )
            ),
            airspace=tuple(
                AirspaceRestriction(
                    id=region.id,
                    geometry=tuple(tuple(float(value) for value in point)
                                   for point in region.polygon),
                    valid_from_h=max(
                        float(latest.valid_from_h), float(region.active_from)
                    ),
                    valid_until_h=(
                        float(latest.valid_until_h)
                        if region.active_until is None
                        else min(float(latest.valid_until_h), float(region.active_until))
                    ),
                    safety_buffer_m=float(region.safety_buffer_m),
                )
                for region in self.airspace.active_regions(latest.issued_at_h)
                if isinstance(region, NoFlyZone)
                and max(float(latest.valid_from_h), float(region.active_from))
                < (
                    float(latest.valid_until_h)
                    if region.active_until is None
                    else min(float(latest.valid_until_h), float(region.active_until))
                )
            ),
        )

    def deliver(self, uav_id: int, quantities: Sequence[float]) -> None:
        """Queue a delivery chosen explicitly by the caller."""
        self._require_ready()
        self._invalidate_diagnostic_epoch()
        assert self.params is not None and self.scenario is not None
        uav = self._uav(uav_id)
        uav_parameters = self.scenario.fleet[uav.idx]
        requested = self._quantities(quantities)
        if uav.mode is not Mode.AT_NODE or uav.current_node is None:
            raise ValueError("UAV must be at a demand node to deliver")
        if np.sum(requested) <= _EPS:
            raise ValueError(
                f"{InfeasibilityReason.INVALID_COMMODITY_LOAD.value}: "
                "delivery quantities must contain a positive amount"
            )
        if np.any(requested > uav.payload + _EPS):
            raise ValueError(
                f"{InfeasibilityReason.INVALID_COMMODITY_LOAD.value}: "
                "delivery exceeds onboard payload"
            )
        node_id = uav.current_node
        available = self.nodes[node_id].remaining_demand - self._reserved_delivery[node_id]
        if np.any(requested > available + _EPS):
            raise ValueError(
                f"{InfeasibilityReason.INVALID_COMMODITY_LOAD.value}: "
                "delivery exceeds residual demand"
            )
        finish = self.time_h + self.params.mission.service_time_h
        if finish > self.params.mission.T + TIME_TOL_H:
            raise ValueError(
                f"{InfeasibilityReason.MISSION_HORIZON_EXCEEDED.value}: "
                "service completion exceeds mission horizon"
            )
        payload_after = uav.payload - requested
        packet = self._current_packet()
        safe_return = None
        if packet is not None:
            safe_return = evaluate_safe_return(
                uav.position,
                self.scenario.depot,
                finish,
                float(np.dot(
                    np.asarray(self.params.commodities.w_k, dtype=float),
                    payload_after,
                )),
                uav.battery,
                uav_parameters,
                packet,
                service_energy_wh=uav_parameters.service_energy_wh,
            )
            if not safe_return.feasible:
                code = (
                    safe_return.reason_code.value
                    if safe_return.reason_code is not None
                    else str(safe_return.reason or "SAFE_RETURN_INFEASIBLE")
                )
                raise ValueError(f"{code}: service would violate return feasibility")
            assert safe_return.leg_evaluation.arrival_time_h is not None
            if safe_return.leg_evaluation.arrival_time_h > self.params.mission.T + TIME_TOL_H:
                raise ValueError(
                    f"{InfeasibilityReason.MISSION_HORIZON_EXCEEDED.value}: "
                    "safe return exceeds mission horizon"
                )
        elif uav.battery < (
            uav_parameters.service_energy_wh
            + uav_parameters.reserve_requirement_wh
        ):
            raise ValueError(
                f"{InfeasibilityReason.SAFE_RETURN_RESERVE_VIOLATION.value}: "
                "insufficient battery for service and reserve"
            )
        self.queue.push(Event(
            finish,
            EventType.SERVICE_COMPLETE,
            {"uav_id": uav.idx, "node_id": node_id},
        ))
        self._reserved_delivery[node_id] += requested
        uav.pending_delivery = requested
        uav.mode = Mode.SERVICING

    def _accrue_deprivation(self, end_time_h: float) -> None:
        assert self.params is not None
        duration = float(end_time_h) - self.time_h
        if duration <= 0.0:
            return
        _, lambda_k, alpha_k, kappa_k = self.params.commodities.as_arrays()
        for node in self.nodes:
            value = deprivation_integral(
                node.vulnerability,
                node.remaining_demand,
                self.time_h,
                duration,
                lambda_k,
                alpha_k,
                kappa_k,
            )
            self.metrics.add_deprivation(node.idx, value)

    @staticmethod
    def _route_at_distance(route: np.ndarray, distance_km: float):
        lengths = np.linalg.norm(np.diff(route, axis=0), axis=1)
        total = float(np.sum(lengths))
        target = float(np.clip(distance_km, 0.0, total))
        prefix = [route[0].copy()]
        traversed = 0.0
        for index, length in enumerate(lengths):
            length = float(length)
            if target >= traversed + length - _EPS:
                prefix.append(route[index + 1].copy())
                traversed += length
                continue
            fraction = (target - traversed) / max(length, _EPS)
            position = route[index] + fraction * (route[index + 1] - route[index])
            if np.linalg.norm(position - prefix[-1]) > _EPS:
                prefix.append(position.copy())
            remaining = [position.copy(), *[
                point.copy() for point in route[index + 1:]
            ]]
            return np.asarray(prefix), np.asarray(remaining), position
        return np.asarray(prefix), np.asarray([route[-1].copy()]), route[-1].copy()

    def _location_label(self, position: Sequence[float]) -> str:
        assert self.scenario is not None
        point = np.asarray(position, dtype=float)
        if np.allclose(
            point, np.asarray(self.scenario.depot), atol=STATE_TOL, rtol=0.0
        ):
            return "DEPOT"
        for node in self.nodes:
            if np.allclose(point, node.position, atol=STATE_TOL, rtol=0.0):
                return f"NODE-{node.idx:03d}"
        return f"({float(point[0]):.9g},{float(point[1]):.9g})"

    def _record_rejected_flight(
        self,
        uav: UAVState,
        destination: int,
        route: np.ndarray,
        evaluation,
    ) -> None:
        """Record a rejected route command without changing physical state."""
        payload = uav.payload.copy()
        unit_masses = np.asarray(self.params.commodities.w_k, dtype=float)
        payload_mass = float(np.dot(unit_masses, payload))
        leg = (
            evaluation.leg_evaluations[-1]
            if getattr(evaluation, "leg_evaluations", ())
            else None
        )
        code = (
            evaluation.failure_reason
            if getattr(evaluation, "failure_reason", None) is not None
            else str(getattr(evaluation, "reason", None) or "ROUTE_INFEASIBLE")
        )
        self.metrics.record_flight({
            "uav": int(uav.idx),
            "origin": self._location_label(route[0]),
            "destination": (
                "DEPOT" if destination == -1
                else f"NODE-{int(destination):03d}"
            ),
            "departure_time_h": float(self.time_h),
            "arrival_time_h": None,
            "payload_before": payload.tolist(),
            "payload_after": payload.tolist(),
            "payload_before_mass_kg": payload_mass,
            "payload_after_mass_kg": payload_mass,
            "battery_before": float(uav.battery),
            "battery_after": float(uav.battery),
            "packet_id": getattr(leg, "packet_id", None),
            "energy_wh": 0.0,
            "distance_km": 0.0,
            "edge_geometry": route.tolist(),
            "travel_time_h": None,
            "ground_speed_kmh": None,
            "wind_vector_kmh": getattr(leg, "wind_vector_kmh", None),
            "along_track_wind_kmh": getattr(
                leg, "along_track_wind_kmh", None
            ),
            "cross_track_wind_kmh": getattr(
                leg, "cross_track_wind_kmh", None
            ),
            "airspeed_kmh": getattr(leg, "airspeed_kmh", None),
            "power_w": getattr(leg, "power_w", None),
            "weather_state": getattr(leg, "weather_state", "CLEAR"),
            "airspace_state": getattr(leg, "airspace_state", "CLEAR"),
            "feasible": False,
            "reason": code,
        })

    @staticmethod
    def _packet_region_state(
        route: np.ndarray,
        packet: Optional[EnvironmentalPacket],
        time_h: float,
    ) -> tuple[str, str]:
        if packet is None:
            return "CLEAR", "CLEAR"
        line = LineString(route)
        weather_state = "CLEAR"
        for region in packet.weather:
            geometry = Polygon(region.geometry)
            buffer_km = float(region.safety_buffer_m) / 1000.0
            if buffer_km > 0.0:
                geometry = geometry.buffer(buffer_km)
            if region.active_at(time_h) and line.intersects(geometry):
                weather_state = "BLOCKED" if region.is_hard else "SOFT"
                if region.is_hard:
                    break
        airspace_state = "CLEAR"
        for region in packet.airspace:
            geometry = Polygon(region.geometry)
            buffer_km = float(region.safety_buffer_m) / 1000.0
            if buffer_km > 0.0:
                geometry = geometry.buffer(buffer_km)
            if region.active_at(time_h) and line.intersects(geometry):
                airspace_state = "BLOCKED"
                break
        return weather_state, airspace_state

    def _settle_flight(self, uav: UAVState, at_time_h: float, *, interrupt: bool):
        assert self.params is not None and self.scenario is not None
        assert uav.active_route is not None
        route = uav.active_route.copy()
        destination = uav.destination
        payload_before = uav.payload.copy()
        battery_before = float(uav.battery)
        payload_mass = uav.payload_mass(
            np.asarray(self.params.commodities.w_k, dtype=float)
        )
        if self._uses_authoritative_packets:
            if self.environment_packet is None:
                raise RuntimeError("authoritative packet state is unavailable")
            position, distance, energy, _ = route_state_at(
                uav.active_route,
                uav.route_departure_h,
                float(at_time_h),
                payload_mass,
                self.scenario.fleet[uav.idx],
                self.environment_packet,
            )
        else:
            position, distance, energy = realized_route_state(
                uav.active_route,
                uav.route_departure_h,
                float(at_time_h),
                payload_mass,
                self.scenario.wind_spec,
                self.params.physics,
            )
        _, remaining, _ = self._route_at_distance(uav.active_route, distance)
        reserve = (
            self.scenario.fleet[uav.idx].reserve_requirement_wh
            if self._uses_authoritative_packets
            else self.params.physics.beta_safe
        )
        if battery_before - energy < reserve - ENERGY_TOL_WH:
            raise ValueError(
                f"{InfeasibilityReason.SAFE_RETURN_RESERVE_VIOLATION.value}: "
                "flight would consume the fixed reserve"
            )
        self.consume_battery(uav.idx, energy)
        self.metrics.energy_consumed_wh += energy
        uav.position = position.copy()
        packet = self._current_packet()
        segment_records = []
        if self._uses_authoritative_packets and packet is not None:
            try:
                route_evaluation = evaluate_route(
                    route,
                    uav.route_departure_h,
                    payload_mass,
                    battery_before,
                    None,
                    None,
                    self.params,
                    environmental_packet=packet,
                    uav_parameters=self.scenario.fleet[uav.idx],
                )
                for leg_evaluation in route_evaluation.leg_evaluations:
                    segment_records.extend(
                        leg_evaluation.diagnostics.get("segments", ())
                    )
            except (TypeError, ValueError):
                segment_records = []
        travel_time = max(float(at_time_h) - float(uav.route_departure_h), 0.0)
        if segment_records:
            segment_duration = float(sum(
                float(segment.get("duration_h", 0.0))
                for segment in segment_records
            ))
            denominator = segment_duration if segment_duration > TIME_TOL_H else travel_time
            along_wind = float(sum(
                float(segment.get("along_track_wind_kmh", 0.0))
                * float(segment.get("duration_h", 0.0))
                for segment in segment_records
            ) / denominator) if denominator > TIME_TOL_H else 0.0
            cross_wind = float(sum(
                float(segment.get("cross_track_wind_kmh", 0.0))
                * float(segment.get("duration_h", 0.0))
                for segment in segment_records
            ) / denominator) if denominator > TIME_TOL_H else 0.0
            wind_vector = [
                float(sum(
                    float(segment.get("wind_vector_kmh", (0.0, 0.0))[axis])
                    * float(segment.get("duration_h", 0.0))
                    for segment in segment_records
                ) / denominator) if denominator > TIME_TOL_H else 0.0
                for axis in range(2)
            ]
        else:
            along_wind = 0.0
            cross_wind = 0.0
            wind_vector = [0.0, 0.0]
        vehicle = self.scenario.fleet[uav.idx]
        weather_state, airspace_state = self._packet_region_state(
            route,
            packet,
            0.5 * (float(uav.route_departure_h) + float(at_time_h)),
        )
        self.metrics.record_flight({
            "uav": int(uav.idx),
            "origin": self._location_label(route[0]),
            "destination": (
                "DEPOT" if uav.destination == -1
                else f"NODE-{int(uav.destination):03d}"
            ),
            "departure_time_h": float(uav.route_departure_h),
            "arrival_time_h": float(at_time_h),
            "payload_before": payload_before.tolist(),
            "payload_after": uav.payload.tolist(),
            "payload_before_mass_kg": float(payload_mass),
            "payload_after_mass_kg": float(
                uav.payload_mass(np.asarray(self.params.commodities.w_k, dtype=float))
            ),
            "battery_before": battery_before,
            "battery_after": float(uav.battery),
            "packet_id": (
                packet.packet_id if packet is not None else None
            ),
            "energy_wh": float(energy),
            "distance_km": float(distance),
            "edge_geometry": route.tolist(),
            "travel_time_h": float(travel_time),
            "ground_speed_kmh": (
                float(distance / travel_time)
                if travel_time > TIME_TOL_H else None
            ),
            "wind_vector_kmh": wind_vector,
            "along_track_wind_kmh": along_wind,
            "cross_track_wind_kmh": cross_wind,
            "airspeed_kmh": float(vehicle.nominal_airspeed_kmh),
            "power_w": float(nominal_power(payload_mass, vehicle)),
            "weather_state": weather_state,
            "airspace_state": airspace_state,
            "feasible": True,
            "reason": None,
        })
        if interrupt:
            if uav.waypoint_event_id is not None:
                self.queue.cancel(uav.waypoint_event_id)
            uav.pending_route = remaining.copy() if len(remaining) >= 2 else None
            uav.pending_destination = uav.destination if len(remaining) >= 2 else None
            uav.pending_packet_id = (
                self.environment_packet.packet_id
                if self.environment_packet is not None else None
            )
            uav.active_route = None
            uav.waypoint_event_id = None
            if len(remaining) >= 2:
                uav.destination = None
                uav.current_node = None
                uav.mode = Mode.AWAITING_ROUTE
            elif destination == -1:
                uav.destination = None
                uav.current_node = None
                uav.mode = Mode.DEPOT
            else:
                uav.destination = None
                uav.current_node = int(destination)
                uav.mode = Mode.AT_NODE
        else:
            uav.pending_route = None
            uav.pending_destination = None
            uav.pending_packet_id = None
        return remaining

    def _interrupt_flights(self, *, check_hard: bool = False) -> None:
        assert self.params is not None
        for uav in self.uavs:
            if uav.mode is not Mode.FLYING:
                continue
            remaining = self._settle_flight(uav, self.time_h, interrupt=True)
            if check_hard and len(remaining) >= 2 and self.airspace.hard_intersects(
                remaining,
                self.time_h,
                extra_margin_km=(
                    self.params.route_validation.safe_corridor_margin_m / 1000.0
                ),
            ):
                self.metrics.hard_route_violations += 1

    def _apply_event(self, event: Event) -> None:
        assert self.params is not None
        if event.event_type is EventType.ENVIRONMENT_PACKET_UPDATE:
            packet = event.payload["packet"]
            if not isinstance(packet, EnvironmentalPacket):
                packet = EnvironmentalPacket.from_dict(packet)
            if self._uses_authoritative_packets:
                previous_packet = self.environment_packet
                self._interrupt_flights()
                self._previous_environment_packet = previous_packet
                self.environment_packet = packet
                if packet.packet_id not in self._encountered_packet_ids:
                    self._encountered_packet_ids.append(packet.packet_id)
                self.wind_forecast.receive(
                    self._wind_packet(packet),
                    now_h=self.time_h,
                )
        elif event.event_type is EventType.AIRSPACE_UPDATE:
            self.airspace.apply_update(event.payload["update"])
            self._interrupt_flights(check_hard=True)
        elif event.event_type is EventType.WIND_FORECAST_UPDATE:
            self.wind_forecast.receive(event.payload["packet"], now_h=self.time_h)
            self._interrupt_flights()
        elif event.event_type is EventType.LOAD_COMPLETE:
            uav = self._uav(event.payload["uav_id"])
            if uav.mode is Mode.PREPARING:
                assert self.scenario is not None
                pending = uav.pending_load.copy()
                resulting_payload = uav.payload + pending
                if np.any(resulting_payload < -STATE_TOL):
                    raise ValueError(
                        f"{InfeasibilityReason.INVALID_COMMODITY_LOAD.value}: "
                        "load completion would make payload negative"
                    )
                battery_before = float(uav.battery)
                uav.payload += uav.pending_load
                uav.pending_load = np.zeros(N_COMMODITIES, dtype=float)
                capacity = self.scenario.fleet[uav.idx].battery_capacity_wh
                uav.battery = float(capacity)
                charged = float(capacity - battery_before)
                if charged > 0.0:
                    self.metrics.charged_battery_wh[uav.idx] = (
                        self.metrics.charged_battery_wh.get(uav.idx, 0.0)
                        + charged
                    )
                uav.mode = Mode.READY
        elif event.event_type is EventType.WAYPOINT_REACHED:
            uav = self._uav(event.payload["uav_id"])
            if uav.mode is Mode.FLYING and uav.active_route is not None:
                destination = uav.destination
                self._settle_flight(uav, self.time_h, interrupt=False)
                uav.active_route = None
                uav.waypoint_event_id = None
                uav.destination = None
                if destination == -1:
                    uav.mode = Mode.DEPOT
                    uav.current_node = None
                else:
                    uav.mode = Mode.AT_NODE
                    uav.current_node = int(destination)
        elif event.event_type is EventType.SERVICE_COMPLETE:
            uav = self._uav(event.payload["uav_id"])
            node_id = int(event.payload["node_id"])
            if uav.mode is Mode.SERVICING:
                delivered = uav.pending_delivery.copy()
                uav_service_energy = self.scenario.fleet[
                    uav.idx
                ].service_energy_wh if self._uses_authoritative_packets else self.params.physics.e_v
                node = self.nodes[node_id]
                remaining_demand = node.remaining_demand - delivered
                reserved_delivery = self._reserved_delivery[node_id] - delivered
                remaining_payload = uav.payload - delivered
                if any(np.any(values < -STATE_TOL) for values in (
                    remaining_demand, reserved_delivery, remaining_payload
                )):
                    raise ValueError(
                        f"{InfeasibilityReason.INVALID_COMMODITY_LOAD.value}: "
                        "service completion would make a state negative"
                    )
                for values in (remaining_demand, reserved_delivery, remaining_payload):
                    values[values < 0.0] = 0.0
                battery_before = float(uav.battery)
                self.consume_battery(uav.idx, uav_service_energy)
                node.remaining_demand = remaining_demand
                self._reserved_delivery[node_id] = reserved_delivery
                uav.payload = remaining_payload
                uav.pending_delivery = np.zeros(N_COMMODITIES, dtype=float)
                self.metrics.energy_consumed_wh += uav_service_energy
                self.metrics.per_uav_energy_wh[uav.idx] = (
                    self.metrics.per_uav_energy_wh.get(uav.idx, 0.0)
                    + float(uav_service_energy)
                )
                self.metrics.delivered_units += delivered
                self.metrics.completed_services += 1
                self.metrics.record_delivery(node_id, delivered, self.time_h)
                self.metrics.record_delivery_event({
                    "uav": int(uav.idx),
                    "node_id": int(node_id),
                    "time_h": float(self.time_h),
                    "quantities": delivered.tolist(),
                    "residual_demand": node.remaining_demand.tolist(),
                    "payload_before": (uav.payload + delivered).tolist(),
                    "payload_after": uav.payload.tolist(),
                    "battery_before": battery_before,
                    "battery_after": float(uav.battery),
                    "service_energy_wh": float(uav_service_energy),
                    "packet_id": (
                        self.environment_packet.packet_id
                        if self.environment_packet is not None else None
                    ),
                    "feasible": True,
                    "reason": None,
                })
                uav.mode = Mode.AT_NODE
        elif event.event_type is EventType.HORIZON:
            self._interrupt_flights()
            self.terminated = True
            self.metrics.termination_reason = "horizon"
        self._diagnostic_epoch_open = (
            event.event_type is EventType.ENVIRONMENT_PACKET_UPDATE
        )

    def conservation_audit(self) -> dict:
        """Audit inventory, demand, battery, payload, and distance balances."""
        if self.scenario is None or self.inventory is None:
            raise RuntimeError("simulator must be reset before use")
        unit_masses = np.asarray(self.params.commodities.w_k, dtype=float)
        current_payload = np.sum(
            [uav.payload for uav in self.uavs], axis=0
        ) if self.uavs else np.zeros(N_COMMODITIES, dtype=float)
        inventory_residual = self._initial_inventory - (
            self.inventory.quantities + current_payload + self.metrics.delivered_units
        )
        current_demand = np.sum(
            [node.remaining_demand for node in self.nodes], axis=0
        ) if self.nodes else np.zeros(N_COMMODITIES, dtype=float)
        demand_residual = self.metrics.initial_demand_units - (
            current_demand + self.metrics.delivered_units
        )
        current_batteries = np.asarray(
            [uav.battery for uav in self.uavs], dtype=float
        )
        charged = np.asarray(
            [self.metrics.charged_battery_wh.get(index, 0.0)
             for index in range(len(self.uavs))],
            dtype=float,
        )
        battery_residual = (
            self._initial_batteries + charged
            - current_batteries
            - np.asarray(
                [self.metrics.per_uav_energy_wh.get(index, 0.0)
                 for index in range(len(self.uavs))],
                dtype=float,
            )
        )
        logged_distance = float(sum(
            float(record.get("distance_km", 0.0))
            for record in self.metrics.flight_log
        ))
        distance_residual = float(self.metrics.distance_travelled_km - logged_distance)
        payload_residual_kg = float(np.dot(unit_masses, inventory_residual))
        within = {
            "inventory": bool(np.all(np.abs(inventory_residual) <= STATE_TOL)),
            "demand": bool(np.all(np.abs(demand_residual) <= STATE_TOL)),
            "battery": bool(np.all(np.abs(battery_residual) <= ENERGY_TOL_WH)),
            "payload_kg": bool(abs(payload_residual_kg) <= ENERGY_TOL_WH),
            "distance_km": bool(abs(distance_residual) <= STATE_TOL),
        }
        return {
            "inventory_residual": inventory_residual.tolist(),
            "demand_residual": demand_residual.tolist(),
            "battery_residual_wh": battery_residual.tolist(),
            "payload_residual_kg": payload_residual_kg,
            "distance_residual_km": distance_residual,
            "within_tolerance": within,
            "all_within_tolerance": bool(all(within.values())),
        }

    def advance(self) -> DecisionEpoch:
        """Apply the next event and return the resulting decision epoch."""
        if self.scenario is None or self.params is None:
            raise RuntimeError("simulator must be reset before use")
        if self.terminated:
            raise ValueError("mission has terminated")
        event = self.queue.pop()
        if event is None:
            raise RuntimeError("event queue is empty")
        if event.time_h < self.time_h - _EPS:
            raise ValueError("event time is earlier than simulator time")
        self._accrue_deprivation(event.time_h)
        self.time_h = event.time_h
        self._apply_event(event)
        self._last_event_type = event.event_type
        return self._snapshot(DecisionEpoch, event.event_type)

    def snapshot(self) -> EnvironmentSnapshot:
        """Return a copy-only controller observation of current information."""
        return self._snapshot(EnvironmentSnapshot, self._last_event_type)

    def _snapshot(self, snapshot_type, event_type):
        if self.scenario is None or self.params is None or self.inventory is None:
            raise RuntimeError("simulator must be reset before use")
        node_values = tuple(DemandNodeSnapshot(
            idx=node.idx,
            position=_readonly(node.position),
            vulnerability=node.vulnerability,
            priority=node.priority,
            remaining_demand=_readonly(node.remaining_demand),
        ) for node in self.nodes)
        uav_values = tuple(UAVSnapshot(
            idx=uav.idx,
            position=_readonly(uav.position),
            battery=float(uav.battery),
            payload=_readonly(uav.payload),
            mode=uav.mode,
            current_node=uav.current_node,
            destination=uav.destination,
            active_route=(
                None if uav.active_route is None else _readonly(uav.active_route)
            ),
            committed_route=(
                _readonly(uav.active_route)
                if uav.active_route is not None
                else None
                if uav.pending_route is None
                else _readonly(uav.pending_route)
            ),
            committed_destination=(
                uav.destination
                if uav.active_route is not None
                else uav.pending_destination
            ),
        ) for uav in self.uavs)
        regions = []
        if self._uses_authoritative_packets and self.environment_packet is not None:
            for region in self.environment_packet.weather:
                if not region.active_at(self.time_h):
                    continue
                regions.append(AirspaceRegionSnapshot(
                    id=region.id,
                    region_type="weather",
                    polygon=tuple(tuple(float(value) for value in point)
                                  for point in region.geometry),
                    severity=1.0 if region.is_hard else 0.5,
                    hard=region.is_hard,
                ))
            for region in self.environment_packet.airspace:
                if not region.active_at(self.time_h):
                    continue
                regions.append(AirspaceRegionSnapshot(
                    id=region.id,
                    region_type="no_fly",
                    polygon=tuple(tuple(float(value) for value in point)
                                  for point in region.geometry),
                    severity=None,
                    hard=True,
                ))
        else:
            for region in self.airspace.active_regions(self.time_h):
                is_hazard = isinstance(region, HazardRegion)
                regions.append(AirspaceRegionSnapshot(
                    id=region.id,
                    region_type="hazard" if is_hazard else "no_fly",
                    polygon=tuple(tuple(float(value) for value in point)
                                  for point in region.polygon),
                    severity=float(region.severity) if is_hazard else None,
                    hard=(region.is_hard if is_hazard else isinstance(region, NoFlyZone)),
                ))
        return snapshot_type(
            time_h=float(self.time_h),
            nodes=node_values,
            uavs=uav_values,
            inventory=_readonly(self.inventory.quantities),
            airspace_version=int(self.airspace.version),
            airspace_regions=tuple(regions),
            wind_forecast=self.wind_forecast.latest_packet,
            environment_packet=self.environment_packet,
            event_type=event_type,
            terminated=bool(self.terminated),
        )
