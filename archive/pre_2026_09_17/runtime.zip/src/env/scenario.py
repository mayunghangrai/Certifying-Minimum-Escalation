"""Canonical replayable scenarios with an explicit legacy migration boundary."""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

import numpy as np

from .airspace import AirspaceUpdateEvent, HazardRegion, NoFlyZone
from .environment import AirspaceRestriction, EnvironmentalPacket, WeatherRegion
from .entities import UAVParameters
from .network import Network, NetworkEdge, NetworkNode
from .params import (
    COMMODITY_NAMES,
    N_COMMODITIES,
    EnvParams,
    MissionParams,
    PhysicsParams,
)
from .wind import WindForecastPacket, forecast_packets_from_spec


SCHEMA_VERSION = "information-aware-routing-v3"
GENERATOR_VERSION = "authoritative-packets-v1"
_EPS = 1e-9


@dataclass
class ScenarioNode:
    """A completely known relief task retained as a runtime compatibility type."""

    idx: int
    x: float
    y: float
    vulnerability: float
    demand: List[float]
    priority: float = 1.0

    def __post_init__(self) -> None:
        if isinstance(self.idx, bool) or int(self.idx) != self.idx or self.idx < 0:
            raise ValueError("node idx must be a nonnegative integer")
        self.idx = int(self.idx)
        self.x = float(self.x)
        self.y = float(self.y)
        self.vulnerability = float(self.vulnerability)
        self.demand = [float(value) for value in self.demand]
        self.priority = float(self.priority)
        if not all(math.isfinite(value) for value in (
            self.x, self.y, self.vulnerability, self.priority
        )):
            raise ValueError("node coordinates, vulnerability, and priority must be finite")
        if self.vulnerability <= 0.0:
            raise ValueError("node vulnerability must be positive")
        if self.priority <= 0.0:
            raise ValueError("node priority must be positive")
        if len(self.demand) != N_COMMODITIES:
            raise ValueError(f"node demand must have {N_COMMODITIES} values")
        if any(not math.isfinite(value) or value < 0.0 for value in self.demand):
            raise ValueError("node demand must be finite and nonnegative")
        if sum(self.demand) <= 0.0:
            raise ValueError("every node must have positive total demand")


def _sha256(payload: Any) -> str:
    canonical = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _node_from_canonical(index: int, payload: Mapping[str, Any]) -> ScenarioNode:
    position = payload.get("position", (payload.get("x"), payload.get("y")))
    return ScenarioNode(
        idx=index,
        x=position[0],
        y=position[1],
        vulnerability=payload["vulnerability"],
        demand=payload["demand"],
        priority=payload.get("priority", 1.0),
    )


def _canonical_node(node: ScenarioNode) -> dict:
    return {
        "id": f"NODE-{node.idx:03d}",
        "position": [float(node.x), float(node.y)],
        "priority": float(node.priority),
        "vulnerability": float(node.vulnerability),
        "demand": [float(value) for value in node.demand],
    }


def _network_from_positions(
    depot: Sequence[float],
    nodes: Sequence[ScenarioNode],
) -> Network:
    graph_nodes = [
        NetworkNode(id="DEPOT", position=tuple(float(v) for v in depot))
    ]
    graph_nodes.extend(
        NetworkNode(id=f"NODE-{node.idx:03d}", position=(node.x, node.y))
        for node in nodes
    )
    edges: list[NetworkEdge] = []
    depot_point = tuple(float(value) for value in depot)
    for node in nodes:
        node_id = f"NODE-{node.idx:03d}"
        node_point = (float(node.x), float(node.y))
        edges.append(NetworkEdge(
            id=f"DEPOT->{node_id}",
            origin="DEPOT",
            destination=node_id,
            geometry=(depot_point, node_point),
        ))
        edges.append(NetworkEdge(
            id=f"{node_id}->DEPOT",
            origin=node_id,
            destination="DEPOT",
            geometry=(node_point, depot_point),
        ))
    return Network(nodes=tuple(graph_nodes), edges=tuple(edges))


def _legacy_regions_to_packet_data(
    regions: Sequence[Any],
    packet_end_h: float,
) -> tuple[tuple[WeatherRegion, ...], tuple[AirspaceRestriction, ...]]:
    weather: list[WeatherRegion] = []
    airspace: list[AirspaceRestriction] = []
    for region in regions:
        valid_until = (
            region.active_until
            if region.active_until is not None
            else packet_end_h
        )
        if valid_until <= region.active_from + _EPS:
            continue
        if isinstance(region, HazardRegion):
            weather.append(WeatherRegion(
                id=region.id,
                geometry=tuple(region.polygon),
                severity="HARD" if region.is_hard else "SOFT",
                valid_from_h=max(float(region.active_from), 0.0),
                valid_until_h=float(valid_until),
                safety_buffer_m=region.safety_buffer_m,
            ))
        else:
            airspace.append(AirspaceRestriction(
                id=region.id,
                geometry=tuple(region.polygon),
                valid_from_h=max(float(region.active_from), 0.0),
                valid_until_h=float(valid_until),
                safety_buffer_m=region.safety_buffer_m,
            ))
    return tuple(weather), tuple(airspace)


def _packets_from_legacy(
    wind_spec: Mapping[str, Any],
    hazards: Sequence[HazardRegion],
    zones: Sequence[NoFlyZone],
    horizon_h: float,
) -> Tuple[EnvironmentalPacket, ...]:
    packets = []
    for index, packet in enumerate(forecast_packets_from_spec(wind_spec)):
        valid_from = max(float(packet.valid_from_h), float(packet.issued_at_h))
        valid_until = min(float(packet.valid_until_h), float(horizon_h))
        if valid_until <= valid_from + _EPS:
            continue
        weather, airspace = _legacy_regions_to_packet_data(
            [*hazards, *zones], valid_until
        )
        points = tuple(
            point for point in packet.points
            if valid_from - _EPS <= point.valid_time_h <= valid_until + _EPS
        )
        if len(points) == 1 and valid_until > valid_from + _EPS:
            points = (
                points[0],
                points[0].__class__(
                    valid_until,
                    points[0].u_kmh,
                    points[0].v_kmh,
                ),
            )
        packets.append(EnvironmentalPacket(
            packet_id=f"ENV-{index:03d}",
            issued_at_h=float(packet.issued_at_h),
            valid_from_h=valid_from,
            valid_until_h=valid_until,
            wind=points,
            weather=weather,
            airspace=airspace,
        ))
    return tuple(packets)


def _legacy_regions_from_packets(
    packets: Sequence[EnvironmentalPacket],
) -> tuple[list[HazardRegion], list[NoFlyZone]]:
    hazards: list[HazardRegion] = []
    zones: list[NoFlyZone] = []
    seen_hazards: set[str] = set()
    seen_zones: set[str] = set()
    for packet in packets:
        for region in packet.weather:
            if region.id in seen_hazards:
                continue
            seen_hazards.add(region.id)
            hazards.append(HazardRegion(
                id=region.id,
                polygon=[tuple(point) for point in region.geometry],
                severity=1.0 if region.is_hard else 0.5,
                hazard_type="packet_weather",
                active_from=region.valid_from_h,
                active_until=region.valid_until_h,
                version=1,
                safety_buffer_m=region.safety_buffer_m,
                hard_threshold=0.8,
            ))
        for region in packet.airspace:
            if region.id in seen_zones:
                continue
            seen_zones.add(region.id)
            zones.append(NoFlyZone(
                id=region.id,
                polygon=[tuple(point) for point in region.geometry],
                active_from=region.valid_from_h,
                active_until=region.valid_until_h,
                version=1,
                safety_buffer_m=region.safety_buffer_m,
            ))
    return hazards, zones


def _wind_spec_from_packets(packets: Sequence[EnvironmentalPacket]) -> dict:
    return {
        "model": "global_2d_v1",
        "vector_convention": "towards",
        "units": {"time": "h", "speed": "km/h"},
        "forecast_packets": [
            {
                "issued_at_h": packet.issued_at_h,
                "horizon_h": packet.valid_until_h - packet.issued_at_h,
                "points": [point.to_dict() for point in packet.wind],
            }
            for packet in packets
        ],
        "update_interval_h": (
            packets[1].issued_at_h - packets[0].issued_at_h
            if len(packets) > 1 else None
        ),
        "lookahead_h": (
            packets[0].valid_until_h - packets[0].issued_at_h
            if packets else None
        ),
    }


def _params_from_canonical(
    mission: Mapping[str, Any],
    commodities: Sequence[Mapping[str, Any]],
    fleet: Sequence[UAVParameters],
    node_count: int,
    positions: Sequence[Sequence[float]],
) -> dict:
    first = fleet[0] if fleet else UAVParameters.from_physics(0, PhysicsParams())
    physics = {
        "W_max": first.max_payload_kg,
        "m0": first.empty_mass_kg,
        "B_max": first.battery_capacity_wh,
        "e_c": first.energy_coefficient_wh_per_km_kg,
        "e_v": first.service_energy_wh,
        "beta_safe": first.reserve_requirement_wh,
        "v_uav": first.nominal_airspeed_kmh,
    }
    weights = [float(item.get("unit_mass_kg", 1.0)) for item in commodities]
    if len(weights) != N_COMMODITIES:
        weights = [0.25, 0.5, 1.0, 2.5]
    region = max(
        [float(value) for position in positions for value in position] + [12.0]
    )
    return EnvParams.from_dict({
        "physics": physics,
        "mission": {
            "T": float(mission["horizon_h"]),
            "M": len(fleet),
            "environment_update_interval_h": float(
                mission["environment_update_interval_h"]
            ),
            "forecast_horizon_h": float(mission["forecast_horizon_h"]),
        },
        "map": {
            "region_km": region,
            "n_nodes": node_count,
            "n_clusters": 1,
        },
        "commodities": {"w_k": weights},
    }).to_dict()


@dataclass
class Scenario:
    """Replayable scenario with canonical v3 serialization and v2 adapters."""

    # Legacy-compatible construction fields. They are intentionally not the
    # serialized representation; ``to_dict`` emits only canonical v3 fields.
    seed: int = 0
    params: Dict[str, Any] = field(default_factory=dict)
    depot: Any = field(default_factory=list)
    nodes: List[ScenarioNode] = field(default_factory=list)
    initial_inventory: List[float] = field(default_factory=list)
    no_fly_zones: List[NoFlyZone] = field(default_factory=list)
    hazard_regions: List[HazardRegion] = field(default_factory=list)
    airspace_updates: List[AirspaceUpdateEvent] = field(default_factory=list)
    wind_spec: Dict[str, Any] = field(default_factory=dict)
    generation_metadata: Dict[str, Any] = field(default_factory=dict)
    schema_version: str = SCHEMA_VERSION
    metadata: Dict[str, Any] = field(default_factory=dict)
    mission: Dict[str, Any] = field(default_factory=dict)
    commodities: List[Dict[str, Any]] = field(default_factory=list)
    relief_nodes: List[Dict[str, Any]] = field(default_factory=list)
    fleet: List[UAVParameters] = field(default_factory=list)
    network: Optional[Network] = None
    environment_packets: List[EnvironmentalPacket] = field(default_factory=list)
    scenario_descriptors: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.seed = int(self.seed)
        if isinstance(self.depot, Mapping):
            depot_payload = dict(self.depot)
            if not self.initial_inventory:
                self.initial_inventory = list(
                    depot_payload.get("initial_inventory", [])
                )
            self.depot = depot_payload.get("position", [])
        self.depot = [float(value) for value in self.depot]
        if len(self.depot) != 2 or not all(math.isfinite(value) for value in self.depot):
            raise ValueError("depot must contain two finite coordinates")
        self.initial_inventory = [float(value) for value in self.initial_inventory]
        if len(self.initial_inventory) != N_COMMODITIES:
            raise ValueError(f"initial_inventory must have {N_COMMODITIES} values")
        if any(not math.isfinite(value) or value < 0.0 for value in self.initial_inventory):
            raise ValueError("initial_inventory must be finite and nonnegative")

        self.nodes = [
            node if isinstance(node, ScenarioNode)
            else _node_from_canonical(index, node)
            for index, node in enumerate(self.nodes)
        ]
        if not self.nodes and self.relief_nodes:
            self.nodes = [
                _node_from_canonical(index, node)
                for index, node in enumerate(self.relief_nodes)
            ]
        indices = [node.idx for node in self.nodes]
        if indices != list(range(len(self.nodes))):
            raise ValueError("scenario node indices must be contiguous from zero")

        if self.params:
            params = EnvParams.from_dict(self.params)
        else:
            self.fleet = [
                item if isinstance(item, UAVParameters)
                else UAVParameters.from_dict(item)
                for item in self.fleet
            ]
            positions = [self.depot, *[[node.x, node.y] for node in self.nodes]]
            self.params = _params_from_canonical(
                self.mission,
                self.commodities,
                self.fleet,
                len(self.nodes),
                positions,
            )
            params = EnvParams.from_dict(self.params)

        if len(self.nodes) != params.map.n_nodes:
            raise ValueError("scenario node count does not match params.map.n_nodes")
        for point in [self.depot, *self.node_positions().tolist()]:
            if any(value < 0.0 or value > params.map.region_km for value in point):
                raise ValueError("depot and nodes must lie within the map")

        self.mission = {
            "horizon_h": float(self.mission.get("horizon_h", params.mission.T)),
            "environment_update_interval_h": float(self.mission.get(
                "environment_update_interval_h",
                params.mission.environment_update_interval_h,
            )),
            "forecast_horizon_h": float(self.mission.get(
                "forecast_horizon_h", params.mission.forecast_horizon_h
            )),
        }
        self.commodities = self.commodities or [
            {"id": name, "unit_mass_kg": float(mass)}
            for name, mass in zip(COMMODITY_NAMES, params.commodities.w_k)
        ]
        if not self.fleet:
            self.fleet = [
                UAVParameters.from_physics(index, params.physics)
                for index in range(params.mission.M)
            ]
        else:
            self.fleet = [
                item if isinstance(item, UAVParameters)
                else UAVParameters.from_dict(item)
                for item in self.fleet
            ]
        self.relief_nodes = self.relief_nodes or [
            _canonical_node(node) for node in self.nodes
        ]
        self.network = (
            self.network if isinstance(self.network, Network)
            else Network.from_dict(self.network)
            if self.network is not None
            else _network_from_positions(self.depot, self.nodes)
        )

        if not self.environment_packets:
            self.environment_packets = list(_packets_from_legacy(
                self.wind_spec,
                self.hazard_regions,
                self.no_fly_zones,
                self.mission["horizon_h"],
            ))
        else:
            self.environment_packets = [
                item if isinstance(item, EnvironmentalPacket)
                else EnvironmentalPacket.from_dict(item)
                for item in self.environment_packets
            ]
        if not self.environment_packets:
            legacy_without_packets = (
                "truth_keyframes" in self.wind_spec
                or self.generation_metadata.get("schema")
                == "information-aware-routing-v2"
            )
            if not legacy_without_packets:
                raise ValueError("scenario must contain at least one environmental packet")
        self.environment_packets.sort(key=lambda packet: packet.issued_at_h)
        if self.environment_packets:
            if not self.hazard_regions and not self.no_fly_zones:
                self.hazard_regions, self.no_fly_zones = _legacy_regions_from_packets(
                    self.environment_packets
                )
        self.wind_spec = self.wind_spec or _wind_spec_from_packets(
            self.environment_packets
        )

        self.metadata = dict(self.metadata or {})
        self.generation_metadata = dict(self.generation_metadata or {})
        self.metadata.setdefault("seed", self.seed)
        self.metadata.setdefault(
            "generator_version",
            self.generation_metadata.get("generator_version", GENERATOR_VERSION),
        )
        self.metadata.setdefault("config_hash", _sha256(self.params))
        self.scenario_descriptors = self.scenario_descriptors or self._build_descriptors()

    def env_params(self) -> EnvParams:
        return EnvParams.from_dict(self.params)

    def node_positions(self) -> np.ndarray:
        return np.asarray([[node.x, node.y] for node in self.nodes], dtype=float)

    def environment_packet_timeline(self) -> Tuple[EnvironmentalPacket, ...]:
        return tuple(self.environment_packets)

    def wind_forecast_timeline(self) -> List[WindForecastPacket]:
        return [
            WindForecastPacket(
                issued_at_h=packet.issued_at_h,
                horizon_h=packet.valid_until_h - packet.issued_at_h,
                points=tuple(packet.wind),
            )
            for packet in self.environment_packets
        ]

    def airspace_timeline(self) -> List[AirspaceUpdateEvent]:
        """Return a compatibility event view; polygons live in packets."""
        if self.airspace_updates:
            return sorted(
                self.airspace_updates,
                key=lambda event: (event.time_h, event.region_id, event.version),
            )
        updates: list[AirspaceUpdateEvent] = []
        seen: set[tuple[str, str, float]] = set()
        for packet in self.environment_packets:
            for region in packet.weather:
                key = ("hazard", region.id, region.valid_from_h)
                if key in seen:
                    continue
                seen.add(key)
                updates.append(AirspaceUpdateEvent(
                    time_h=region.valid_from_h,
                    region_id=region.id,
                    region_type="hazard",
                    update_type="ACTIVATE",
                    new_polygon=[tuple(point) for point in region.geometry],
                    new_severity=1.0 if region.is_hard else 0.5,
                    version=1,
                ))
            for region in packet.airspace:
                key = ("no_fly", region.id, region.valid_from_h)
                if key in seen:
                    continue
                seen.add(key)
                updates.append(AirspaceUpdateEvent(
                    time_h=region.valid_from_h,
                    region_id=region.id,
                    region_type="no_fly",
                    update_type="ACTIVATE",
                    new_polygon=[tuple(point) for point in region.geometry],
                    version=1,
                ))
        return sorted(
            updates,
            key=lambda event: (event.time_h, event.region_id, event.version),
        )

    def _build_descriptors(self) -> dict:
        wind_magnitudes = [
            math.hypot(point.u_kmh, point.v_kmh)
            for packet in self.environment_packets
            for point in packet.wind
        ]
        unique_weather = {
            region.id for packet in self.environment_packets for region in packet.weather
        }
        unique_airspace = {
            region.id for packet in self.environment_packets for region in packet.airspace
        }
        revisions = 0
        from .environment import compare_environmental_packets
        for previous, current in zip(
            self.environment_packets[:-1], self.environment_packets[1:]
        ):
            revisions += len(compare_environmental_packets(previous, current).revised)
        return {
            "number_of_relief_nodes": len(self.nodes),
            "number_of_uavs": len(self.fleet),
            "number_of_graph_edges": len(self.network.edges),
            "number_of_environment_packets": len(self.environment_packets),
            "number_of_weather_regions": len(unique_weather),
            "number_of_airspace_announcements": len(unique_airspace),
            "mean_wind_magnitude_kmh": (
                float(np.mean(wind_magnitudes)) if wind_magnitudes else 0.0
            ),
            "maximum_wind_magnitude_kmh": (
                float(np.max(wind_magnitudes)) if wind_magnitudes else 0.0
            ),
            "packet_revision_count": revisions,
        }

    def _canonical_dict(self, *, include_hash: bool) -> Dict[str, Any]:
        metadata = {
            "seed": int(self.metadata.get("seed", self.seed)),
            "generator_version": str(
                self.metadata.get("generator_version", GENERATOR_VERSION)
            ),
            "config_hash": str(
                self.metadata.get("config_hash", _sha256(self.params))
            ),
        }
        if include_hash:
            metadata["scenario_hash"] = self._content_hash()
        return {
            "schema_version": SCHEMA_VERSION,
            "metadata": metadata,
            "mission": dict(self.mission),
            "depot": {
                "id": "DEPOT",
                "position": [float(value) for value in self.depot],
                "initial_inventory": [
                    float(value) for value in self.initial_inventory
                ],
            },
            "commodities": [dict(item) for item in self.commodities],
            "relief_nodes": [_canonical_node(node) for node in self.nodes],
            "fleet": [item.to_dict() for item in self.fleet],
            "network": self.network.to_dict(),
            "environment_packets": [
                packet.to_dict() for packet in self.environment_packets
            ],
            "scenario_descriptors": dict(self.scenario_descriptors),
        }

    def _content_hash(self) -> str:
        return _sha256(self._canonical_dict(include_hash=False))

    def to_dict(self) -> Dict[str, Any]:
        return self._canonical_dict(include_hash=True)

    def content_hash(self) -> str:
        return self._content_hash()

    def to_json(self, path: str | Path) -> str:
        destination = Path(path)
        destination.write_text(
            json.dumps(self.to_dict(), indent=1),
            encoding="utf-8",
        )
        return str(destination)

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "Scenario":
        values = dict(payload)
        if "schema_version" in values:
            allowed = {
                "schema_version",
                "metadata",
                "mission",
                "depot",
                "commodities",
                "relief_nodes",
                "fleet",
                "network",
                "environment_packets",
                "scenario_descriptors",
            }
            unknown = sorted(set(values) - allowed)
            if unknown:
                raise ValueError(f"invalid scenario schema (unknown keys: {unknown})")
            required = set(allowed)
            missing = sorted(required - set(values))
            if missing:
                raise ValueError(
                    "invalid scenario schema (missing keys: "
                    + ", ".join(missing)
                    + ")"
                )
            metadata = dict(values.get("metadata") or {})
            required_metadata = {
                "seed", "generator_version", "config_hash", "scenario_hash"
            }
            missing_metadata = sorted(required_metadata - set(metadata))
            if missing_metadata:
                raise ValueError(
                    "invalid scenario schema (metadata fields are incomplete)"
                )
            depot = values.get("depot") or {}
            mission = dict(values.get("mission") or {})
            required_mission = {
                "horizon_h",
                "environment_update_interval_h",
                "forecast_horizon_h",
            }
            if set(mission) != required_mission:
                raise ValueError("invalid scenario schema (mission fields are incomplete)")
            nodes = [
                _node_from_canonical(index, node)
                for index, node in enumerate(values.get("relief_nodes", []))
            ]
            fleet = [
                UAVParameters.from_dict(item)
                for item in values.get("fleet", [])
            ]
            packets = [
                EnvironmentalPacket.from_dict(item)
                for item in values.get("environment_packets", [])
            ]
            if not packets:
                raise ValueError("invalid scenario schema (environment_packets is empty)")
            return cls(
                seed=int(metadata["seed"]),
                params={},
                depot=depot.get("position", []),
                nodes=nodes,
                initial_inventory=depot.get("initial_inventory", []),
                schema_version=str(values.get("schema_version")),
                metadata=metadata,
                mission=mission,
                commodities=list(values.get("commodities", [])),
                relief_nodes=list(values.get("relief_nodes", [])),
                fleet=fleet,
                network=Network.from_dict(values.get("network") or {}),
                environment_packets=packets,
                scenario_descriptors=dict(values.get("scenario_descriptors") or {}),
            )

        expected = {
            "seed",
            "params",
            "depot",
            "nodes",
            "initial_inventory",
            "no_fly_zones",
            "hazard_regions",
            "airspace_updates",
            "wind_spec",
            "generation_metadata",
            "content_hash",
        }
        unknown = sorted(set(values) - expected)
        missing = sorted((expected - {"content_hash"}) - set(values))
        if unknown or missing:
            details = []
            if unknown:
                details.append(f"unknown keys: {unknown}")
            if missing:
                details.append(f"missing keys: {missing}")
            raise ValueError("invalid scenario schema (" + "; ".join(details) + ")")
        return cls(
            seed=values["seed"],
            params=values["params"],
            depot=values["depot"],
            nodes=[ScenarioNode(**node) for node in values["nodes"]],
            initial_inventory=values["initial_inventory"],
            no_fly_zones=[NoFlyZone(**zone) for zone in values["no_fly_zones"]],
            hazard_regions=[HazardRegion(**region) for region in values["hazard_regions"]],
            airspace_updates=[
                AirspaceUpdateEvent(**event)
                for event in values["airspace_updates"]
            ],
            wind_spec=values["wind_spec"],
            generation_metadata=values["generation_metadata"],
        )

    @classmethod
    def from_json(cls, path: str | Path) -> "Scenario":
        return cls.from_dict(json.loads(Path(path).read_text(encoding="utf-8")))
