"""Closed-form deprivation for exact demand known from mission time zero."""

from __future__ import annotations

import math

import numpy as np


def f_waiting(age, alpha, kappa):
    """Exponential waiting cost ``alpha * (exp(kappa * age) - 1)``."""
    return np.asarray(alpha) * (
        np.exp(np.asarray(kappa) * np.maximum(np.asarray(age), 0.0)) - 1.0
    )


def f_waiting_integral(age, duration, alpha, kappa):
    """Exact integral of ``f_waiting(age + s)`` over one duration."""
    age = np.maximum(np.asarray(age), 0.0)
    duration = np.maximum(np.asarray(duration), 0.0)
    alpha = np.asarray(alpha)
    kappa = np.asarray(kappa)
    exponential = np.exp(kappa * age) * np.expm1(kappa * duration)
    with np.errstate(divide="ignore", invalid="ignore"):
        ratio = np.where(
            np.abs(kappa) > 1e-15,
            exponential / kappa,
            np.asarray(duration, dtype=float),
        )
    return alpha * (ratio - duration)


def deprivation_integral(
    vulnerability: float,
    residual_demand: np.ndarray,
    start_time_h: float,
    duration_h: float,
    lambda_k: np.ndarray,
    alpha_k: np.ndarray,
    kappa_k: np.ndarray,
) -> float:
    """Cumulative deprivation while a known residual-demand vector waits."""
    vulnerability = float(vulnerability)
    start_time_h = float(start_time_h)
    duration_h = float(duration_h)
    if not all(math.isfinite(value) for value in (
        vulnerability, start_time_h, duration_h
    )):
        raise ValueError("deprivation inputs must be finite")
    if vulnerability <= 0.0 or start_time_h < 0.0 or duration_h < 0.0:
        raise ValueError("invalid vulnerability, start time, or duration")
    residual = np.asarray(residual_demand, dtype=float)
    weights = np.asarray(lambda_k, dtype=float)
    alpha = np.asarray(alpha_k, dtype=float)
    kappa = np.asarray(kappa_k, dtype=float)
    if not (residual.shape == weights.shape == alpha.shape == kappa.shape):
        raise ValueError("deprivation commodity vectors must have equal shape")
    if np.any(residual < 0.0) or not all(np.all(np.isfinite(value))
                                         for value in (residual, weights, alpha, kappa)):
        raise ValueError("deprivation vectors must be finite and demand nonnegative")
    if duration_h == 0.0 or not np.any(residual > 0.0):
        return 0.0
    return float(vulnerability * np.sum(
        weights * residual * f_waiting_integral(
            start_time_h, duration_h, alpha, kappa
        )
    ))
