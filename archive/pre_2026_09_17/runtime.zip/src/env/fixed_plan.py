"""Deterministic execution of an externally supplied fixed mission plan.

This adapter drives the existing command/event simulator.  It validates and
executes the plan in its declared order; it does not select, repair, or
optimize routes and it never creates undeclared deliveries.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Optional, Sequence

import numpy as np

from .entities import Mode
from .energy import InfeasibilityReason
from .events import EventType
from .metrics import EpisodeMetrics
from .network import NetworkEdge
from .params import N_COMMODITIES, STATE_TOL
from .scenario import Scenario


@dataclass(frozen=True)
class _PlanEntry:
    uav_idx: int
    route: tuple[str, ...]
    load: np.ndarray
    deliveries: dict[str, np.ndarray]


@dataclass(frozen=True)
class FixedPlanResult:
    """Trace and terminal state returned by fixed-plan execution."""

    simulator: Any
    metrics: EpisodeMetrics
    event_log: dict
    flight_events: tuple[dict, ...]
    completed: bool
    termination_reason: str
    conservation: dict
    total_travel_time_h: float
    total_energy_wh: float
    final_reserve_margin_wh: float
    environment_packets_encountered: tuple[str, ...]

    def to_dict(self) -> dict:
        return {
            "completed": self.completed,
            "termination_reason": self.termination_reason,
            "event_log": self.event_log,
            "flight_events": list(self.flight_events),
            "conservation": self.conservation,
            "total_travel_time_h": self.total_travel_time_h,
            "total_energy_wh": self.total_energy_wh,
            "final_reserve_margin_wh": self.final_reserve_margin_wh,
            "environment_packets_encountered": list(
                self.environment_packets_encountered
            ),
        }


def _vector(values: Sequence[float], name: str) -> np.ndarray:
    try:
        vector = np.asarray(values, dtype=float).copy()
    except (TypeError, ValueError) as error:
        raise ValueError(f"{name} must be numeric") from error
    if vector.shape != (N_COMMODITIES,):
        raise ValueError(f"{name} must contain {N_COMMODITIES} values")
    if not np.all(np.isfinite(vector)) or np.any(vector < 0.0):
        raise ValueError(f"{name} must be finite and nonnegative")
    return vector


def _uav_index(scenario: Scenario, key: Any) -> int:
    if isinstance(key, bool):
        raise ValueError("fixed plan UAV key must identify a fleet vehicle")
    if isinstance(key, (int, np.integer)):
        index = int(key)
    else:
        text = str(key)
        matches = [
            index for index, vehicle in enumerate(scenario.fleet)
            if vehicle.id == text
        ]
        if matches:
            return matches[0]
        try:
            index = int(text)
        except ValueError as error:
            raise ValueError(f"unknown fixed plan UAV: {key}") from error
    if not 0 <= index < len(scenario.fleet):
        raise ValueError(f"unknown fixed plan UAV: {key}")
    return index


def _node_index(scenario: Scenario, label: str) -> int:
    text = str(label)
    if text == "DEPOT":
        return -1
    prefix = "NODE-"
    if not text.startswith(prefix):
        raise ValueError(f"invalid fixed plan route location: {label}")
    try:
        index = int(text[len(prefix):])
    except ValueError as error:
        raise ValueError(f"invalid fixed plan route location: {label}") from error
    if not 0 <= index < len(scenario.nodes):
        raise ValueError(f"unknown fixed plan route node: {label}")
    return index


def _normalise_plan(scenario: Scenario, plan: Mapping[Any, Mapping]) -> tuple[_PlanEntry, ...]:
    if not isinstance(plan, Mapping) or not plan:
        raise ValueError("fixed plan must be a nonempty mapping")
    entries: list[_PlanEntry] = []
    seen: set[int] = set()
    for key, raw in plan.items():
        if not isinstance(raw, Mapping):
            raise ValueError(f"fixed plan entry for {key} must be a mapping")
        index = _uav_index(scenario, key)
        if index in seen:
            raise ValueError(f"fixed plan contains duplicate UAV {key}")
        seen.add(index)
        route_value = raw.get("route")
        if isinstance(route_value, (str, bytes)):
            raise ValueError("fixed plan route must be an ordered sequence")
        try:
            route = tuple(str(label) for label in route_value)
        except TypeError as error:
            raise ValueError("fixed plan route must be an ordered sequence") from error
        if len(route) < 2 or route[0] != "DEPOT" or route[-1] != "DEPOT":
            raise ValueError("fixed plan route must start and end at DEPOT")
        for label in route:
            _node_index(scenario, label)
        load = _vector(raw.get("load", np.zeros(N_COMMODITIES)), "fixed plan load")
        delivery_payload = raw.get("deliveries", {})
        if not isinstance(delivery_payload, Mapping):
            raise ValueError("fixed plan deliveries must be a mapping")
        deliveries: dict[str, np.ndarray] = {}
        for label, values in delivery_payload.items():
            label = str(label)
            node_index = _node_index(scenario, label)
            if node_index < 0 or label not in route:
                raise ValueError(
                    "fixed plan deliveries must name demand nodes on the route"
                )
            if label in deliveries:
                raise ValueError(f"duplicate fixed plan delivery for {label}")
            deliveries[label] = _vector(values, f"delivery {label}")
        entries.append(_PlanEntry(index, route, load, deliveries))
    return tuple(sorted(entries, key=lambda entry: entry.uav_idx))


def _position(scenario: Scenario, label: str) -> np.ndarray:
    node_index = _node_index(scenario, label)
    if node_index < 0:
        return np.asarray(scenario.depot, dtype=float).copy()
    node = scenario.nodes[node_index]
    return np.asarray([node.x, node.y], dtype=float)


def _edge_for(scenario: Scenario, origin: str, destination: str) -> NetworkEdge:
    matches = scenario.network.edges_between(origin, destination)
    if matches:
        return matches[0]
    return NetworkEdge(
        id=f"fixed-plan:{origin}->{destination}",
        origin=origin,
        destination=destination,
        geometry=(tuple(_position(scenario, origin)), tuple(_position(scenario, destination))),
    )


def _finish_result(simulator: Any, completed: bool, reason: str) -> FixedPlanResult:
    conservation = simulator.conservation_audit()
    flights = tuple(dict(record) for record in simulator.metrics.flight_log)
    total_time = float(sum(
        float(record.get("arrival_time_h", 0.0))
        - float(record.get("departure_time_h", 0.0))
        for record in flights
    ))
    total_energy = float(simulator.metrics.energy_consumed_wh)
    margins = []
    if simulator.scenario is not None:
        for uav, parameters in zip(simulator.uavs, simulator.scenario.fleet):
            margins.append(float(uav.battery - parameters.reserve_requirement_wh))
    final_margin = float(min(margins)) if margins else 0.0
    packets = list(getattr(simulator, "encountered_packet_ids", ()))
    if not packets:
        for record in flights:
            packet_id = record.get("packet_id")
            if packet_id is not None and packet_id not in packets:
                packets.append(packet_id)
    return FixedPlanResult(
        simulator=simulator,
        metrics=simulator.metrics,
        event_log=simulator.metrics.event_log,
        flight_events=flights,
        completed=bool(completed),
        termination_reason=str(reason),
        conservation=conservation,
        total_travel_time_h=total_time,
        total_energy_wh=total_energy,
        final_reserve_margin_wh=final_margin,
        environment_packets_encountered=tuple(packets),
    )


def _canonical_failure_reason(error: BaseException) -> str:
    message = str(error)
    for reason in InfeasibilityReason:
        if message == reason.value or message.startswith(reason.value + ":"):
            return reason.value
    return message


def _run_on_simulator(simulator: Any, entries: tuple[_PlanEntry, ...]) -> FixedPlanResult:
    scenario = simulator.scenario
    if scenario is None:
        raise RuntimeError("simulator must be reset before fixed-plan execution")
    progress = {entry.uav_idx: 1 for entry in entries}
    delivery_issued = {entry.uav_idx: set() for entry in entries}
    by_index = {entry.uav_idx: entry for entry in entries}
    failure_reason: Optional[str] = None

    try:
        for entry in entries:
            simulator.prepare(entry.uav_idx, entry.load)

        while True:
            action_taken = False
            for entry in entries:
                uav = simulator.uavs[entry.uav_idx]
                if uav.mode is Mode.AWAITING_ROUTE and uav.pending_route is not None:
                    simulator.resume_current_leg(entry.uav_idx)
                    action_taken = True
                    continue
                if uav.mode is Mode.FLYING:
                    continue
                if uav.mode is Mode.SERVICING or uav.mode is Mode.PREPARING:
                    continue
                cursor = progress[entry.uav_idx]
                if cursor >= len(entry.route):
                    continue
                at_depot = np.allclose(
                    uav.position,
                    np.asarray(scenario.depot, dtype=float),
                    atol=STATE_TOL,
                    rtol=0.0,
                )
                current_label = (
                    "DEPOT" if at_depot
                    else f"NODE-{int(uav.current_node):03d}"
                    if uav.current_node is not None else None
                )
                expected_label = entry.route[cursor - 1]
                if current_label != expected_label:
                    raise ValueError(
                        f"fixed plan state diverged at UAV-{entry.uav_idx:02d}: "
                        f"expected {expected_label}, got {current_label}"
                    )
                if (
                    current_label != "DEPOT"
                    and current_label in entry.deliveries
                    and current_label not in delivery_issued[entry.uav_idx]
                ):
                    simulator.deliver(
                        entry.uav_idx,
                        entry.deliveries[current_label],
                    )
                    delivery_issued[entry.uav_idx].add(current_label)
                    action_taken = True
                    continue
                if cursor >= len(entry.route):
                    continue
                origin = entry.route[cursor - 1]
                destination = entry.route[cursor]
                edge = _edge_for(scenario, origin, destination)
                destination_index = _node_index(scenario, destination)
                simulator.dispatch(
                    entry.uav_idx,
                    destination_index,
                    edge.geometry,
                )
                progress[entry.uav_idx] = cursor + 1
                action_taken = True

            all_done = all(
                simulator.uavs[index].mode is Mode.DEPOT
                and progress[index] == len(entry.route)
                for index, entry in by_index.items()
            )
            if all_done:
                return _finish_result(simulator, True, "completed")
            if simulator.terminated:
                failure_reason = simulator.metrics.termination_reason or "horizon"
                break
            if action_taken:
                continue
            if simulator.queue.peek_time() is None:
                failure_reason = "event queue is empty before fixed plan completion"
                break
            epoch = simulator.advance()
            if epoch.event_type is EventType.HORIZON:
                failure_reason = "MISSION_HORIZON_EXCEEDED"
                break
    except (RuntimeError, ValueError) as error:
        failure_reason = _canonical_failure_reason(error)

    simulator.metrics.termination_reason = failure_reason or "fixed plan failed"
    return _finish_result(simulator, False, simulator.metrics.termination_reason)


def execute_fixed_plan(
    scenario: Scenario,
    plan: Mapping[Any, Mapping],
    objective_params: Any = None,
) -> FixedPlanResult:
    """Reset a simulator and execute the caller-supplied deterministic plan."""
    entries = _normalise_plan(scenario, plan)
    from .simulator import RoutingSimulator

    simulator = RoutingSimulator()
    simulator.reset(scenario, objective_params=objective_params)
    return _run_on_simulator(simulator, entries)


def execute_fixed_plan_on_simulator(simulator: Any, plan: Mapping[Any, Mapping]) -> FixedPlanResult:
    """Execute a validated fixed plan from an already reset simulator."""
    if simulator.scenario is None:
        raise RuntimeError("simulator must be reset before fixed-plan execution")
    entries = _normalise_plan(simulator.scenario, plan)
    return _run_on_simulator(simulator, entries)
