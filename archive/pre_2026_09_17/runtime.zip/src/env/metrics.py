"""Method-neutral episode measurements."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from .objective import ObjectiveParams, evaluate_episode
from .params import N_COMMODITIES


@dataclass
class EpisodeMetrics:
    total_deprivation: float = 0.0
    per_node_deprivation: Dict[int, float] = field(default_factory=dict)
    energy_consumed_wh: float = 0.0
    hard_route_violations: int = 0
    battery_violations: int = 0
    delivered_units: np.ndarray = field(
        default_factory=lambda: np.zeros(N_COMMODITIES, dtype=float)
    )
    initial_demand_units: np.ndarray = field(
        default_factory=lambda: np.zeros(N_COMMODITIES, dtype=float)
    )
    completed_services: int = 0
    termination_reason: str = ""
    priorities: Optional[np.ndarray] = None
    initial_demand_per_node: Optional[np.ndarray] = None
    horizon_h: float = 0.0
    objective_params: ObjectiveParams = field(default_factory=ObjectiveParams)
    delivery_log: List[Tuple[int, np.ndarray, float]] = field(default_factory=list)
    flight_log: List[Dict[str, Any]] = field(default_factory=list)
    delivery_events: List[Dict[str, Any]] = field(default_factory=list)
    per_uav_energy_wh: Dict[int, float] = field(default_factory=dict)
    charged_battery_wh: Dict[int, float] = field(default_factory=dict)
    distance_travelled_km: float = 0.0

    def add_deprivation(self, node_id: int, value: float) -> None:
        amount = float(value)
        self.total_deprivation += amount
        self.per_node_deprivation[node_id] = (
            self.per_node_deprivation.get(node_id, 0.0) + amount
        )

    def record_delivery(self, node_id: int, quantities, time_h: float) -> None:
        """Record a completed delivery for the humanitarian objective."""
        self.delivery_log.append(
            (int(node_id), np.asarray(quantities, dtype=float).copy(), float(time_h))
        )

    def record_flight(self, record: Dict[str, Any]) -> None:
        """Append a JSON-friendly physical flight event."""
        self.flight_log.append(dict(record))
        uav_id = int(record["uav"])
        energy = float(record.get("energy_wh", 0.0))
        self.per_uav_energy_wh[uav_id] = (
            self.per_uav_energy_wh.get(uav_id, 0.0) + energy
        )
        self.distance_travelled_km += float(record.get("distance_km", 0.0))

    def record_delivery_event(self, record: Dict[str, Any]) -> None:
        """Append a structured service event while retaining delivery_log."""
        self.delivery_events.append(dict(record))

    @property
    def event_log(self) -> Dict[str, List[Dict[str, Any]]]:
        """Structured execution trace, separate from scenario serialization."""
        return {
            "flights": list(self.flight_log),
            "deliveries": list(self.delivery_events),
        }

    def fill_rate(self) -> float:
        initial = float(np.sum(self.initial_demand_units))
        return 1.0 if initial <= 1e-12 else float(
            np.sum(self.delivered_units) / initial
        )

    def humanitarian_objective(self) -> Optional[Dict]:
        """Priority-weighted delivery time, maximin fairness, composite."""
        if self.priorities is None or self.initial_demand_per_node is None:
            return None
        return evaluate_episode(
            self.priorities,
            self.initial_demand_per_node,
            self.delivery_log,
            self.horizon_h,
            self.objective_params,
        )

    def summary(self, residual_demand: np.ndarray) -> Dict:
        return {
            "total_deprivation": self.total_deprivation,
            "per_node_deprivation": dict(self.per_node_deprivation),
            "energy_consumed_wh": self.energy_consumed_wh,
            "hard_route_violations": self.hard_route_violations,
            "battery_violations": self.battery_violations,
            "delivered_units": self.delivered_units.tolist(),
            "fill_rate": self.fill_rate(),
            "unserved_residual_demand": np.asarray(
                residual_demand, dtype=float
            ).tolist(),
            "completed_services": self.completed_services,
            "termination_reason": self.termination_reason,
            "delivery_log": [
                {
                    "node_idx": node_idx,
                    "quantities": quantities.tolist(),
                    "time_h": time_h,
                }
                for node_idx, quantities, time_h in self.delivery_log
            ],
            "flight_log": list(self.flight_log),
            "delivery_events": list(self.delivery_events),
            "per_uav_energy_wh": dict(self.per_uav_energy_wh),
            "distance_travelled_km": self.distance_travelled_km,
            "humanitarian_objective": self.humanitarian_objective(),
        }
