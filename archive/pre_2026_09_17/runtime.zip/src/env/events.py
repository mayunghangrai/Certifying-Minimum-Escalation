"""Deterministic events used by the method-neutral routing executor."""

from __future__ import annotations

import heapq
import itertools
import math
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class EventType(Enum):
    ENVIRONMENT_PACKET = "environment_packet"
    ENVIRONMENT_PACKET_UPDATE = "environment_packet"
    AIRSPACE_UPDATE = "airspace_update"
    WIND_FORECAST_UPDATE = "wind_forecast_update"
    WAYPOINT_REACHED = "waypoint_reached"
    LOAD_COMPLETE = "load_complete"
    SERVICE_COMPLETE = "service_complete"
    HORIZON = "horizon"


_PRIORITY = {
    EventType.ENVIRONMENT_PACKET: 0,
    EventType.AIRSPACE_UPDATE: 0,
    EventType.WIND_FORECAST_UPDATE: 1,
    EventType.WAYPOINT_REACHED: 2,
    EventType.SERVICE_COMPLETE: 3,
    EventType.LOAD_COMPLETE: 4,
    EventType.HORIZON: 5,
}


@dataclass(frozen=True)
class Event:
    time_h: float
    event_type: EventType
    payload: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        time_h = float(self.time_h)
        object.__setattr__(self, "time_h", time_h)
        if not math.isfinite(time_h) or time_h < 0.0:
            raise ValueError("event time_h must be finite and nonnegative")


class EventQueue:
    """Min-heap ordered by time, event priority, and insertion sequence."""

    def __init__(self) -> None:
        self._heap: List = []
        self._counter = itertools.count()
        self._cancelled: set[int] = set()
        self._last_popped_time = -math.inf

    def push(self, event: Event) -> int:
        if event.time_h < self._last_popped_time - 1e-12:
            raise ValueError("cannot insert an event earlier than queue progress")
        sequence = next(self._counter)
        heapq.heappush(
            self._heap,
            (event.time_h, _PRIORITY[event.event_type], sequence, event),
        )
        return sequence

    def cancel(self, sequence: int) -> None:
        self._cancelled.add(int(sequence))

    def _discard_cancelled_head(self) -> None:
        while self._heap and self._heap[0][2] in self._cancelled:
            _, _, sequence, _ = heapq.heappop(self._heap)
            self._cancelled.discard(sequence)

    def pop(self) -> Optional[Event]:
        self._discard_cancelled_head()
        if not self._heap:
            return None
        _, _, sequence, event = heapq.heappop(self._heap)
        self._cancelled.discard(sequence)
        if event.time_h < self._last_popped_time - 1e-12:
            raise ValueError("event queue produced a nonmonotone event")
        self._last_popped_time = event.time_h
        return event

    def peek_time(self) -> Optional[float]:
        self._discard_cancelled_head()
        return None if not self._heap else float(self._heap[0][0])

    def __len__(self) -> int:
        return sum(1 for _, _, sequence, _ in self._heap
                   if sequence not in self._cancelled)
