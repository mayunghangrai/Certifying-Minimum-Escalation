"""Authoritative environmental packets and packet-transition utilities."""

from __future__ import annotations

import dataclasses
import math
from dataclasses import dataclass
from typing import Any, Mapping, Optional, Sequence, Tuple


_EPS = 1e-9
Point2D = Tuple[float, float]


def _point(value: Sequence[float]) -> Point2D:
    if len(value) != 2:
        raise ValueError("polygon points must contain two coordinates")
    point = (float(value[0]), float(value[1]))
    if not all(math.isfinite(component) for component in point):
        raise ValueError("polygon points must be finite")
    return point


def _polygon(values: Sequence[Sequence[float]]) -> Tuple[Point2D, ...]:
    points = tuple(_point(value) for value in values)
    if len(points) < 3:
        raise ValueError("environment polygons must contain at least three points")
    area_twice = sum(
        left[0] * right[1] - right[0] * left[1]
        for left, right in zip(points, (*points[1:], points[0]))
    )
    if abs(area_twice) <= _EPS:
        raise ValueError("environment polygon must have positive area")
    return points


def _interval(valid_from_h: float, valid_until_h: Optional[float]) -> Tuple[float, Optional[float]]:
    start = float(valid_from_h)
    end = None if valid_until_h is None else float(valid_until_h)
    if not math.isfinite(start) or start < 0.0:
        raise ValueError("valid_from_h must be finite and nonnegative")
    if end is not None and (not math.isfinite(end) or end <= start):
        raise ValueError("valid_until_h must be finite and after valid_from_h")
    return start, end


def _normalise_severity(value: Any) -> str:
    if isinstance(value, str):
        value = value.strip().upper()
        aliases = {"DEGRADED": "SOFT", "SOFT": "SOFT", "BLOCKED": "HARD", "HARD": "HARD"}
        if value in aliases:
            return aliases[value]
    if isinstance(value, (int, float)) and math.isfinite(float(value)):
        return "HARD" if float(value) >= 0.8 else "SOFT"
    raise ValueError("weather severity must be SOFT/DEGRADED or HARD/BLOCKED")


@dataclass(frozen=True)
class WeatherRegion:
    """A polygonal weather region, soft/degraded or hard/blocked."""

    id: str
    geometry: Tuple[Point2D, ...]
    severity: str
    valid_from_h: float
    valid_until_h: Optional[float]
    safety_buffer_m: float = 0.0

    def __post_init__(self) -> None:
        region_id = str(self.id)
        if not region_id:
            raise ValueError("weather region id must be nonempty")
        start, end = _interval(self.valid_from_h, self.valid_until_h)
        buffer_m = float(self.safety_buffer_m)
        if not math.isfinite(buffer_m) or buffer_m < 0.0:
            raise ValueError("weather safety_buffer_m must be finite and nonnegative")
        object.__setattr__(self, "id", region_id)
        object.__setattr__(self, "geometry", _polygon(self.geometry))
        object.__setattr__(self, "severity", _normalise_severity(self.severity))
        object.__setattr__(self, "valid_from_h", start)
        object.__setattr__(self, "valid_until_h", end)
        object.__setattr__(self, "safety_buffer_m", buffer_m)

    @property
    def is_hard(self) -> bool:
        return self.severity == "HARD"

    def active_at(self, time_h: float) -> bool:
        time_h = float(time_h)
        return time_h >= self.valid_from_h - _EPS and (
            self.valid_until_h is None or time_h <= self.valid_until_h + _EPS
        )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "geometry": [list(point) for point in self.geometry],
            "severity": self.severity,
            "valid_from_h": float(self.valid_from_h),
            "valid_until_h": None if self.valid_until_h is None else float(self.valid_until_h),
            "safety_buffer_m": float(self.safety_buffer_m),
        }

    @classmethod
    def from_dict(cls, payload: Mapping) -> "WeatherRegion":
        return cls(
            id=payload["id"],
            geometry=payload.get("geometry", payload.get("polygon")),
            severity=payload.get("severity", "SOFT"),
            valid_from_h=payload.get("valid_from_h", payload.get("active_from", 0.0)),
            valid_until_h=payload.get("valid_until_h", payload.get("active_until")),
            safety_buffer_m=payload.get("safety_buffer_m", 0.0),
        )


@dataclass(frozen=True)
class AirspaceRestriction:
    """A hard polygonal no-fly restriction with a validity interval."""

    id: str
    geometry: Tuple[Point2D, ...]
    valid_from_h: float
    valid_until_h: Optional[float]
    safety_buffer_m: float = 0.0

    def __post_init__(self) -> None:
        region_id = str(self.id)
        if not region_id:
            raise ValueError("airspace restriction id must be nonempty")
        start, end = _interval(self.valid_from_h, self.valid_until_h)
        buffer_m = float(self.safety_buffer_m)
        if not math.isfinite(buffer_m) or buffer_m < 0.0:
            raise ValueError("airspace safety_buffer_m must be finite and nonnegative")
        object.__setattr__(self, "id", region_id)
        object.__setattr__(self, "geometry", _polygon(self.geometry))
        object.__setattr__(self, "valid_from_h", start)
        object.__setattr__(self, "valid_until_h", end)
        object.__setattr__(self, "safety_buffer_m", buffer_m)

    def active_at(self, time_h: float) -> bool:
        time_h = float(time_h)
        return time_h >= self.valid_from_h - _EPS and (
            self.valid_until_h is None or time_h <= self.valid_until_h + _EPS
        )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "geometry": [list(point) for point in self.geometry],
            "valid_from_h": float(self.valid_from_h),
            "valid_until_h": None if self.valid_until_h is None else float(self.valid_until_h),
            "safety_buffer_m": float(self.safety_buffer_m),
        }

    @classmethod
    def from_dict(cls, payload: Mapping) -> "AirspaceRestriction":
        return cls(
            id=payload["id"],
            geometry=payload.get("geometry", payload.get("polygon")),
            valid_from_h=payload.get("valid_from_h", payload.get("active_from", 0.0)),
            valid_until_h=payload.get("valid_until_h", payload.get("active_until")),
            safety_buffer_m=payload.get("safety_buffer_m", 0.0),
        )


def _wind_points(value: Any) -> Tuple[Any, ...]:
    from .wind import WindForecastPoint

    if isinstance(value, Mapping):
        value = value.get("points", ())
    points = []
    for point in value:
        if isinstance(point, WindForecastPoint):
            points.append(point)
        elif isinstance(point, Mapping):
            points.append(WindForecastPoint.from_dict(point))
        else:
            try:
                if len(point) != 3:
                    raise ValueError
                points.append(WindForecastPoint(
                    valid_time_h=float(point[0]),
                    u_kmh=float(point[1]),
                    v_kmh=float(point[2]),
                ))
            except (TypeError, ValueError, IndexError) as error:
                raise ValueError(
                    "wind points must be WindForecastPoint, mappings, or [time_h, u_kmh, v_kmh]"
                ) from error
    points = tuple(points)
    if not points:
        raise ValueError("an environmental packet requires at least one wind point")
    times = [float(point.valid_time_h) for point in points]
    if any(later <= earlier for earlier, later in zip(times[:-1], times[1:])):
        raise ValueError("packet wind times must be strictly increasing")
    return points


@dataclass(frozen=True)
class EnvironmentalPacket:
    """Authoritative environmental information issued for a finite horizon."""

    packet_id: str
    issued_at_h: float
    valid_from_h: float
    valid_until_h: float
    wind: Tuple[Any, ...]
    weather: Tuple[WeatherRegion, ...] = ()
    airspace: Tuple[AirspaceRestriction, ...] = ()

    def __post_init__(self) -> None:
        packet_id = str(self.packet_id)
        issued_at = float(self.issued_at_h)
        valid_from = float(self.valid_from_h)
        valid_until = float(self.valid_until_h)
        if not packet_id:
            raise ValueError("packet_id must be nonempty")
        if not math.isfinite(issued_at) or issued_at < 0.0:
            raise ValueError("issued_at_h must be finite and nonnegative")
        if not math.isfinite(valid_from) or valid_from < issued_at - _EPS:
            raise ValueError("valid_from_h must be finite and no earlier than issued_at_h")
        if not math.isfinite(valid_until) or valid_until <= valid_from:
            raise ValueError("valid_until_h must be finite and after valid_from_h")
        wind = _wind_points(self.wind)
        if wind[0].valid_time_h < valid_from - _EPS or wind[-1].valid_time_h > valid_until + _EPS:
            raise ValueError("packet wind points must lie within the packet validity interval")
        weather = tuple(
            item if isinstance(item, WeatherRegion) else WeatherRegion.from_dict(item)
            for item in self.weather
        )
        airspace = tuple(
            item if isinstance(item, AirspaceRestriction) else AirspaceRestriction.from_dict(item)
            for item in self.airspace
        )
        object.__setattr__(self, "packet_id", packet_id)
        object.__setattr__(self, "issued_at_h", issued_at)
        object.__setattr__(self, "valid_from_h", valid_from)
        object.__setattr__(self, "valid_until_h", valid_until)
        object.__setattr__(self, "wind", wind)
        object.__setattr__(self, "weather", weather)
        object.__setattr__(self, "airspace", airspace)

    @property
    def valid_interval(self) -> Tuple[float, float]:
        return self.valid_from_h, self.valid_until_h

    @property
    def wind_points(self) -> Tuple[Any, ...]:
        return self.wind

    def wind_at(self, time_h: float) -> Optional[Tuple[float, float]]:
        """Return the packet wind at a covered time, or ``None`` outside it."""
        return _wind_at(self.wind, time_h)

    def covers(self, start_time_h: float, end_time_h: float) -> bool:
        return (
            float(start_time_h) >= self.valid_from_h - _EPS
            and float(end_time_h) <= self.valid_until_h + _EPS
            and float(start_time_h) <= float(end_time_h)
        )

    def to_dict(self) -> dict:
        return {
            "packet_id": self.packet_id,
            "issued_at_h": float(self.issued_at_h),
            "valid_from_h": float(self.valid_from_h),
            "valid_until_h": float(self.valid_until_h),
            "wind": {
                "model": "global_2d",
                "vector_convention": "towards",
                "units": {"time": "h", "speed": "km/h"},
                "points": [point.to_dict() for point in self.wind],
            },
            "weather": [region.to_dict() for region in self.weather],
            "airspace": [restriction.to_dict() for restriction in self.airspace],
        }

    @classmethod
    def from_dict(cls, payload: Mapping) -> "EnvironmentalPacket":
        wind_payload = payload.get("wind", payload.get("wind_points", ()))
        if isinstance(wind_payload, Mapping):
            wind_payload = wind_payload.get("points", ())
        return cls(
            packet_id=payload["packet_id"],
            issued_at_h=payload["issued_at_h"],
            valid_from_h=payload.get("valid_from_h", payload["issued_at_h"]),
            valid_until_h=payload["valid_until_h"],
            wind=wind_payload,
            weather=tuple(WeatherRegion.from_dict(item) for item in payload.get("weather", ())),
            airspace=tuple(AirspaceRestriction.from_dict(item) for item in payload.get("airspace", ())),
        )


@dataclass(frozen=True)
class EnvironmentalChange:
    domain: str
    key: str
    interval: Tuple[float, float]
    before: Any
    after: Any


@dataclass(frozen=True)
class EnvironmentalTransition:
    overlap: Optional[Tuple[float, float]]
    revised: Tuple[EnvironmentalChange, ...]
    newly_revealed: Tuple[EnvironmentalChange, ...]

    @property
    def revision(self) -> Tuple[EnvironmentalChange, ...]:
        return self.revised

    @property
    def new(self) -> Tuple[EnvironmentalChange, ...]:
        return self.newly_revealed

    def __getitem__(self, key: str):
        if key == "overlap":
            return self.overlap
        if key in {"revised", "revision"}:
            return self.revised
        if key in {"newly_revealed", "new"}:
            return self.newly_revealed
        raise KeyError(key)

    def to_dict(self) -> dict:
        return dataclasses.asdict(self)


def _wind_at(points: Sequence[Any], time_h: float) -> Optional[Tuple[float, float]]:
    if not points:
        return None
    time_h = float(time_h)
    if time_h < points[0].valid_time_h - _EPS or time_h > points[-1].valid_time_h + _EPS:
        return None
    if time_h <= points[0].valid_time_h + _EPS:
        return float(points[0].u_kmh), float(points[0].v_kmh)
    for left, right in zip(points[:-1], points[1:]):
        if time_h <= right.valid_time_h + _EPS:
            weight = (time_h - left.valid_time_h) / (right.valid_time_h - left.valid_time_h)
            return (
                float(left.u_kmh + weight * (right.u_kmh - left.u_kmh)),
                float(left.v_kmh + weight * (right.v_kmh - left.v_kmh)),
            )
    return float(points[-1].u_kmh), float(points[-1].v_kmh)


def _region_signature(
    region: Any,
    interval: Optional[Tuple[float, float]] = None,
) -> Optional[tuple]:
    values = tuple((round(x, 10), round(y, 10)) for x, y in region.geometry)
    severity = getattr(region, "severity", None)
    start = float(region.valid_from_h)
    end = math.inf if region.valid_until_h is None else float(region.valid_until_h)
    if interval is not None:
        start = max(start, float(interval[0]))
        end = min(end, float(interval[1]))
        if end <= start + _EPS:
            return None
    return values, severity, round(start, 10), (
        None if math.isinf(end) else round(end, 10)
    )


def _coverage_changes(
    previous: EnvironmentalPacket,
    current: EnvironmentalPacket,
) -> Tuple[Tuple[EnvironmentalChange, ...], Tuple[EnvironmentalChange, ...]]:
    """Return finite cells on which packet coverage was lost or gained."""

    boundaries = sorted({
        float(previous.valid_from_h),
        float(previous.valid_until_h),
        float(current.valid_from_h),
        float(current.valid_until_h),
    })
    revised = []
    newly_revealed = []
    for left, right in zip(boundaries[:-1], boundaries[1:]):
        if right <= left + _EPS:
            continue
        midpoint = 0.5 * (left + right)
        before = previous.valid_from_h <= midpoint <= previous.valid_until_h
        after = current.valid_from_h <= midpoint <= current.valid_until_h
        if before == after:
            continue
        change = EnvironmentalChange(
            domain="coverage",
            key=f"{left:g}:{right:g}",
            interval=(left, right),
            before=before,
            after=after,
        )
        if after:
            newly_revealed.append(change)
        else:
            revised.append(change)
    return tuple(revised), tuple(newly_revealed)


def _wind_difference_changes(
    previous: EnvironmentalPacket,
    current: EnvironmentalPacket,
    overlap: Optional[Tuple[float, float]],
) -> Tuple[EnvironmentalChange, ...]:
    """Cover differences between two piecewise-linear wind functions."""

    if overlap is None:
        return ()
    start = max(
        float(overlap[0]),
        float(previous.wind[0].valid_time_h),
        float(current.wind[0].valid_time_h),
    )
    end = min(
        float(overlap[1]),
        float(previous.wind[-1].valid_time_h),
        float(current.wind[-1].valid_time_h),
    )
    if end <= start + _EPS:
        return ()
    boundaries = sorted({
        start,
        end,
        *(
            float(point.valid_time_h)
            for point in (*previous.wind, *current.wind)
            if start < point.valid_time_h < end
        ),
    })
    changes = []
    for left, right in zip(boundaries[:-1], boundaries[1:]):
        before_left = _wind_at(previous.wind, left)
        before_right = _wind_at(previous.wind, right)
        after_left = _wind_at(current.wind, left)
        after_right = _wind_at(current.wind, right)
        if None in (before_left, before_right, after_left, after_right):
            continue
        endpoints_equal = all(
            math.isclose(before, after, rel_tol=0.0, abs_tol=_EPS)
            for before_values, after_values in (
                (before_left, after_left),
                (before_right, after_right),
            )
            for before, after in zip(before_values, after_values)
        )
        if endpoints_equal:
            continue
        changes.append(EnvironmentalChange(
            domain="wind",
            key=f"{left:g}:{right:g}",
            interval=(left, right),
            before=((left, *before_left), (right, *before_right)),
            after=((left, *after_left), (right, *after_right)),
        ))
    return tuple(changes)


def compare_environmental_packets(
    previous: EnvironmentalPacket,
    current: EnvironmentalPacket,
) -> EnvironmentalTransition:
    """Separate changes in a common horizon from newly revealed conditions."""
    if not isinstance(previous, EnvironmentalPacket) or not isinstance(current, EnvironmentalPacket):
        raise TypeError("packet comparison requires EnvironmentalPacket values")
    overlap_start = max(previous.valid_from_h, current.valid_from_h)
    overlap_end = min(previous.valid_until_h, current.valid_until_h)
    overlap = None if overlap_end <= overlap_start + _EPS else (overlap_start, overlap_end)
    coverage_revised, coverage_new = _coverage_changes(previous, current)
    revised = [*coverage_revised, *_wind_difference_changes(
        previous,
        current,
        overlap,
    )]
    newly_revealed = list(coverage_new)

    for point in current.wind:
        if point.valid_time_h > previous.valid_until_h + _EPS:
            newly_revealed.append(EnvironmentalChange(
                domain="wind",
                key=f"{point.valid_time_h:g}",
                interval=(float(point.valid_time_h), float(point.valid_time_h)),
                before=None,
                after=(float(point.u_kmh), float(point.v_kmh)),
            ))

    for domain, before_regions, after_regions in (
        ("weather", previous.weather, current.weather),
        ("airspace", previous.airspace, current.airspace),
    ):
        before_by_id = {region.id: region for region in before_regions}
        after_by_id = {region.id: region for region in after_regions}
        for region_id in sorted(set(before_by_id) | set(after_by_id)):
            before = before_by_id.get(region_id)
            after = after_by_id.get(region_id)
            if after is not None and after.valid_until_h is not None and after.valid_until_h > previous.valid_until_h + _EPS:
                start = max(after.valid_from_h, previous.valid_until_h)
                if start < after.valid_until_h - _EPS:
                    newly_revealed.append(EnvironmentalChange(
                        domain=domain,
                        key=region_id,
                        interval=(start, after.valid_until_h),
                        before=None,
                        after=_region_signature(after),
                    ))
            if overlap is None:
                continue
            before_signature = (
                None if before is None else _region_signature(before, overlap)
            )
            after_signature = (
                None if after is None else _region_signature(after, overlap)
            )
            if before_signature != after_signature and (before is not None or after is not None):
                revised.append(EnvironmentalChange(
                    domain=domain,
                    key=region_id,
                    interval=overlap,
                    before=before_signature,
                    after=after_signature,
                ))

    return EnvironmentalTransition(
        overlap=overlap,
        revised=tuple(revised),
        newly_revealed=tuple(newly_revealed),
    )


packet_transition = compare_environmental_packets
