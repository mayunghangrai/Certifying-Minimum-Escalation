"""Read-only diagnostics for an incumbent plan at a packet update epoch."""

from __future__ import annotations

import dataclasses
import math
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from types import MappingProxyType
from typing import Any, Mapping, Optional, Sequence, Tuple

import numpy as np
from shapely.geometry import LineString, Polygon

from .environment import (
    EnvironmentalChange,
    EnvironmentalPacket,
    EnvironmentalTransition,
    compare_environmental_packets,
)
from .energy import InfeasibilityReason, evaluate_leg
from .params import ENERGY_TOL_WH, N_COMMODITIES, STATE_TOL, TIME_TOL_H


_EPS = 1e-9
_GEOMETRY_MATCH_TOL = 1e-7
_UNDETERMINED_REASONS = frozenset({
    "INVALID_ENVIRONMENTAL_COVERAGE",
    "UPSTREAM_PROPAGATION_UNKNOWN",
})


class ProjectionStatus(str, Enum):
    """Three-valued status for one packet-conditioned leg projection."""

    FEASIBLE = "feasible"
    INFEASIBLE = "infeasible"
    UNDETERMINED = "undetermined"


def _jsonable(value: Any) -> Any:
    if dataclasses.is_dataclass(value):
        return {
            field.name: _jsonable(getattr(value, field.name))
            for field in dataclasses.fields(value)
        }
    if isinstance(value, Enum):
        return _jsonable(value.value)
    if isinstance(value, Mapping):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, np.ndarray):
        return _jsonable(value.tolist())
    if isinstance(value, np.generic):
        return _jsonable(value.item())
    if isinstance(value, tuple):
        return [_jsonable(item) for item in value]
    if isinstance(value, list):
        return [_jsonable(item) for item in value]
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("diagnostic values must be finite or None")
    return value


@dataclass(frozen=True)
class LegProjection:
    feasible: bool
    reason: Optional[str]
    reason_codes: Tuple[str, ...]
    departure_time_h: Optional[float]
    arrival_time_h: Optional[float]
    travel_time_h: Optional[float]
    energy_wh: Optional[float]
    battery_before_wh: Optional[float]
    battery_after_flight_wh: Optional[float]
    service_energy_wh: float
    battery_after_service_wh: Optional[float]
    reserve_margin_wh: Optional[float]
    deadline_h: Optional[float]
    deadline_slack_h: Optional[float]
    deadline_met: Optional[bool]
    status: ProjectionStatus = field(init=False)

    def __post_init__(self) -> None:
        if self.feasible:
            status = ProjectionStatus.FEASIBLE
        elif any(code in _UNDETERMINED_REASONS for code in self.reason_codes):
            status = ProjectionStatus.UNDETERMINED
        else:
            status = ProjectionStatus.INFEASIBLE
        object.__setattr__(self, "status", status)

    def to_dict(self) -> dict:
        return _jsonable(self)


@dataclass(frozen=True)
class LegImpact:
    leg_id: str
    uav_id: str
    uav_idx: int
    route_index: int
    origin: str
    destination: str
    geometry: Tuple[Tuple[float, float], ...]
    payload_mass_kg: float
    directly_affected: bool
    direct_changes: Tuple[EnvironmentalChange, ...]
    propagated: bool
    baseline: LegProjection
    revised: LegProjection
    delta_arrival_time_h: Optional[float]
    delta_travel_time_h: Optional[float]
    delta_energy_wh: Optional[float]
    delta_deadline_slack_h: Optional[float]
    baseline_payload_mass_kg: Optional[float] = None
    revised_payload_mass_kg: Optional[float] = None

    def to_dict(self) -> dict:
        return _jsonable(self)


@dataclass(frozen=True)
class DependencyVertex:
    """One typed quantity in the paired packet-evaluation graph."""

    vertex_id: str
    kind: str
    leg_id: Optional[str]
    baseline_value: Any
    revised_value: Any
    materially_changed: bool

    def to_dict(self) -> dict:
        return _jsonable(self)


@dataclass(frozen=True)
class DependencyEdge:
    """One directed syntactic dependency between graph vertices."""

    parent_id: str
    child_id: str

    def to_dict(self) -> dict:
        return _jsonable(self)


@dataclass(frozen=True)
class DisturbanceDependencyGraph:
    """Typed graph and its structural, material, and reportable supports."""

    vertices: Tuple[DependencyVertex, ...]
    edges: Tuple[DependencyEdge, ...]
    seed_vertex_ids: Tuple[str, ...]
    structural_closure_vertex_ids: Tuple[str, ...]
    material_vertex_ids: Tuple[str, ...]
    operational_material_vertex_ids: Tuple[str, ...]
    reportable_vertex_ids: Tuple[str, ...]
    is_acyclic: bool

    def __post_init__(self) -> None:
        for name in (
            "vertices",
            "edges",
            "seed_vertex_ids",
            "structural_closure_vertex_ids",
            "material_vertex_ids",
            "operational_material_vertex_ids",
            "reportable_vertex_ids",
        ):
            object.__setattr__(self, name, tuple(getattr(self, name)))

    @property
    def affected_leg_ids(self) -> Tuple[str, ...]:
        reportable = frozenset(self.reportable_vertex_ids)
        return tuple(dict.fromkeys(
            vertex.leg_id
            for vertex in self.vertices
            if vertex.vertex_id in reportable and vertex.leg_id is not None
        ))

    def to_dict(self) -> dict:
        return _jsonable(self)


@dataclass(frozen=True)
class DisturbanceImpactClosure:
    epoch_time_h: float
    previous_packet_id: str
    received_packet_id: str
    transition: EnvironmentalTransition
    legs: Tuple[LegImpact, ...]
    dependency_graph: DisturbanceDependencyGraph
    summary: Mapping[str, Any]
    non_anticipative: bool = True

    def __post_init__(self) -> None:
        object.__setattr__(self, "legs", tuple(self.legs))
        object.__setattr__(self, "summary", MappingProxyType(dict(self.summary)))

    @property
    def directly_affected_legs(self) -> Tuple[LegImpact, ...]:
        return tuple(leg for leg in self.legs if leg.directly_affected)

    @property
    def propagated_legs(self) -> Tuple[LegImpact, ...]:
        return tuple(leg for leg in self.legs if leg.propagated)

    @property
    def affected_leg_ids(self) -> Tuple[str, ...]:
        affected = frozenset(self.dependency_graph.affected_leg_ids)
        return tuple(leg.leg_id for leg in self.legs if leg.leg_id in affected)

    @property
    def affected_task_ids(self) -> Tuple[str, ...]:
        affected = frozenset(self.affected_leg_ids)
        return tuple(sorted({
            task_id
            for leg in self.legs
            if leg.leg_id in affected
            for task_id in (leg.origin, leg.destination)
            if task_id != "DEPOT"
        }))

    def to_dict(self) -> dict:
        return _jsonable(self)


def _validate_packet_update(
    epoch: Any,
    previous_packet: EnvironmentalPacket,
    received_packet: EnvironmentalPacket,
) -> float:
    if not isinstance(previous_packet, EnvironmentalPacket):
        raise TypeError("previous_packet must be an EnvironmentalPacket")
    if not isinstance(received_packet, EnvironmentalPacket):
        raise TypeError("received_packet must be an EnvironmentalPacket")
    epoch_time = float(epoch.time_h)
    if not math.isfinite(epoch_time) or epoch_time < 0.0:
        raise ValueError("decision epoch time must be finite and nonnegative")
    if previous_packet.issued_at_h > epoch_time + _EPS:
        raise ValueError("previous packet is not visible at this decision epoch")
    if received_packet.issued_at_h > epoch_time + _EPS:
        raise ValueError("received packet is not visible at this decision epoch")
    if received_packet.issued_at_h <= previous_packet.issued_at_h + _EPS:
        raise ValueError("received packet must be later than the previous packet")
    current = getattr(epoch, "environment_packet", None)
    if current is not None and current != received_packet:
        raise ValueError("received packet does not match the decision epoch")
    return epoch_time


def _empty_summary() -> Mapping[str, Any]:
    return MappingProxyType({
        "remaining_leg_count": 0,
        "directly_affected_leg_count": 0,
        "propagated_leg_count": 0,
        "baseline_infeasible_leg_count": 0,
        "revised_infeasible_leg_count": 0,
        "baseline_deadline_miss_count": 0,
        "revised_deadline_miss_count": 0,
        "total_known_flight_energy_delta_wh": 0.0,
        "maximum_known_arrival_delta_h": None,
    })


@dataclass(frozen=True)
class _PlanEntry:
    uav_idx: int
    uav_id: str
    route: Tuple[str, ...]
    load: np.ndarray
    deliveries: Mapping[str, np.ndarray]
    geometries: Any
    current_route_index: Optional[int]


@dataclass(frozen=True)
class _RemainingLeg:
    uav_idx: int
    uav_id: str
    route_index: int
    origin: str
    destination: str
    geometry: Tuple[Tuple[float, float], ...]


@dataclass
class _ProjectionState:
    time_h: Optional[float]
    battery_wh: Optional[float]
    payload: np.ndarray
    failed: bool = False


def _vector(values: Any, name: str) -> np.ndarray:
    try:
        vector = np.asarray(values, dtype=float).copy()
    except (TypeError, ValueError) as error:
        raise ValueError(f"{name} must contain numeric quantities") from error
    if vector.shape != (N_COMMODITIES,):
        raise ValueError(f"{name} must contain {N_COMMODITIES} quantities")
    if not np.all(np.isfinite(vector)) or np.any(vector < 0.0):
        raise ValueError(f"{name} must be finite and nonnegative")
    return vector


def _geometry(value: Any, name: str) -> Tuple[Tuple[float, float], ...]:
    try:
        points = np.asarray(value, dtype=float)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{name} must contain numeric points") from error
    if points.ndim != 2 or points.shape[1:] != (2,) or len(points) < 2:
        raise ValueError(f"{name} must have shape (n, 2) with at least two points")
    if not np.all(np.isfinite(points)):
        raise ValueError(f"{name} must contain finite points")
    if np.any(np.linalg.norm(np.diff(points, axis=0), axis=1) <= _EPS):
        raise ValueError(f"{name} cannot contain consecutive duplicate points")
    return tuple(tuple(float(component) for component in point) for point in points)


def _uav_index(scenario: Any, key: Any) -> int:
    if isinstance(key, bool):
        raise ValueError(f"incumbent plan names an unknown UAV: {key}")
    fleet = tuple(getattr(scenario, "fleet", ()))
    for index, vehicle in enumerate(fleet):
        if key == index or str(key) == str(getattr(vehicle, "id", "")):
            return index
    if isinstance(key, str) and key.isdigit():
        index = int(key)
        if 0 <= index < len(fleet):
            return index
    raise ValueError(f"incumbent plan names an unknown UAV: {key}")


def _node_labels(scenario: Any) -> Mapping[str, int]:
    return {
        f"NODE-{int(node.idx):03d}": int(node.idx)
        for node in getattr(scenario, "nodes", ())
    }


def _label(value: Any, node_labels: Mapping[str, int]) -> str:
    if value == "DEPOT":
        return "DEPOT"
    if isinstance(value, (int, np.integer)) and not isinstance(value, bool):
        candidate = f"NODE-{int(value):03d}"
    else:
        candidate = str(value)
        if candidate.startswith("NODE-"):
            suffix = candidate[5:]
            if suffix.isdigit():
                candidate = f"NODE-{int(suffix):03d}"
    if candidate in node_labels:
        return candidate
    raise ValueError(f"incumbent plan names an unknown route label: {value}")


def _position_for_label(scenario: Any, label: str) -> Tuple[float, float]:
    if label == "DEPOT":
        value = getattr(scenario, "depot")
        return float(value[0]), float(value[1])
    index = int(label.split("-")[1])
    node = next(node for node in scenario.nodes if int(node.idx) == index)
    return float(node.x), float(node.y)


def _uav_id(scenario: Any, index: int) -> str:
    return str(getattr(scenario.fleet[index], "id", f"UAV-{index:02d}"))


def _geometry_source(raw: Mapping[str, Any]) -> Any:
    for key in ("leg_geometries", "geometries", "waypoints_by_leg"):
        if key in raw:
            return raw[key]
    return None


def _remaining_geometry(
    value: Any,
    position: Any,
    name: str,
) -> Tuple[Tuple[float, float], ...]:
    """Clip an active polyline at the observed position without rerouting it."""
    points = np.asarray(_geometry(value, name), dtype=float)
    current = np.asarray(position, dtype=float)
    if current.shape != (2,) or not np.all(np.isfinite(current)):
        raise ValueError("snapshot position must contain two finite coordinates")
    best_distance = math.inf
    best_index = 0
    best_fraction = 0.0
    for index, (start, end) in enumerate(zip(points[:-1], points[1:])):
        segment = end - start
        denominator = float(np.dot(segment, segment))
        fraction = float(np.clip(
            np.dot(current - start, segment) / denominator,
            0.0,
            1.0,
        ))
        projected = start + fraction * segment
        distance = float(np.linalg.norm(current - projected))
        if distance < best_distance:
            best_distance = distance
            best_index = index
            best_fraction = fraction
    if best_distance > _GEOMETRY_MATCH_TOL:
        raise ValueError(f"{name} does not contain the snapshot position")
    projected = points[best_index] + best_fraction * (points[best_index + 1] - points[best_index])
    remainder = [tuple(float(component) for component in current)]
    for point in (projected, *points[best_index + 1:]):
        candidate = tuple(float(component) for component in point)
        if np.linalg.norm(np.asarray(candidate) - np.asarray(remainder[-1])) > _GEOMETRY_MATCH_TOL:
            remainder.append(candidate)
    return _geometry(remainder, name)


def _normalise_plan(scenario: Any, plan: Mapping[Any, Mapping[str, Any]]) -> Tuple[_PlanEntry, ...]:
    if not isinstance(plan, Mapping):
        raise TypeError("incumbent_plan must be a mapping")
    node_labels = _node_labels(scenario)
    entries = []
    seen = set()
    for key, raw in plan.items():
        if not isinstance(raw, Mapping):
            raise ValueError(f"incumbent plan entry for {key} must be a mapping")
        index = _uav_index(scenario, key)
        if index in seen:
            raise ValueError(f"incumbent plan contains duplicate UAV {key}")
        seen.add(index)
        route_value = raw.get("route")
        if isinstance(route_value, (str, bytes)):
            raise ValueError("incumbent plan route must be an ordered sequence")
        try:
            route = tuple(_label(value, node_labels) for value in route_value)
        except TypeError as error:
            raise ValueError("incumbent plan route must be an ordered sequence") from error
        if len(route) < 2 or route[0] != "DEPOT" or route[-1] != "DEPOT":
            raise ValueError("incumbent plan route must start and end at DEPOT")
        if any(left == right for left, right in zip(route[:-1], route[1:])):
            raise ValueError("incumbent plan route cannot repeat a consecutive label")
        current_route_index = raw.get("current_route_index")
        if current_route_index is not None:
            if isinstance(current_route_index, bool) or not isinstance(
                current_route_index, (int, np.integer)
            ):
                raise ValueError(
                    "current_route_index must be an integer when provided"
                )
            current_route_index = int(current_route_index)
            if not 0 <= current_route_index < len(route):
                raise ValueError(
                    "current_route_index must identify a stop in the incumbent route"
                )
        load = _vector(raw.get("load", np.zeros(N_COMMODITIES)), "incumbent plan load")
        delivery_payload = raw.get("deliveries", {})
        if not isinstance(delivery_payload, Mapping):
            raise ValueError("incumbent plan deliveries must be a mapping")
        deliveries = {}
        for delivery_key, values in delivery_payload.items():
            delivery_label = _label(delivery_key, node_labels)
            if delivery_label == "DEPOT" or delivery_label not in route:
                raise ValueError(
                    "incumbent plan deliveries must name demand nodes on the route"
                )
            if delivery_label in deliveries:
                raise ValueError(f"incumbent plan contains duplicate delivery for {delivery_label}")
            deliveries[delivery_label] = _vector(
                values, f"delivery {delivery_label}"
            )
        entries.append(_PlanEntry(
            uav_idx=index,
            uav_id=_uav_id(scenario, index),
            route=route,
            load=load,
            deliveries=deliveries,
            geometries=_geometry_source(raw),
            current_route_index=current_route_index,
        ))
    return tuple(sorted(entries, key=lambda entry: entry.uav_idx))


def _explicit_geometry(
    source: Any,
    route_index: int,
    origin: str,
    destination: str,
) -> Optional[Tuple[Tuple[float, float], ...]]:
    if source is None:
        return None
    candidate = None
    if isinstance(source, Mapping):
        for key in (
            route_index,
            str(route_index),
            f"{origin}->{destination}",
        ):
            if key in source:
                candidate = source[key]
                break
    elif not isinstance(source, (str, bytes)):
        try:
            candidate = source[route_index]
        except (IndexError, TypeError):
            candidate = None
    return None if candidate is None else _geometry(
        candidate, f"geometry for {origin}->{destination}"
    )


def _edge_geometry(
    scenario: Any,
    entry: _PlanEntry,
    route_index: int,
    origin: str,
    destination: str,
) -> Tuple[Tuple[float, float], ...]:
    explicit = _explicit_geometry(entry.geometries, route_index, origin, destination)
    if explicit is not None:
        return explicit
    network = getattr(scenario, "network", None)
    matches = () if network is None else network.edges_between(origin, destination)
    if matches:
        return tuple(
            tuple(float(component) for component in point)
            for point in matches[0].geometry
        )
    raise ValueError(
        f"incumbent plan has no declared geometry for {origin}->{destination}"
    )


def _mode_name(state: Any) -> str:
    mode = getattr(state, "mode", "")
    return str(getattr(mode, "value", mode)).lower()


def _state_label(scenario: Any, state: Any) -> Optional[str]:
    current_node = getattr(state, "current_node", None)
    if current_node is not None:
        return f"NODE-{int(current_node):03d}"
    position = np.asarray(getattr(state, "position"), dtype=float)
    depot = np.asarray(getattr(scenario, "depot"), dtype=float)
    if np.allclose(position, depot, atol=STATE_TOL, rtol=0.0):
        return "DEPOT"
    for node in getattr(scenario, "nodes", ()):
        if np.allclose(
            position, np.asarray([node.x, node.y]), atol=STATE_TOL, rtol=0.0
        ):
            return f"NODE-{int(node.idx):03d}"
    return None


def _destination_label(scenario: Any, value: Any) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, (int, np.integer)) and not isinstance(value, bool):
        return "DEPOT" if int(value) == -1 else f"NODE-{int(value):03d}"
    return _label(value, _node_labels(scenario))


def _route_index_after(
    route: Tuple[str, ...],
    destination: str,
    current: Optional[str],
    current_route_index: Optional[int] = None,
) -> int:
    if current_route_index is not None:
        if current_route_index >= len(route) - 1:
            raise ValueError(
                "current_route_index has no following committed-plan leg"
            )
        if current is not None and route[current_route_index] != current:
            raise ValueError(
                "current_route_index does not identify the observed incumbent stop"
            )
        target_index = current_route_index + 1
        if route[target_index] != destination:
            raise ValueError(
                "committed destination does not match the next incumbent-plan stop"
            )
        return target_index
    candidates = [index for index, label in enumerate(route) if label == destination]
    if destination == "DEPOT":
        candidates = [index for index in candidates if index > 0]
    if current is not None and current in route:
        current_indices = [index for index, label in enumerate(route) if label == current]
        if len(current_indices) > 1 and not (
            current == "DEPOT" and len(current_indices) == 2
        ):
            raise ValueError(
                "observed incumbent stop is ambiguous; provide current_route_index"
            )
        current_index = current_indices[0]
        later = [index for index in candidates if index > current_index]
        if later:
            return later[0]
    if len(candidates) > 1:
        raise ValueError(
            "committed destination is ambiguous; provide current_route_index"
        )
    if candidates:
        return candidates[0]
    raise ValueError("committed destination is not a remaining incumbent-plan stop")


def _snapshot_uav(epoch: Any, index: int) -> Any:
    for state in getattr(epoch, "uavs", ()):
        if int(getattr(state, "idx")) == index:
            return state
    raise ValueError(f"decision epoch has no state for UAV index {index}")


def _remaining_legs(scenario: Any, epoch: Any, entry: _PlanEntry) -> Tuple[_RemainingLeg, ...]:
    state = _snapshot_uav(epoch, entry.uav_idx)
    current = _state_label(scenario, state)
    mode = _mode_name(state)
    committed = getattr(state, "committed_route", None)
    if committed is None and mode == "flying":
        committed = getattr(state, "active_route", None)
    committed_destination = getattr(state, "committed_destination", None)
    if committed_destination is None and mode == "flying":
        committed_destination = getattr(state, "destination", None)
    if committed is not None and committed_destination is not None:
        destination = _destination_label(scenario, committed_destination)
        assert destination is not None
        target_index = _route_index_after(
            entry.route,
            destination,
            current,
            entry.current_route_index,
        )
        origin = entry.route[target_index - 1]
        return (
            _RemainingLeg(
                uav_idx=entry.uav_idx,
                uav_id=entry.uav_id,
                route_index=target_index - 1,
                origin=origin,
                destination=destination,
                geometry=_remaining_geometry(
                    committed,
                    getattr(state, "position"),
                    "committed route",
                ),
            ),
            *tuple(
                _RemainingLeg(
                    uav_idx=entry.uav_idx,
                    uav_id=entry.uav_id,
                    route_index=index,
                    origin=entry.route[index],
                    destination=entry.route[index + 1],
                    geometry=_edge_geometry(
                        scenario,
                        entry,
                        index,
                        entry.route[index],
                        entry.route[index + 1],
                    ),
                )
                for index in range(target_index, len(entry.route) - 1)
            ),
        )
    if mode in {"flying", "awaiting_route"}:
        raise ValueError(
            f"UAV {entry.uav_id} has no committed geometry at the decision epoch"
        )
    if current is None:
        raise ValueError(f"UAV {entry.uav_id} is not at a declared incumbent stop")
    if entry.current_route_index is not None:
        current_index = entry.current_route_index
        if entry.route[current_index] != current:
            raise ValueError(
                f"UAV {entry.uav_id} current_route_index does not match its stop"
            )
    else:
        current_indices = [
            index for index, label in enumerate(entry.route) if label == current
        ]
        if not current_indices:
            raise ValueError(
                f"UAV {entry.uav_id} is not at its incumbent route position"
            )
        if len(current_indices) > 1 and not (
            current == "DEPOT" and len(current_indices) == 2
        ):
            raise ValueError(
                f"UAV {entry.uav_id} has an ambiguous repeated stop; "
                "provide current_route_index"
            )
        current_index = current_indices[0]
    return tuple(
        _RemainingLeg(
            uav_idx=entry.uav_idx,
            uav_id=entry.uav_id,
            route_index=index,
            origin=entry.route[index],
            destination=entry.route[index + 1],
            geometry=_edge_geometry(
                scenario,
                entry,
                index,
                entry.route[index],
                entry.route[index + 1],
            ),
        )
        for index in range(current_index, len(entry.route) - 1)
    )


def _deadline(deadlines: Optional[Mapping[Any, float]], destination: str, horizon_h: float) -> float:
    if deadlines is None:
        return float(horizon_h)
    candidates: list[Any] = [destination]
    if destination != "DEPOT":
        candidates.append(int(destination.split("-")[1]))
    for candidate in candidates:
        if candidate in deadlines:
            value = float(deadlines[candidate])
            if not math.isfinite(value) or value < 0.0:
                raise ValueError("deadline values must be finite and nonnegative")
            return value
    return float(horizon_h)


def _validate_deadlines(deadlines: Optional[Mapping[Any, float]]) -> None:
    if deadlines is None:
        return
    if not isinstance(deadlines, Mapping):
        raise TypeError("deadlines_h must be a mapping when provided")
    for key, value in deadlines.items():
        try:
            deadline = float(value)
        except (TypeError, ValueError) as error:
            raise ValueError(f"deadline for {key} must be numeric") from error
        if not math.isfinite(deadline) or deadline < 0.0:
            raise ValueError(
                f"deadline for {key} must be finite and nonnegative"
            )


def _projection_failure(
    reason: str,
    departure_time_h: Optional[float],
    deadline_h: float,
) -> LegProjection:
    return LegProjection(
        feasible=False,
        reason=reason,
        reason_codes=(reason,),
        departure_time_h=departure_time_h,
        arrival_time_h=None,
        travel_time_h=None,
        energy_wh=None,
        battery_before_wh=None,
        battery_after_flight_wh=None,
        service_energy_wh=0.0,
        battery_after_service_wh=None,
        reserve_margin_wh=None,
        deadline_h=deadline_h,
        deadline_slack_h=None,
        deadline_met=None,
    )


def _reason_code(evaluation: Any) -> str:
    reason_code = getattr(evaluation, "reason_code", None)
    if reason_code is not None:
        return str(getattr(reason_code, "value", reason_code))
    return str(getattr(evaluation, "reason", None) or "LEG_INFEASIBLE")


def _project_leg(
    state: _ProjectionState,
    leg: _RemainingLeg,
    entry: _PlanEntry,
    scenario: Any,
    params: Any,
    packet: EnvironmentalPacket,
    deadline_h: float,
) -> Tuple[LegProjection, _ProjectionState]:
    if state.failed or state.time_h is None or state.battery_wh is None:
        return (
            _projection_failure(
                "UPSTREAM_PROPAGATION_UNKNOWN", None, deadline_h
            ),
            _ProjectionState(None, None, state.payload.copy(), True),
        )
    delivery = entry.deliveries.get(leg.destination, np.zeros(N_COMMODITIES))
    payload = state.payload.copy()
    payload_mass = float(np.dot(np.asarray(params.commodities.w_k), payload))
    vehicle = scenario.fleet[entry.uav_idx]
    evaluation = evaluate_leg(
        {"geometry": leg.geometry},
        state.time_h,
        payload_mass,
        vehicle,
        packet,
    )
    departure = float(state.time_h)
    if not evaluation.feasible:
        projection = LegProjection(
            feasible=False,
            reason=_reason_code(evaluation),
            reason_codes=(_reason_code(evaluation),),
            departure_time_h=departure,
            arrival_time_h=getattr(evaluation, "arrival_time_h", None),
            travel_time_h=getattr(evaluation, "travel_time_h", None),
            energy_wh=getattr(evaluation, "energy_wh", None),
            battery_before_wh=float(state.battery_wh),
            battery_after_flight_wh=None,
            service_energy_wh=0.0,
            battery_after_service_wh=None,
            reserve_margin_wh=None,
            deadline_h=deadline_h,
            deadline_slack_h=None,
            deadline_met=None,
        )
        return projection, _ProjectionState(None, None, payload, True)

    assert evaluation.arrival_time_h is not None
    assert evaluation.travel_time_h is not None
    assert evaluation.energy_wh is not None
    battery_after_flight = float(state.battery_wh - evaluation.energy_wh)
    service_energy = (
        float(vehicle.service_energy_wh)
        if leg.destination != "DEPOT" and np.sum(delivery) > _EPS
        else 0.0
    )
    if np.any(delivery > payload + STATE_TOL):
        raise ValueError(
            f"incumbent delivery at {leg.destination} exceeds the declared payload"
        )
    payload_after = payload - delivery
    payload_after[payload_after < 0.0] = 0.0
    battery_after_service = battery_after_flight - service_energy
    reserve_margin = battery_after_service - float(vehicle.reserve_requirement_wh)
    reason_codes = []
    if battery_after_flight < -ENERGY_TOL_WH:
        reason_codes.append(InfeasibilityReason.INSUFFICIENT_BATTERY.value)
    if battery_after_service < -ENERGY_TOL_WH:
        if InfeasibilityReason.INSUFFICIENT_BATTERY.value not in reason_codes:
            reason_codes.append(InfeasibilityReason.INSUFFICIENT_BATTERY.value)
    if reserve_margin < -ENERGY_TOL_WH:
        reason_codes.append(InfeasibilityReason.SAFE_RETURN_RESERVE_VIOLATION.value)
    service_time = (
        float(params.mission.service_time_h)
        if service_energy > _EPS else 0.0
    )
    if evaluation.arrival_time_h + service_time > float(params.mission.T) + TIME_TOL_H:
        reason_codes.append(InfeasibilityReason.MISSION_HORIZON_EXCEEDED.value)
    deadline_slack = float(deadline_h - evaluation.arrival_time_h)
    projection = LegProjection(
        feasible=not reason_codes,
        reason=reason_codes[0] if reason_codes else None,
        reason_codes=tuple(reason_codes),
        departure_time_h=departure,
        arrival_time_h=float(evaluation.arrival_time_h),
        travel_time_h=float(evaluation.travel_time_h),
        energy_wh=float(evaluation.energy_wh),
        battery_before_wh=float(state.battery_wh),
        battery_after_flight_wh=battery_after_flight,
        service_energy_wh=service_energy,
        battery_after_service_wh=battery_after_service,
        reserve_margin_wh=reserve_margin,
        deadline_h=deadline_h,
        deadline_slack_h=deadline_slack,
        deadline_met=bool(deadline_slack >= -TIME_TOL_H),
    )
    if not projection.feasible:
        return projection, _ProjectionState(None, None, payload_after, True)
    return projection, _ProjectionState(
        float(evaluation.arrival_time_h + service_time),
        battery_after_service,
        payload_after,
        False,
    )


def _projection_intervals(
    projection: LegProjection,
    packet: EnvironmentalPacket,
) -> Tuple[Tuple[float, float], ...]:
    if projection.departure_time_h is None:
        return ()
    start = float(projection.departure_time_h)
    end = projection.arrival_time_h
    if end is None:
        end = float(packet.valid_until_h)
    return ((start, max(start, float(end))),)


def _intervals_overlap(
    first: Tuple[float, float],
    second: Tuple[float, float],
) -> bool:
    return max(float(first[0]), float(second[0])) <= min(
        float(first[1]), float(second[1])
    ) + _EPS


def _region_points(value: Any) -> Optional[Tuple[Tuple[float, float], ...]]:
    if value is None or not isinstance(value, (tuple, list)) or not value:
        return None
    points = value[0]
    try:
        return _geometry(points, "environment change region")
    except (TypeError, ValueError):
        return None


def _change_touches_geometry(
    change: EnvironmentalChange,
    geometry: Tuple[Tuple[float, float], ...],
) -> bool:
    if change.domain in {"coverage", "wind"}:
        return True
    line = LineString(geometry)
    for value in (change.before, change.after):
        points = _region_points(value)
        if points is not None and line.intersects(Polygon(points)):
            return True
    return False


def _change_intervals(change: EnvironmentalChange) -> Tuple[Tuple[float, float], ...]:
    """Return the change's effective temporal support for direct attribution."""
    if change.domain not in {"weather", "airspace"}:
        return (change.interval,)
    intervals = []
    for value in (change.before, change.after):
        if value is None or not isinstance(value, (tuple, list)) or len(value) < 4:
            continue
        try:
            start = max(float(change.interval[0]), float(value[2]))
            end_value = value[3]
            end = float(change.interval[1]) if end_value is None else min(
                float(change.interval[1]), float(end_value)
            )
        except (TypeError, ValueError):
            continue
        if start <= end + _EPS:
            intervals.append((start, end))
    return tuple(intervals) or (change.interval,)


def _direct_changes(
    leg: _RemainingLeg,
    baseline: LegProjection,
    revised: LegProjection,
    previous_packet: EnvironmentalPacket,
    received_packet: EnvironmentalPacket,
    transition: EnvironmentalTransition,
) -> Tuple[EnvironmentalChange, ...]:
    intervals = (
        *_projection_intervals(baseline, previous_packet),
        *_projection_intervals(revised, received_packet),
    )
    changes = []
    for change in (*transition.revised, *transition.newly_revealed):
        if not any(
            (
                max(change_interval[0], interval[0])
                < min(change_interval[1], interval[1]) - _EPS
                if change.domain == "coverage"
                else _intervals_overlap(change_interval, interval)
            )
            and _change_touches_geometry(change, leg.geometry)
            for interval in intervals
            for change_interval in _change_intervals(change)
        ):
            continue
        if change not in changes:
            changes.append(change)
    return tuple(changes)


def _known_delta(first: Optional[float], second: Optional[float]) -> Optional[float]:
    if first is None or second is None:
        return None
    return float(second - first)


def _numeric_changed(
    first: Optional[float],
    second: Optional[float],
    tolerance: float,
) -> bool:
    if first is None or second is None:
        return first is not second
    return not math.isclose(
        float(first),
        float(second),
        rel_tol=0.0,
        abs_tol=tolerance,
    )


def _projection_changed(first: LegProjection, second: LegProjection) -> bool:
    if first.status is not second.status or first.reason_codes != second.reason_codes:
        return True
    for left, right in (
        (first.arrival_time_h, second.arrival_time_h),
        (first.travel_time_h, second.travel_time_h),
        (first.deadline_slack_h, second.deadline_slack_h),
    ):
        if _numeric_changed(left, right, TIME_TOL_H):
            return True
    for left, right in (
        (first.energy_wh, second.energy_wh),
        (first.battery_after_flight_wh, second.battery_after_flight_wh),
        (first.battery_after_service_wh, second.battery_after_service_wh),
        (first.reserve_margin_wh, second.reserve_margin_wh),
    ):
        if _numeric_changed(left, right, ENERGY_TOL_WH):
            return True
    return first.deadline_met is not second.deadline_met


def _entering_state_changed(
    baseline: _ProjectionState,
    revised: _ProjectionState,
    mass_vector: np.ndarray,
) -> bool:
    baseline_mass = None if baseline.failed else float(np.dot(mass_vector, baseline.payload))
    revised_mass = None if revised.failed else float(np.dot(mass_vector, revised.payload))
    return any((
        _numeric_changed(baseline.time_h, revised.time_h, TIME_TOL_H),
        _numeric_changed(baseline.battery_wh, revised.battery_wh, ENERGY_TOL_WH),
        _numeric_changed(baseline_mass, revised_mass, STATE_TOL),
    ))


def _vertex_changed(
    baseline: Any,
    revised: Any,
    tolerance: Optional[float] = None,
) -> bool:
    if tolerance is not None:
        return _numeric_changed(baseline, revised, tolerance)
    return baseline != revised


def _reachable_vertices(
    seed_ids: Sequence[str],
    edges: Sequence[DependencyEdge],
) -> frozenset[str]:
    adjacency: dict[str, list[str]] = {}
    for edge in edges:
        adjacency.setdefault(edge.parent_id, []).append(edge.child_id)
    reached = set(seed_ids)
    pending = deque(seed_ids)
    while pending:
        parent = pending.popleft()
        for child in adjacency.get(parent, ()):
            if child in reached:
                continue
            reached.add(child)
            pending.append(child)
    return frozenset(reached)


def _is_acyclic(
    vertex_ids: Sequence[str],
    edges: Sequence[DependencyEdge],
) -> bool:
    adjacency: dict[str, list[str]] = {vertex_id: [] for vertex_id in vertex_ids}
    indegree = {vertex_id: 0 for vertex_id in vertex_ids}
    for edge in edges:
        adjacency[edge.parent_id].append(edge.child_id)
        indegree[edge.child_id] += 1
    pending = deque(
        vertex_id for vertex_id in vertex_ids if indegree[vertex_id] == 0
    )
    visited = 0
    while pending:
        parent = pending.popleft()
        visited += 1
        for child in adjacency[parent]:
            indegree[child] -= 1
            if indegree[child] == 0:
                pending.append(child)
    return visited == len(vertex_ids)


def _dependency_graph(
    legs: Sequence[LegImpact],
    transition: EnvironmentalTransition,
) -> DisturbanceDependencyGraph:
    vertices: list[DependencyVertex] = []
    edges: list[DependencyEdge] = []
    vertex_ids: set[str] = set()
    edge_pairs: set[tuple[str, str]] = set()
    seed_ids: list[str] = []

    def add_vertex(
        vertex_id: str,
        kind: str,
        leg_id: Optional[str],
        baseline: Any,
        revised: Any,
        *,
        tolerance: Optional[float] = None,
        changed: Optional[bool] = None,
    ) -> str:
        if vertex_id in vertex_ids:
            raise ValueError(f"duplicate dependency vertex: {vertex_id}")
        vertex_ids.add(vertex_id)
        vertices.append(DependencyVertex(
            vertex_id=vertex_id,
            kind=kind,
            leg_id=leg_id,
            baseline_value=baseline,
            revised_value=revised,
            materially_changed=(
                _vertex_changed(baseline, revised, tolerance)
                if changed is None else bool(changed)
            ),
        ))
        return vertex_id

    def add_edge(parent_id: str, child_id: str) -> None:
        pair = (parent_id, child_id)
        if pair in edge_pairs:
            return
        edge_pairs.add(pair)
        edges.append(DependencyEdge(parent_id, child_id))

    change_ids: dict[int, str] = {}
    for group, changes in (
        ("revised", transition.revised),
        ("new", transition.newly_revealed),
    ):
        for index, change in enumerate(changes):
            vertex_id = f"packet:{group}:{index:03d}:{change.domain}:{change.key}"
            add_vertex(
                vertex_id,
                "packet_change",
                None,
                _jsonable(change.before),
                _jsonable(change.after),
                changed=True,
            )
            change_ids[id(change)] = vertex_id

    previous_by_uav: dict[int, Mapping[str, str]] = {}
    for leg in legs:
        prefix = leg.leg_id
        node = {
            "departure": add_vertex(
                f"{prefix}:state:departure",
                "state",
                prefix,
                leg.baseline.departure_time_h,
                leg.revised.departure_time_h,
                tolerance=TIME_TOL_H,
            ),
            "battery": add_vertex(
                f"{prefix}:state:battery",
                "state",
                prefix,
                leg.baseline.battery_before_wh,
                leg.revised.battery_before_wh,
                tolerance=ENERGY_TOL_WH,
            ),
            "payload": add_vertex(
                f"{prefix}:state:payload_mass",
                "state",
                prefix,
                leg.baseline_payload_mass_kg,
                leg.revised_payload_mass_kg,
                tolerance=STATE_TOL,
            ),
            "evaluation": add_vertex(
                f"{prefix}:evaluator",
                "evaluator",
                prefix,
                (
                    leg.baseline.status.value,
                    leg.baseline.reason_codes,
                    leg.baseline.travel_time_h,
                    leg.baseline.energy_wh,
                ),
                (
                    leg.revised.status.value,
                    leg.revised.reason_codes,
                    leg.revised.travel_time_h,
                    leg.revised.energy_wh,
                ),
                changed=_projection_changed(leg.baseline, leg.revised),
            ),
        }

        quantity_specs = {
            "travel_time": (
                leg.baseline.travel_time_h,
                leg.revised.travel_time_h,
                TIME_TOL_H,
            ),
            "arrival": (
                leg.baseline.arrival_time_h,
                leg.revised.arrival_time_h,
                TIME_TOL_H,
            ),
            "energy": (
                leg.baseline.energy_wh,
                leg.revised.energy_wh,
                ENERGY_TOL_WH,
            ),
            "battery_after_flight": (
                leg.baseline.battery_after_flight_wh,
                leg.revised.battery_after_flight_wh,
                ENERGY_TOL_WH,
            ),
            "battery_after_service": (
                leg.baseline.battery_after_service_wh,
                leg.revised.battery_after_service_wh,
                ENERGY_TOL_WH,
            ),
            "reserve_margin": (
                leg.baseline.reserve_margin_wh,
                leg.revised.reserve_margin_wh,
                ENERGY_TOL_WH,
            ),
            "deadline_slack": (
                leg.baseline.deadline_slack_h,
                leg.revised.deadline_slack_h,
                TIME_TOL_H,
            ),
        }
        for name, (baseline, revised, tolerance) in quantity_specs.items():
            node[name] = add_vertex(
                f"{prefix}:quantity:{name}",
                "quantity",
                prefix,
                baseline,
                revised,
                tolerance=tolerance,
            )

        node["reason"] = add_vertex(
            f"{prefix}:status:reason",
            "status",
            prefix,
            leg.baseline.reason_codes,
            leg.revised.reason_codes,
        )
        node["deadline"] = add_vertex(
            f"{prefix}:status:deadline",
            "status",
            prefix,
            leg.baseline.deadline_met,
            leg.revised.deadline_met,
        )
        node["status"] = add_vertex(
            f"{prefix}:status:leg",
            "status",
            prefix,
            leg.baseline.status.value,
            leg.revised.status.value,
        )

        for parent in (node["departure"], node["payload"]):
            add_edge(parent, node["evaluation"])
        add_edge(node["evaluation"], node["travel_time"])
        add_edge(node["evaluation"], node["energy"])
        add_edge(node["evaluation"], node["reason"])
        add_edge(node["departure"], node["arrival"])
        add_edge(node["travel_time"], node["arrival"])
        add_edge(node["battery"], node["battery_after_flight"])
        add_edge(node["energy"], node["battery_after_flight"])
        add_edge(node["battery_after_flight"], node["battery_after_service"])
        add_edge(node["battery_after_service"], node["reserve_margin"])
        add_edge(node["arrival"], node["deadline_slack"])
        add_edge(node["deadline_slack"], node["deadline"])
        for parent in (
            node["evaluation"],
            node["reason"],
            node["battery_after_flight"],
            node["battery_after_service"],
            node["reserve_margin"],
        ):
            add_edge(parent, node["status"])

        changes_by_domain: dict[str, list[EnvironmentalChange]] = {}
        for change in leg.direct_changes:
            changes_by_domain.setdefault(change.domain, []).append(change)
        for domain, domain_changes in sorted(changes_by_domain.items()):
            condition_id = add_vertex(
                f"{prefix}:environment:{domain}",
                "environment",
                prefix,
                tuple(
                    (change.key, change.interval, _jsonable(change.before))
                    for change in domain_changes
                ),
                tuple(
                    (change.key, change.interval, _jsonable(change.after))
                    for change in domain_changes
                ),
            )
            seed_ids.append(condition_id)
            add_edge(condition_id, node["evaluation"])
            for change in domain_changes:
                change_id = change_ids[id(change)]
                seed_ids.append(change_id)
                add_edge(change_id, condition_id)
                add_edge(change_id, node["evaluation"])

        previous = previous_by_uav.get(leg.uav_idx)
        if previous is not None:
            add_edge(previous["arrival"], node["departure"])
            add_edge(previous["status"], node["departure"])
            add_edge(previous["battery_after_service"], node["battery"])
            add_edge(previous["status"], node["battery"])
            add_edge(previous["payload"], node["payload"])
            add_edge(previous["status"], node["payload"])
        previous_by_uav[leg.uav_idx] = node

    ordered_seeds = tuple(dict.fromkeys(seed_ids))
    structural_set = _reachable_vertices(ordered_seeds, edges)
    structural = tuple(
        vertex.vertex_id for vertex in vertices
        if vertex.vertex_id in structural_set
    )
    material = tuple(
        vertex.vertex_id for vertex in vertices
        if vertex.vertex_id in structural_set
        and vertex.kind != "packet_change"
        and vertex.materially_changed
    )
    operational_material = tuple(
        vertex.vertex_id for vertex in vertices
        if vertex.vertex_id in material
        and vertex.kind not in {"packet_change", "environment"}
    )
    reportable_set = frozenset((*ordered_seeds, *material))
    reportable = tuple(
        vertex.vertex_id for vertex in vertices
        if vertex.vertex_id in reportable_set
    )
    ids = tuple(vertex.vertex_id for vertex in vertices)
    return DisturbanceDependencyGraph(
        vertices=tuple(vertices),
        edges=tuple(edges),
        seed_vertex_ids=ordered_seeds,
        structural_closure_vertex_ids=structural,
        material_vertex_ids=material,
        operational_material_vertex_ids=operational_material,
        reportable_vertex_ids=reportable,
        is_acyclic=_is_acyclic(ids, edges),
    )


def _summary(
    legs: Sequence[LegImpact],
    graph: DisturbanceDependencyGraph,
) -> Mapping[str, Any]:
    energy_deltas = [leg.delta_energy_wh for leg in legs if leg.delta_energy_wh is not None]
    arrival_deltas = [
        leg.delta_arrival_time_h
        for leg in legs
        if leg.delta_arrival_time_h is not None
    ]
    return MappingProxyType({
        "remaining_leg_count": len(legs),
        "directly_affected_leg_count": sum(leg.directly_affected for leg in legs),
        "propagated_leg_count": sum(leg.propagated for leg in legs),
        "mixed_influence_leg_count": sum(
            leg.directly_affected and leg.propagated for leg in legs
        ),
        "affected_leg_count": len(graph.affected_leg_ids),
        "baseline_infeasible_leg_count": sum(
            leg.baseline.status is ProjectionStatus.INFEASIBLE for leg in legs
        ),
        "revised_infeasible_leg_count": sum(
            leg.revised.status is ProjectionStatus.INFEASIBLE for leg in legs
        ),
        "baseline_undetermined_leg_count": sum(
            leg.baseline.status is ProjectionStatus.UNDETERMINED for leg in legs
        ),
        "revised_undetermined_leg_count": sum(
            leg.revised.status is ProjectionStatus.UNDETERMINED for leg in legs
        ),
        "baseline_deadline_miss_count": sum(
            leg.baseline.deadline_met is False for leg in legs
        ),
        "revised_deadline_miss_count": sum(
            leg.revised.deadline_met is False for leg in legs
        ),
        "total_known_flight_energy_delta_wh": float(sum(energy_deltas)),
        "maximum_known_arrival_delta_h": (
            float(max(abs(value) for value in arrival_deltas))
            if arrival_deltas else None
        ),
    })


def diagnose_environmental_packet_update(
    scenario: Any,
    incumbent_plan: Mapping[Any, Mapping[str, Any]],
    epoch: Any,
    previous_packet: EnvironmentalPacket,
    received_packet: EnvironmentalPacket,
    deadlines_h: Optional[Mapping[Any, float]] = None,
) -> DisturbanceImpactClosure:
    """Return a visible-information closure for one received packet update."""
    epoch_time = _validate_packet_update(epoch, previous_packet, received_packet)
    transition = compare_environmental_packets(previous_packet, received_packet)
    params = scenario.env_params()
    entries = _normalise_plan(scenario, incumbent_plan)
    _validate_deadlines(deadlines_h)
    deadlines = deadlines_h
    legs = []
    for entry in entries:
        state = _snapshot_uav(epoch, entry.uav_idx)
        initial_payload = _vector(
            getattr(state, "payload", np.zeros(N_COMMODITIES)),
            f"snapshot payload for {entry.uav_id}",
        )
        if _mode_name(state) in {"depot", "preparing", "ready"} and np.all(
            initial_payload <= STATE_TOL
        ):
            initial_payload = entry.load.copy()
        battery = float(getattr(state, "battery"))
        if not math.isfinite(battery) or battery < 0.0:
            raise ValueError(f"snapshot battery for {entry.uav_id} must be finite and nonnegative")
        baseline_state = _ProjectionState(epoch_time, battery, initial_payload.copy())
        revised_state = _ProjectionState(epoch_time, battery, initial_payload.copy())
        mass_vector = np.asarray(params.commodities.w_k)
        has_prior_leg = False
        for leg in _remaining_legs(scenario, epoch, entry):
            deadline_h = _deadline(
                deadlines,
                leg.destination,
                float(params.mission.T),
            )
            baseline_entering = baseline_state
            revised_entering = revised_state
            baseline_payload_mass_kg = (
                None if baseline_entering.failed else float(np.dot(
                    mass_vector,
                    baseline_entering.payload,
                ))
            )
            revised_payload_mass_kg = (
                None if revised_entering.failed else float(np.dot(
                    mass_vector,
                    revised_entering.payload,
                ))
            )
            payload_mass_kg = next(
                (
                    value for value in (
                        baseline_payload_mass_kg,
                        revised_payload_mass_kg,
                    )
                    if value is not None
                ),
                float(np.dot(mass_vector, baseline_entering.payload)),
            )
            propagated = bool(
                has_prior_leg
                and _entering_state_changed(
                    baseline_entering,
                    revised_entering,
                    mass_vector,
                )
            )
            baseline, baseline_state = _project_leg(
                baseline_state,
                leg,
                entry,
                scenario,
                params,
                previous_packet,
                deadline_h,
            )
            revised, revised_state = _project_leg(
                revised_state,
                leg,
                entry,
                scenario,
                params,
                received_packet,
                deadline_h,
            )
            direct_changes = _direct_changes(
                leg,
                baseline,
                revised,
                previous_packet,
                received_packet,
                transition,
            )
            directly_affected = bool(direct_changes)
            impact = LegImpact(
                leg_id=f"{leg.uav_id}:leg-{leg.route_index:03d}",
                uav_id=leg.uav_id,
                uav_idx=leg.uav_idx,
                route_index=leg.route_index,
                origin=leg.origin,
                destination=leg.destination,
                geometry=leg.geometry,
                payload_mass_kg=payload_mass_kg,
                directly_affected=directly_affected,
                direct_changes=direct_changes,
                propagated=propagated,
                baseline=baseline,
                revised=revised,
                delta_arrival_time_h=_known_delta(
                    baseline.arrival_time_h,
                    revised.arrival_time_h,
                ),
                delta_travel_time_h=_known_delta(
                    baseline.travel_time_h,
                    revised.travel_time_h,
                ),
                delta_energy_wh=_known_delta(
                    baseline.energy_wh,
                    revised.energy_wh,
                ),
                delta_deadline_slack_h=_known_delta(
                    baseline.deadline_slack_h,
                    revised.deadline_slack_h,
                ),
                baseline_payload_mass_kg=baseline_payload_mass_kg,
                revised_payload_mass_kg=revised_payload_mass_kg,
            )
            legs.append(impact)
            has_prior_leg = True
    graph = _dependency_graph(legs, transition)
    return DisturbanceImpactClosure(
        epoch_time_h=epoch_time,
        previous_packet_id=previous_packet.packet_id,
        received_packet_id=received_packet.packet_id,
        transition=transition,
        legs=tuple(legs),
        dependency_graph=graph,
        summary=_summary(legs, graph),
    )


diagnose_packet_update = diagnose_environmental_packet_update


__all__ = [
    "DependencyEdge",
    "DependencyVertex",
    "DisturbanceDependencyGraph",
    "DisturbanceImpactClosure",
    "LegImpact",
    "LegProjection",
    "ProjectionStatus",
    "diagnose_environmental_packet_update",
    "diagnose_packet_update",
]
