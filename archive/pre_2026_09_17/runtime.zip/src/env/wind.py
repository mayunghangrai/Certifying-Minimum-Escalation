"""Global wind packets and compatibility adapters for legacy scenarios."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterable, Mapping, Optional, Sequence, Tuple

import numpy as np


_EPS = 1e-9


@dataclass(frozen=True)
class WindForecastPoint:
    """One global 2D wind estimate at a forecast-valid time."""

    valid_time_h: float
    u_kmh: float
    v_kmh: float

    def __post_init__(self) -> None:
        values = (self.valid_time_h, self.u_kmh, self.v_kmh)
        if not all(math.isfinite(float(value)) for value in values):
            raise ValueError("wind forecast point values must be finite")

    def to_dict(self) -> dict:
        return {
            "valid_time_h": float(self.valid_time_h),
            "u_kmh": float(self.u_kmh),
            "v_kmh": float(self.v_kmh),
        }

    @classmethod
    def from_dict(cls, payload: Mapping) -> "WindForecastPoint":
        return cls(
            valid_time_h=float(payload["valid_time_h"]),
            u_kmh=float(payload["u_kmh"]),
            v_kmh=float(payload["v_kmh"]),
        )


@dataclass(frozen=True)
class WindForecastPacket:
    """A forecast received atomically at ``issued_at_h``."""

    issued_at_h: float
    horizon_h: float
    points: Tuple[WindForecastPoint, ...]

    def __post_init__(self) -> None:
        issued_at = float(self.issued_at_h)
        horizon = float(self.horizon_h)
        points = tuple(self.points)
        object.__setattr__(self, "issued_at_h", issued_at)
        object.__setattr__(self, "horizon_h", horizon)
        object.__setattr__(self, "points", points)
        if not math.isfinite(issued_at) or issued_at < 0.0:
            raise ValueError("issued_at_h must be finite and nonnegative")
        if not math.isfinite(horizon) or horizon <= 0.0:
            raise ValueError("horizon_h must be finite and positive")
        if not points:
            raise ValueError("a wind forecast packet requires at least one point")
        times = [float(point.valid_time_h) for point in points]
        if any(later <= earlier for earlier, later in zip(times[:-1], times[1:])):
            raise ValueError("wind forecast valid times must be strictly increasing")
        if times[0] < issued_at - _EPS:
            raise ValueError("forecast points cannot precede the packet issue time")
        if times[-1] > issued_at + horizon + _EPS:
            raise ValueError("forecast points cannot exceed the declared horizon")

    @property
    def valid_from_h(self) -> float:
        return float(self.points[0].valid_time_h)

    @property
    def valid_until_h(self) -> float:
        return float(self.points[-1].valid_time_h)

    def to_dict(self) -> dict:
        return {
            "issued_at_h": float(self.issued_at_h),
            "horizon_h": float(self.horizon_h),
            "points": [point.to_dict() for point in self.points],
        }

    @classmethod
    def from_dict(cls, payload: Mapping) -> "WindForecastPacket":
        return cls(
            issued_at_h=float(payload["issued_at_h"]),
            horizon_h=float(payload["horizon_h"]),
            points=tuple(
                WindForecastPoint.from_dict(point)
                for point in payload.get("points", [])
            ),
        )


def _keyframe_values(
    keyframes: Iterable[Sequence[float] | WindForecastPoint],
) -> Tuple[Tuple[float, float, float], ...]:
    values = []
    for keyframe in keyframes:
        if isinstance(keyframe, WindForecastPoint):
            values.append((
                float(keyframe.valid_time_h),
                float(keyframe.u_kmh),
                float(keyframe.v_kmh),
            ))
        else:
            if len(keyframe) != 3:
                raise ValueError("wind keyframes must be [time_h, u_kmh, v_kmh]")
            values.append(tuple(float(value) for value in keyframe))
    if not values:
        raise ValueError("at least one wind keyframe is required")
    if any(
        later[0] <= earlier[0]
        for earlier, later in zip(values[:-1], values[1:])
    ):
        raise ValueError("wind keyframe times must be strictly increasing")
    return tuple(values)


def interpolate_wind_vector(
    keyframes: Iterable[Sequence[float] | WindForecastPoint],
    time_h: float,
) -> np.ndarray:
    """Linearly interpolate east/north wind components and clamp at endpoints."""
    values = _keyframe_values(keyframes)
    time_h = float(time_h)
    if not math.isfinite(time_h):
        raise ValueError("wind query time must be finite")
    if time_h <= values[0][0]:
        return np.asarray(values[0][1:], dtype=float)
    if time_h >= values[-1][0]:
        return np.asarray(values[-1][1:], dtype=float)
    for left, right in zip(values[:-1], values[1:]):
        if left[0] <= time_h <= right[0]:
            weight = (time_h - left[0]) / (right[0] - left[0])
            return np.asarray(left[1:], dtype=float) + weight * (
                np.asarray(right[1:], dtype=float)
                - np.asarray(left[1:], dtype=float)
            )
    raise RuntimeError("wind interpolation interval was not found")


def truth_wind_vector(wind_spec: Mapping, time_h: float) -> np.ndarray:
    """Oracle-only interpolation of the scenario's latent truth keyframes."""
    keyframes = wind_spec.get("truth_keyframes")
    if not keyframes:
        return np.zeros(2, dtype=float)
    return interpolate_wind_vector(keyframes, time_h)


def truth_keyframe_times(wind_spec: Mapping) -> List[float]:
    """Sorted truth-keyframe timestamps of a wind spec (empty when calm)."""
    if not wind_spec:
        return []
    keyframes = wind_spec.get("truth_keyframes") or []
    return sorted(float(row[0]) for row in keyframes)


def forecast_packets_from_spec(wind_spec: Mapping) -> Tuple[WindForecastPacket, ...]:
    """Deserialize packet wind timelines from canonical or legacy specs."""
    if "environment_packets" in wind_spec:
        packets = []
        for payload in wind_spec.get("environment_packets", []):
            points = payload.get(
                "wind", {}
            ).get("points", payload.get("wind_points", ()))
            packets.append(WindForecastPacket(
                issued_at_h=float(payload["issued_at_h"]),
                horizon_h=float(payload["valid_until_h"]) - float(payload["issued_at_h"]),
                points=tuple(
                    point if isinstance(point, WindForecastPoint)
                    else WindForecastPoint.from_dict(point)
                    for point in points
                ),
            ))
        return tuple(sorted(packets, key=lambda packet: packet.issued_at_h))
    packets = tuple(
        WindForecastPacket.from_dict(payload)
        for payload in wind_spec.get("forecast_packets", [])
    )
    return tuple(sorted(packets, key=lambda packet: packet.issued_at_h))


class OnlineWindForecast:
    """Latest forecast packet received by the controller, with no extrapolation."""

    def __init__(self) -> None:
        self._latest: Optional[WindForecastPacket] = None
        self._latest_environment = None

    @property
    def latest_packet(self) -> Optional[WindForecastPacket]:
        return self._latest

    @property
    def latest_environment_packet(self):
        """Return the latest canonical packet when one was received."""
        return self._latest_environment

    @property
    def issued_at_h(self) -> Optional[float]:
        return None if self._latest is None else self._latest.issued_at_h

    @property
    def valid_until_h(self) -> Optional[float]:
        return None if self._latest is None else self._latest.valid_until_h

    def receive(self, packet: WindForecastPacket, now_h: float) -> bool:
        from .environment import EnvironmentalPacket

        if isinstance(packet, EnvironmentalPacket):
            canonical_packet = packet
            packet = WindForecastPacket(
                issued_at_h=canonical_packet.issued_at_h,
                horizon_h=canonical_packet.valid_until_h - canonical_packet.issued_at_h,
                points=tuple(canonical_packet.wind),
            )
        else:
            canonical_packet = None
        now_h = float(now_h)
        if now_h < packet.issued_at_h - _EPS:
            raise ValueError("cannot receive a wind forecast before its issue time")
        if self._latest is not None \
                and packet.issued_at_h <= self._latest.issued_at_h + _EPS:
            return False
        self._latest = packet
        self._latest_environment = canonical_packet
        return True

    def covers(self, start_time_h: float, end_time_h: float) -> bool:
        if self._latest is None:
            return False
        start = float(start_time_h)
        end = float(end_time_h)
        return (
            start <= end
            and start >= self._latest.valid_from_h - _EPS
            and end <= self._latest.valid_until_h + _EPS
        )

    def vector_at(self, valid_time_h: float) -> Optional[np.ndarray]:
        time_h = float(valid_time_h)
        if not self.covers(time_h, time_h):
            return None
        assert self._latest is not None
        return interpolate_wind_vector(self._latest.points, time_h)

    def wind_at(self, valid_time_h: float) -> Optional[np.ndarray]:
        """Canonical-name alias for the currently received packet wind."""
        return self.vector_at(valid_time_h)
