"""Operational and true polygonal airspace state.

Mission coordinates are local Cartesian kilometres, matching the existing
physics model.  Public airspace buffers remain expressed in metres and are
converted at the geometry boundary.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple, Union

import numpy as np
from shapely.geometry import LineString, Point, Polygon
from shapely.geometry.base import BaseGeometry


METRES_PER_KILOMETRE = 1000.0
PolygonPoints = List[Tuple[float, float]]
Region = Union["NoFlyZone", "HazardRegion"]


def _polygon(points: Sequence[Sequence[float]]) -> Polygon:
    geometry = Polygon(points)
    if geometry.is_empty or not geometry.is_valid or geometry.area <= 0.0:
        raise ValueError("airspace polygon must be a valid non-empty polygon")
    return geometry


def _points(points: Sequence[Sequence[float]]) -> PolygonPoints:
    return [(float(point[0]), float(point[1])) for point in points]


@dataclass
class NoFlyZone:
    """A hard geometric exclusion region."""

    id: str
    polygon: PolygonPoints
    active_from: float
    active_until: Optional[float]
    version: int = 1
    safety_buffer_m: float = 0.0

    def __post_init__(self) -> None:
        self.polygon = _points(self.polygon)
        _polygon(self.polygon)
        if self.active_until is not None and self.active_until < self.active_from:
            raise ValueError("active_until must not precede active_from")
        if self.safety_buffer_m < 0.0:
            raise ValueError("safety_buffer_m must be nonnegative")

    def geometry(self) -> Polygon:
        return _polygon(self.polygon)

    def effective_geometry(self) -> BaseGeometry:
        return self.geometry().buffer(self.safety_buffer_m / METRES_PER_KILOMETRE)


@dataclass
class HazardRegion:
    """A traversable risk region until its severity reaches ``hard_threshold``."""

    id: str
    polygon: PolygonPoints
    severity: float
    hazard_type: str
    active_from: float
    active_until: Optional[float]
    version: int = 1
    safety_buffer_m: float = 0.0
    hard_threshold: float = 1.0

    def __post_init__(self) -> None:
        self.polygon = _points(self.polygon)
        _polygon(self.polygon)
        if not 0.0 <= self.severity <= 1.0:
            raise ValueError("hazard severity must be in [0, 1]")
        if not 0.0 <= self.hard_threshold <= 1.0:
            raise ValueError("hard_threshold must be in [0, 1]")
        if self.active_until is not None and self.active_until < self.active_from:
            raise ValueError("active_until must not precede active_from")
        if self.safety_buffer_m < 0.0:
            raise ValueError("safety_buffer_m must be nonnegative")

    def geometry(self) -> Polygon:
        return _polygon(self.polygon)

    def effective_geometry(self) -> BaseGeometry:
        return self.geometry().buffer(self.safety_buffer_m / METRES_PER_KILOMETRE)

    @property
    def is_hard(self) -> bool:
        return self.severity >= self.hard_threshold


@dataclass
class AirspaceUpdateEvent:
    """One route-information update revealed at ``time_h``."""

    time_h: float
    region_id: str
    region_type: str
    update_type: str
    new_polygon: Optional[PolygonPoints] = None
    new_severity: Optional[float] = None
    version: int = 1
    safety_buffer_m: Optional[float] = None
    hard_threshold: Optional[float] = None

    def __post_init__(self) -> None:
        self.region_type = str(self.region_type).lower()
        self.update_type = str(self.update_type).upper()
        if self.region_type not in {"no_fly", "hazard"}:
            raise ValueError("region_type must be 'no_fly' or 'hazard'")
        if self.update_type not in {
            "ACTIVATE", "DEACTIVATE", "EXPAND", "SHRINK", "MOVE", "SEVERITY_CHANGE"
        }:
            raise ValueError("unsupported airspace update_type")
        self.time_h = float(self.time_h)
        if not np.isfinite(self.time_h) or self.time_h < 0.0:
            raise ValueError("airspace time_h must be finite and nonnegative")
        if self.new_polygon is not None:
            self.new_polygon = _points(self.new_polygon)
            _polygon(self.new_polygon)
        if self.new_severity is not None and not 0.0 <= self.new_severity <= 1.0:
            raise ValueError("new_severity must be in [0, 1]")
        if self.safety_buffer_m is not None and self.safety_buffer_m < 0.0:
            raise ValueError("safety_buffer_m must be nonnegative")
        if self.hard_threshold is not None and not 0.0 <= self.hard_threshold <= 1.0:
            raise ValueError("hard_threshold must be in [0, 1]")


class AirspaceMap:
    """Versioned received-airspace map used by the tactical controller.

    The map only changes through :meth:`apply_update`; callers construct a
    separate instance for physical truth and operational information.  An
    operational map may start empty: the first received activation registers
    its region from the geometry carried by the update itself.
    """

    def __init__(
        self,
        no_fly_zones: Iterable[NoFlyZone] = (),
        hazard_regions: Iterable[HazardRegion] = (),
    ) -> None:
        self._regions: Dict[str, Region] = {}
        self._active: Dict[str, bool] = {}
        self._region_versions: Dict[str, int] = {}
        self._hard_geometry_cache: Dict[
            Tuple[int, Tuple[str, ...]], List[BaseGeometry]
        ] = {}
        self._hard_margin_geometry_cache: Dict[
            Tuple[Tuple[int, Tuple[str, ...]], float], List[BaseGeometry]
        ] = {}
        self._soft_geometry_cache: Dict[
            Tuple[int, Tuple[str, ...]], List[Tuple[HazardRegion, BaseGeometry]]
        ] = {}
        self.version = 0
        for region in [*no_fly_zones, *hazard_regions]:
            if region.id in self._regions:
                raise ValueError(f"duplicate airspace region id: {region.id}")
            self._regions[region.id] = replace(region)
            self._active[region.id] = False
            self._region_versions[region.id] = 0

    @classmethod
    def from_environment_packet(
        cls,
        packet: Any,
        *,
        received_at_h: Optional[float] = None,
    ) -> "AirspaceMap":
        """Adapt packet polygons to the legacy geometry query interface."""
        from .environment import EnvironmentalPacket

        if not isinstance(packet, EnvironmentalPacket):
            packet = EnvironmentalPacket.from_dict(packet)
        no_fly_zones = [
            NoFlyZone(
                id=region.id,
                polygon=list(region.geometry),
                active_from=region.valid_from_h,
                active_until=region.valid_until_h,
                safety_buffer_m=region.safety_buffer_m,
            )
            for region in packet.airspace
        ]
        hazards = [
            HazardRegion(
                id=region.id,
                polygon=list(region.geometry),
                severity=1.0 if region.is_hard else 0.5,
                hazard_type="packet_weather",
                active_from=region.valid_from_h,
                active_until=region.valid_until_h,
                safety_buffer_m=region.safety_buffer_m,
                hard_threshold=0.8,
            )
            for region in packet.weather
        ]
        result = cls(no_fly_zones=no_fly_zones, hazard_regions=hazards)
        received_at = (
            packet.issued_at_h
            if received_at_h is None
            else float(received_at_h)
        )
        for region in [*no_fly_zones, *hazards]:
            if region.active_from <= received_at + 1e-12:
                result.apply_update(activation_update(region))
        return result

    def corridor_state(
        self,
        points: Sequence[Sequence[float]],
        time_h: float,
        extra_margin_km: float = 0.0,
    ) -> str:
        """Derive a corridor state directly from current polygon geometry."""
        if self.hard_intersects(points, time_h, extra_margin_km=extra_margin_km):
            return "BLOCKED"
        if self.path_hazard_risk(points, time_h) > 1e-12:
            return "SOFT"
        return "CLEAR"

    @property
    def region_ids(self) -> Tuple[str, ...]:
        return tuple(self._regions)

    def clone(self) -> "AirspaceMap":
        clone = AirspaceMap()
        clone._regions = {key: replace(value) for key, value in self._regions.items()}
        clone._active = dict(self._active)
        clone._region_versions = dict(self._region_versions)
        clone._hard_geometry_cache = {
            key: list(value) for key, value in self._hard_geometry_cache.items()
        }
        clone._hard_margin_geometry_cache = {
            key: list(value) for key, value in self._hard_margin_geometry_cache.items()
        }
        clone._soft_geometry_cache = {
            key: list(value) for key, value in self._soft_geometry_cache.items()
        }
        clone.version = self.version
        return clone

    def region(self, region_id: str) -> Region:
        return self._regions[region_id]

    def is_active(self, region_id: str, t: float) -> bool:
        region = self._regions[region_id]
        if not self._active.get(region_id, False):
            return False
        if t + 1e-12 < region.active_from:
            return False
        return region.active_until is None or t <= region.active_until + 1e-12

    def active_regions(self, t: float) -> List[Region]:
        return [
            region for region_id, region in self._regions.items()
            if self.is_active(region_id, t)
        ]

    def hard_state_key(self, t: float) -> Tuple[int, Tuple[str, ...]]:
        """Identify the received hard geometry active at one epoch."""
        active = tuple(
            region_id
            for region_id, region in self._regions.items()
            if self.is_active(region_id, t)
            and (isinstance(region, NoFlyZone) or region.is_hard)
        )
        return int(self.version), active

    def soft_state_key(self, t: float) -> Tuple[int, Tuple[str, ...]]:
        """Identify the received traversable hazards active at one epoch."""
        active = tuple(
            region_id
            for region_id, region in self._regions.items()
            if self.is_active(region_id, t)
            and isinstance(region, HazardRegion)
            and not region.is_hard
        )
        return int(self.version), active

    def hard_geometries(self, t: float) -> List[BaseGeometry]:
        key = self.hard_state_key(t)
        if key not in self._hard_geometry_cache:
            self._hard_geometry_cache[key] = [
                self._regions[region_id].effective_geometry()
                for region_id in key[1]
            ]
        return self._hard_geometry_cache[key]

    def _hard_geometries_with_margin(
        self,
        t: float,
        extra_margin_km: float,
    ) -> List[BaseGeometry]:
        if extra_margin_km <= 0.0:
            return self.hard_geometries(t)
        key = (self.hard_state_key(t), round(float(extra_margin_km), 12))
        if key not in self._hard_margin_geometry_cache:
            self._hard_margin_geometry_cache[key] = [
                geometry.buffer(extra_margin_km)
                for geometry in self.hard_geometries(t)
            ]
        return self._hard_margin_geometry_cache[key]

    def soft_hazards(self, t: float) -> List[HazardRegion]:
        return [
            region for region in self.active_regions(t)
            if isinstance(region, HazardRegion) and not region.is_hard
        ]

    def _soft_geometries(self, t: float) -> List[Tuple[HazardRegion, BaseGeometry]]:
        key = self.soft_state_key(t)
        if key not in self._soft_geometry_cache:
            self._soft_geometry_cache[key] = [
                (
                    self._regions[region_id],
                    self._regions[region_id].effective_geometry(),
                )
                for region_id in key[1]
            ]
        return self._soft_geometry_cache[key]

    def hard_intersects(
        self,
        points: Sequence[Sequence[float]],
        t: float,
        extra_margin_km: float = 0.0,
    ) -> bool:
        if len(points) < 2:
            return False
        line = LineString(points)
        return any(
            line.intersects(geometry)
            for geometry in self._hard_geometries_with_margin(t, extra_margin_km)
        )

    def segment_is_safe(
        self,
        origin: Sequence[float],
        destination: Sequence[float],
        t: float,
        extra_margin_km: float = 0.0,
    ) -> bool:
        origin_array = np.asarray(origin, dtype=float)
        destination_array = np.asarray(destination, dtype=float)
        line: BaseGeometry = (
            Point(origin_array)
            if float(np.linalg.norm(destination_array - origin_array)) <= 1e-12
            else LineString([origin_array, destination_array])
        )
        for geometry in self._hard_geometries_with_margin(t, extra_margin_km):
            if line.intersects(geometry):
                return False
        return True

    def hazard_intensity(self, position: Sequence[float], t: float) -> float:
        soft_geometries = self._soft_geometries(t)
        if not soft_geometries:
            return 0.0
        point = Point(position)
        return float(sum(
            region.severity
            for region, geometry in soft_geometries
            if geometry.covers(point)
        ))

    def hazard_intensities(
        self,
        positions: Sequence[Sequence[float]],
        t: float,
    ) -> np.ndarray:
        """Evaluate received soft-hazard intensity for a batch of points."""
        points = np.asarray(positions, dtype=float)
        if points.size == 0:
            return np.zeros(points.shape[:-1], dtype=float)
        soft_geometries = self._soft_geometries(t)
        if not soft_geometries:
            return np.zeros(points.shape[:-1], dtype=float)
        flat = points.reshape(-1, 2)
        values = np.zeros(len(flat), dtype=float)
        for index, position in enumerate(flat):
            point = Point(position)
            values[index] = sum(
                region.severity
                for region, geometry in soft_geometries
                if geometry.covers(point)
            )
        return values.reshape(points.shape[:-1])

    def path_hazard_risk(self, points: Sequence[Sequence[float]], t: float) -> float:
        """Line integral of received soft-hazard intensity along a polyline."""
        if not self._soft_geometries(t) or len(points) < 2:
            return 0.0
        path = LineString(points)
        if path.is_empty or path.length <= 1e-12:
            return 0.0
        return float(sum(
            float(region.severity) * float(path.intersection(geometry).length)
            for region, geometry in self._soft_geometries(t)
        ))

    def _register_received_region(self, update: AirspaceUpdateEvent) -> None:
        if update.update_type == "DEACTIVATE" or update.new_polygon is None:
            raise KeyError(f"unknown airspace region: {update.region_id}")
        if update.region_type == "no_fly":
            region: Region = NoFlyZone(
                id=update.region_id,
                polygon=update.new_polygon,
                active_from=float(update.time_h),
                active_until=None,
                version=int(update.version),
                safety_buffer_m=float(update.safety_buffer_m or 0.0),
            )
        else:
            if update.new_severity is None:
                raise ValueError("first received hazard update requires severity")
            region = HazardRegion(
                id=update.region_id,
                polygon=update.new_polygon,
                severity=float(update.new_severity),
                hazard_type="reported_hazard",
                active_from=float(update.time_h),
                active_until=None,
                version=int(update.version),
                safety_buffer_m=float(update.safety_buffer_m or 0.0),
                hard_threshold=float(
                    1.0 if update.hard_threshold is None else update.hard_threshold
                ),
            )
        self._regions[update.region_id] = region
        self._active[update.region_id] = False
        self._region_versions[update.region_id] = 0

    def apply_update(self, update: AirspaceUpdateEvent) -> bool:
        """Apply one already received update and increment the map version.

        Returns ``False`` for a stale update that cannot change the current
        operational map.  Equal version activation/deactivation is permitted
        because an initial region definition starts at revision zero.
        """
        if update.region_id not in self._regions:
            self._register_received_region(update)
        region = self._regions[update.region_id]
        expected_type = "no_fly" if isinstance(region, NoFlyZone) else "hazard"
        if update.region_type != expected_type:
            raise ValueError("airspace update region_type does not match definition")
        if update.version < self._region_versions[update.region_id]:
            return False

        changed = False
        if update.update_type == "DEACTIVATE":
            changed = self._active[update.region_id]
            self._active[update.region_id] = False
        else:
            if not self._active[update.region_id]:
                changed = True
                self._active[update.region_id] = True
            changes = {}
            if update.new_polygon is not None and update.new_polygon != region.polygon:
                changes["polygon"] = _points(update.new_polygon)
            if update.safety_buffer_m is not None and update.safety_buffer_m != region.safety_buffer_m:
                changes["safety_buffer_m"] = float(update.safety_buffer_m)
            if isinstance(region, HazardRegion):
                if update.new_severity is not None and update.new_severity != region.severity:
                    changes["severity"] = float(update.new_severity)
                if update.hard_threshold is not None and update.hard_threshold != region.hard_threshold:
                    changes["hard_threshold"] = float(update.hard_threshold)
            if changes:
                self._regions[update.region_id] = replace(region, **changes)
                changed = True

        self._region_versions[update.region_id] = max(
            self._region_versions[update.region_id], update.version
        )
        if changed:
            self.version += 1
        self._hard_geometry_cache.clear()
        self._hard_margin_geometry_cache.clear()
        self._soft_geometry_cache.clear()
        return changed


def activation_update(region: Region) -> AirspaceUpdateEvent:
    """Create the initial observable activation for a scenario region."""
    return AirspaceUpdateEvent(
        time_h=float(region.active_from),
        region_id=region.id,
        region_type="no_fly" if isinstance(region, NoFlyZone) else "hazard",
        update_type="ACTIVATE",
        new_polygon=_points(region.polygon),
        new_severity=region.severity if isinstance(region, HazardRegion) else None,
        version=int(region.version),
        safety_buffer_m=float(region.safety_buffer_m),
        hard_threshold=(
            float(region.hard_threshold)
            if isinstance(region, HazardRegion)
            else None
        ),
    )


def deactivation_update(region: Region) -> Optional[AirspaceUpdateEvent]:
    """Create a separately observable expiry when a region has an end time."""
    if region.active_until is None:
        return None
    return AirspaceUpdateEvent(
        time_h=float(region.active_until),
        region_id=region.id,
        region_type="no_fly" if isinstance(region, NoFlyZone) else "hazard",
        update_type="DEACTIVATE",
        version=int(region.version) + 1,
    )
