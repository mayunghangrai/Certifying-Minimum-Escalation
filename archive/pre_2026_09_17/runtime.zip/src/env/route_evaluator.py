"""Pure feasibility and cost evaluation for a caller-supplied polyline.

This module deliberately contains no route construction, waypoint repair, or
fallback logic.  It only evaluates the points supplied by an external method.

Travel time and energy both follow the constant-airspeed wind model, so a
rolling forecast revision directly changes a candidate route's ETA and its
battery feasibility.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Mapping, Optional, Sequence, Tuple

import numpy as np
from shapely.geometry import LineString, Polygon

from .airspace import AirspaceMap
from .energy import InfeasibilityReason, LegEvaluation, evaluate_leg, forecast_route_kinematics
from .environment import AirspaceRestriction, EnvironmentalPacket, WeatherRegion
from .network import NetworkEdge
from .params import EnvParams
from .wind import OnlineWindForecast


_EPS = 1e-9


def _physical_value(
    uav_parameters: Any,
    canonical: str,
    legacy: str,
    default: float,
) -> float:
    if uav_parameters is None:
        return float(default)
    if isinstance(uav_parameters, Mapping):
        value = uav_parameters.get(canonical, uav_parameters.get(legacy, default))
    else:
        value = getattr(
            uav_parameters,
            canonical,
            getattr(uav_parameters, legacy, default),
        )
    return float(value)


@dataclass(frozen=True)
class RouteEvaluation:
    distance_km: float
    duration_h: Optional[float]
    hard_blocked: bool
    hazard_exposure: float
    forecast_covered: bool
    forecast_energy_wh: Optional[float]
    battery_feasible: Optional[bool]
    reasons: Tuple[str, ...]
    feasible: bool = True
    failure_reason: Optional[str] = None
    reason_codes: Tuple[str, ...] = ()
    leg_evaluations: Tuple[LegEvaluation, ...] = ()
    reserve_margin_wh: Optional[float] = None
    arrival_time_h: Optional[float] = None

    @property
    def reason_code(self) -> Optional[InfeasibilityReason]:
        if self.failure_reason is None:
            return None
        try:
            return InfeasibilityReason(str(self.failure_reason))
        except ValueError:
            return None

    def to_dict(self) -> dict:
        return {
            "distance_km": self.distance_km,
            "duration_h": self.duration_h,
            "hard_blocked": self.hard_blocked,
            "hazard_exposure": self.hazard_exposure,
            "forecast_covered": self.forecast_covered,
            "forecast_energy_wh": self.forecast_energy_wh,
            "battery_feasible": self.battery_feasible,
            "reasons": list(self.reasons),
            "feasible": self.feasible,
            "failure_reason": self.failure_reason,
            "reason_codes": list(self.reason_codes),
            "legs": [leg.to_dict() for leg in self.leg_evaluations],
            "reserve_margin_wh": self.reserve_margin_wh,
            "arrival_time_h": self.arrival_time_h,
        }


def _validated_points(points_xy: Sequence[Sequence[float]]) -> np.ndarray:
    try:
        points = np.array(points_xy, dtype=float, copy=True)
    except (TypeError, ValueError) as error:
        raise ValueError("route points must be numeric two-dimensional coordinates") from error
    if points.ndim != 2 or points.shape[1:] != (2,):
        raise ValueError("route points must have shape (n, 2)")
    if len(points) < 2:
        raise ValueError("a route requires at least two points")
    if not np.all(np.isfinite(points)):
        raise ValueError("route points must be finite")
    if np.any(np.linalg.norm(np.diff(points, axis=0), axis=1) <= _EPS):
        raise ValueError("consecutive route points must be distinct")
    return points


def _validated_scalar(name: str, value: float, *, minimum: float = 0.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{name} must be numeric") from error
    if not math.isfinite(number) or number < minimum:
        raise ValueError(f"{name} must be finite and at least {minimum:g}")
    return number


def _legacy_packet(
    forecast: Optional[OnlineWindForecast],
    airspace: Optional[AirspaceMap],
) -> Optional[EnvironmentalPacket]:
    if forecast is None or forecast.latest_packet is None:
        return None
    latest = forecast.latest_packet
    weather = []
    restrictions = []
    if airspace is not None:
        for region in airspace.active_regions(latest.issued_at_h):
            valid_from = max(float(latest.valid_from_h), float(region.active_from))
            valid_until = latest.valid_until_h if region.active_until is None else min(
                float(latest.valid_until_h), float(region.active_until)
            )
            if valid_until <= valid_from + _EPS:
                continue
            geometry = tuple(
                tuple(float(value) for value in point)
                for point in region.polygon
            )
            if hasattr(region, "is_hard"):
                weather.append(WeatherRegion(
                    id=region.id,
                    geometry=geometry,
                    severity="HARD" if region.is_hard else "SOFT",
                    valid_from_h=valid_from,
                    valid_until_h=valid_until,
                    safety_buffer_m=float(region.safety_buffer_m),
                ))
            else:
                restrictions.append(AirspaceRestriction(
                    id=region.id,
                    geometry=geometry,
                    valid_from_h=valid_from,
                    valid_until_h=valid_until,
                    safety_buffer_m=float(region.safety_buffer_m),
                ))
    return EnvironmentalPacket(
        packet_id=f"legacy-adapter-{latest.issued_at_h:g}",
        issued_at_h=float(latest.issued_at_h),
        valid_from_h=float(latest.valid_from_h),
        valid_until_h=float(latest.valid_until_h),
        wind=tuple(latest.points),
        weather=tuple(weather),
        airspace=tuple(restrictions),
    )


def _packet_hazard_exposure(
    points: np.ndarray,
    departure: float,
    packet: EnvironmentalPacket,
) -> float:
    path = LineString(points)
    exposure = 0.0
    for region in packet.weather:
        if region.is_hard or not region.active_at(departure):
            continue
        geometry = Polygon(region.geometry)
        buffer_km = float(region.safety_buffer_m) / 1000.0
        if buffer_km > 0.0:
            geometry = geometry.buffer(buffer_km)
        severity_weight = 0.5 if region.severity == "SOFT" else 1.0
        exposure += severity_weight * float(path.intersection(geometry).length)
    return exposure


def _evaluate_packet_route(
    points: np.ndarray,
    departure: float,
    payloads: Sequence[float],
    packet: EnvironmentalPacket,
    params: EnvParams,
    uav_parameters: Any = None,
) -> tuple[
    Optional[float], Optional[float], bool, bool, tuple[str, ...], float,
    tuple[LegEvaluation, ...], tuple[str, ...]
]:
    current_time = departure
    total_duration = 0.0
    total_energy = 0.0
    hard_blocked = False
    covered = True
    reasons = []
    reason_codes = []
    leg_evaluations = []
    if uav_parameters is None:
        uav_parameters = {
            "nominal_airspeed_kmh": params.physics.v_uav,
            "empty_mass_kg": params.physics.m0,
            "max_payload_kg": params.physics.W_max,
            "battery_capacity_wh": params.physics.B_max,
            "reserve_requirement_wh": params.physics.beta_safe,
            "energy_coefficient_wh_per_km_kg": params.physics.e_c,
            "service_energy_wh": params.physics.e_v,
        }
    for index, (origin, destination) in enumerate(zip(points[:-1], points[1:])):
        edge = NetworkEdge(
            id=f"route-edge-{index:03d}",
            origin=f"route-node-{index:03d}",
            destination=f"route-node-{index + 1:03d}",
            geometry=(tuple(origin), tuple(destination)),
        )
        evaluation = evaluate_leg(
            edge,
            current_time,
            payloads[index],
            uav_parameters,
            packet,
        )
        leg_evaluations.append(evaluation)
        if not evaluation.feasible:
            code = (
                evaluation.reason_code.value
                if evaluation.reason_code is not None
                else str(evaluation.reason or "LEG_INFEASIBLE")
            )
            reason_codes.append(code)
            if code == InfeasibilityReason.INVALID_ENVIRONMENTAL_COVERAGE.value:
                covered = False
            if code in {
                InfeasibilityReason.HARD_WEATHER_BLOCK.value,
                InfeasibilityReason.AIRSPACE_BLOCK.value,
            }:
                hard_blocked = True
            reasons.append(evaluation.reason or "LEG_INFEASIBLE")
            return (
                None,
                None,
                hard_blocked,
                covered,
                tuple(reasons),
                _packet_hazard_exposure(points, departure, packet),
                tuple(leg_evaluations),
                tuple(reason_codes),
            )
        assert evaluation.travel_time_h is not None and evaluation.energy_wh is not None
        total_duration += evaluation.travel_time_h
        total_energy += evaluation.energy_wh
        current_time += evaluation.travel_time_h
    return (
        float(total_duration),
        float(total_energy),
        hard_blocked,
        covered,
        tuple(reasons),
        _packet_hazard_exposure(points, departure, packet),
        tuple(leg_evaluations),
        tuple(reason_codes),
    )


def evaluate_route(
    points_xy: Sequence[Sequence[float]],
    departure_time_h: float,
    payload_mass_kg: float | Sequence[float],
    battery_wh: float,
    airspace: Optional[AirspaceMap],
    forecast: Optional[OnlineWindForecast],
    params: EnvParams,
    *,
    environmental_packet: Optional[EnvironmentalPacket] = None,
    uav_parameters: Any = None,
) -> RouteEvaluation:
    """Evaluate exactly the supplied route against one received environment.

    The environmental_packet argument is the canonical path.  The airspace
    and forecast arguments remain an explicit legacy adapter for older
    scenarios and callers.
    """
    points = _validated_points(points_xy)
    departure = _validated_scalar("departure_time_h", departure_time_h)
    battery = _validated_scalar("battery_wh", battery_wh)
    physical_max_payload = _physical_value(
        uav_parameters,
        "max_payload_kg",
        "W_max",
        params.physics.W_max,
    )
    physical_battery_capacity = _physical_value(
        uav_parameters,
        "battery_capacity_wh",
        "B_max",
        params.physics.B_max,
    )
    physical_reserve = _physical_value(
        uav_parameters,
        "reserve_requirement_wh",
        "beta_safe",
        params.physics.beta_safe,
    )
    if battery > physical_battery_capacity + _EPS:
        raise ValueError("battery_wh exceeds the UAV battery capacity")
    if np.any(points < -_EPS) or np.any(points > params.map.region_km + _EPS):
        raise ValueError("every route point must lie inside the map")

    lengths = np.linalg.norm(np.diff(points, axis=0), axis=1)
    distance = float(np.sum(lengths))
    if np.isscalar(payload_mass_kg):
        payloads = [_validated_scalar("payload_mass_kg", payload_mass_kg)] * len(lengths)
    else:
        try:
            payloads = [
                _validated_scalar("payload_mass_kg", value)
                for value in payload_mass_kg
            ]
        except TypeError as error:
            raise ValueError("payload_mass_kg must be a scalar or per-leg sequence") from error
        if len(payloads) != len(lengths):
            raise ValueError("per-leg payload masses must match route segments")
    if any(payload > physical_max_payload + _EPS for payload in payloads):
        code = InfeasibilityReason.PAYLOAD_CAPACITY_EXCEEDED.value
        return RouteEvaluation(
            distance_km=distance,
            duration_h=None,
            hard_blocked=False,
            hazard_exposure=0.0,
            forecast_covered=True,
            forecast_energy_wh=None,
            battery_feasible=None,
            reasons=("payload capacity exceeded",),
            feasible=False,
            failure_reason=code,
            reason_codes=(code,),
            leg_evaluations=(),
            reserve_margin_wh=None,
            arrival_time_h=None,
        )
    margin_km = params.route_validation.safe_corridor_margin_m / 1000.0
    hard_blocked = False
    exposure = 0.0
    reasons = []
    reason_codes = []
    leg_evaluations: tuple[LegEvaluation, ...] = ()
    external_hard_blocked = False
    packet = environmental_packet or _legacy_packet(forecast, airspace)
    if packet is not None:
        if airspace is not None:
            external_hard_blocked = airspace.hard_intersects(
                points, departure, extra_margin_km=margin_km
            )
            hard_blocked = external_hard_blocked
        (
            duration,
            energy,
            packet_blocked,
            forecast_covered,
            packet_reasons,
            exposure,
            leg_evaluations,
            packet_reason_codes,
        ) = _evaluate_packet_route(
            points,
            departure,
            payloads,
            packet,
            params,
            uav_parameters,
        )
        hard_blocked = hard_blocked or packet_blocked
        reasons.extend(packet_reasons)
        reason_codes.extend(packet_reason_codes)
    else:
        if airspace is not None:
            external_hard_blocked = airspace.hard_intersects(
                points, departure, extra_margin_km=margin_km
            )
            hard_blocked = external_hard_blocked
            exposure = airspace.path_hazard_risk(points, departure)
        kinematics = forecast_route_kinematics(
            points,
            departure,
            payloads,
            forecast,
            params.physics,
        )
        forecast_covered = kinematics is not None
        duration = None if kinematics is None else float(kinematics[1])
        energy = None if kinematics is None else float(kinematics[0])
    battery_feasible = None if energy is None else (
        energy + physical_reserve <= battery + _EPS
    )
    reserve_margin = (
        None if energy is None else float(battery - energy - physical_reserve)
    )
    packet_hard_code_present = any(
        code in {
            InfeasibilityReason.HARD_WEATHER_BLOCK.value,
            InfeasibilityReason.AIRSPACE_BLOCK.value,
        }
        for code in reason_codes
    )
    if hard_blocked and (external_hard_blocked or not packet_hard_code_present):
        reasons.append("hard-airspace-intersection")
        if InfeasibilityReason.AIRSPACE_BLOCK.value not in reason_codes:
            reason_codes.append(InfeasibilityReason.AIRSPACE_BLOCK.value)
    if not forecast_covered:
        reasons.append("forecast-not-covered")
        if InfeasibilityReason.INVALID_ENVIRONMENTAL_COVERAGE.value not in reason_codes:
            reason_codes.append(InfeasibilityReason.INVALID_ENVIRONMENTAL_COVERAGE.value)
    elif battery_feasible is False:
        reasons.append("insufficient-battery")
        if InfeasibilityReason.INSUFFICIENT_BATTERY.value not in reason_codes:
            reason_codes.append(InfeasibilityReason.INSUFFICIENT_BATTERY.value)
    arrival_time = None if duration is None else float(departure + duration)
    if arrival_time is not None and arrival_time > params.mission.T + _EPS:
        reasons.append("mission-horizon-exceeded")
        if InfeasibilityReason.MISSION_HORIZON_EXCEEDED.value not in reason_codes:
            reason_codes.append(InfeasibilityReason.MISSION_HORIZON_EXCEEDED.value)
    feasible = bool(
        duration is not None
        and forecast_covered
        and not hard_blocked
        and battery_feasible is not False
        and not reason_codes
    )
    failure_reason = reason_codes[0] if not feasible and reason_codes else None
    return RouteEvaluation(
        distance_km=distance,
        duration_h=duration,
        hard_blocked=hard_blocked,
        hazard_exposure=float(exposure),
        forecast_covered=forecast_covered,
        forecast_energy_wh=energy,
        battery_feasible=battery_feasible,
        reasons=tuple(reasons),
        feasible=feasible,
        failure_reason=failure_reason,
        reason_codes=tuple(reason_codes),
        leg_evaluations=leg_evaluations,
        reserve_margin_wh=reserve_margin,
        arrival_time_h=arrival_time,
    )
